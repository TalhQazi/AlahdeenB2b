-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 15, 2021 at 07:15 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `alahdeen_stats`
--

-- --------------------------------------------------------

--
-- Table structure for table `category_impression_stats`
--

CREATE TABLE `category_impression_stats` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `category_view_stats`
--

CREATE TABLE `category_view_stats` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `general_stats`
--

CREATE TABLE `general_stats` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `no_of_rfqs` bigint(20) UNSIGNED NOT NULL,
  `no_of_categories` bigint(20) UNSIGNED NOT NULL,
  `no_of_active_suppliers` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_contacted_stats`
--

CREATE TABLE `product_contacted_stats` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_impression_stats`
--

CREATE TABLE `product_impression_stats` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_view_stats`
--

CREATE TABLE `product_view_stats` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `warehouse_contacted_stats`
--

CREATE TABLE `warehouse_contacted_stats` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `warehouse_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `warehouse_impression_stats`
--

CREATE TABLE `warehouse_impression_stats` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `warehouse_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `warehouse_view_stats`
--

CREATE TABLE `warehouse_view_stats` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `warehouse_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category_impression_stats`
--
ALTER TABLE `category_impression_stats`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_impression_stats_category_id_foreign` (`category_id`);

--
-- Indexes for table `category_view_stats`
--
ALTER TABLE `category_view_stats`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_view_stats_category_id_foreign` (`category_id`);

--
-- Indexes for table `general_stats`
--
ALTER TABLE `general_stats`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_contacted_stats`
--
ALTER TABLE `product_contacted_stats`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_contacted_stats_product_id_foreign` (`product_id`);

--
-- Indexes for table `product_impression_stats`
--
ALTER TABLE `product_impression_stats`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_impression_stats_product_id_foreign` (`product_id`);

--
-- Indexes for table `product_view_stats`
--
ALTER TABLE `product_view_stats`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_view_stats_product_id_foreign` (`product_id`);

--
-- Indexes for table `warehouse_contacted_stats`
--
ALTER TABLE `warehouse_contacted_stats`
  ADD PRIMARY KEY (`id`),
  ADD KEY `warehouse_contacted_stats_warehouse_id_foreign` (`warehouse_id`);

--
-- Indexes for table `warehouse_impression_stats`
--
ALTER TABLE `warehouse_impression_stats`
  ADD PRIMARY KEY (`id`),
  ADD KEY `warehouse_impression_stats_warehouse_id_foreign` (`warehouse_id`);

--
-- Indexes for table `warehouse_view_stats`
--
ALTER TABLE `warehouse_view_stats`
  ADD PRIMARY KEY (`id`),
  ADD KEY `warehouse_view_stats_warehouse_id_foreign` (`warehouse_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category_impression_stats`
--
ALTER TABLE `category_impression_stats`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `category_view_stats`
--
ALTER TABLE `category_view_stats`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `general_stats`
--
ALTER TABLE `general_stats`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_contacted_stats`
--
ALTER TABLE `product_contacted_stats`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_impression_stats`
--
ALTER TABLE `product_impression_stats`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_view_stats`
--
ALTER TABLE `product_view_stats`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `warehouse_contacted_stats`
--
ALTER TABLE `warehouse_contacted_stats`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `warehouse_impression_stats`
--
ALTER TABLE `warehouse_impression_stats`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `warehouse_view_stats`
--
ALTER TABLE `warehouse_view_stats`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `category_impression_stats`
--
ALTER TABLE `category_impression_stats`
  ADD CONSTRAINT `category_impression_stats_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `main`.`categories` (`id`);

--
-- Constraints for table `category_view_stats`
--
ALTER TABLE `category_view_stats`
  ADD CONSTRAINT `category_view_stats_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `main`.`categories` (`id`);

--
-- Constraints for table `product_contacted_stats`
--
ALTER TABLE `product_contacted_stats`
  ADD CONSTRAINT `product_contacted_stats_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `main`.`products` (`id`);

--
-- Constraints for table `product_impression_stats`
--
ALTER TABLE `product_impression_stats`
  ADD CONSTRAINT `product_impression_stats_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `main`.`products` (`id`);

--
-- Constraints for table `product_view_stats`
--
ALTER TABLE `product_view_stats`
  ADD CONSTRAINT `product_view_stats_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `main`.`products` (`id`);

--
-- Constraints for table `warehouse_contacted_stats`
--
ALTER TABLE `warehouse_contacted_stats`
  ADD CONSTRAINT `warehouse_contacted_stats_warehouse_id_foreign` FOREIGN KEY (`warehouse_id`) REFERENCES `main`.`warehouses` (`id`);

--
-- Constraints for table `warehouse_impression_stats`
--
ALTER TABLE `warehouse_impression_stats`
  ADD CONSTRAINT `warehouse_impression_stats_warehouse_id_foreign` FOREIGN KEY (`warehouse_id`) REFERENCES `main`.`warehouses` (`id`);

--
-- Constraints for table `warehouse_view_stats`
--
ALTER TABLE `warehouse_view_stats`
  ADD CONSTRAINT `warehouse_view_stats_warehouse_id_foreign` FOREIGN KEY (`warehouse_id`) REFERENCES `main`.`warehouses` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
