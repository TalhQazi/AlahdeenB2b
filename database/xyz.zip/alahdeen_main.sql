-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 18, 2021 at 09:34 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `alahdeen_main`
--

-- --------------------------------------------------------

--
-- Table structure for table `additional_business_details`
--

CREATE TABLE `additional_business_details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `business_id` bigint(20) UNSIGNED NOT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `import_export_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `income_tax_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ntn` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `no_of_production_units` int(11) DEFAULT NULL,
  `affiliation_memberships` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_branches` int(11) DEFAULT NULL,
  `owner_cnic` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `infrastructure_size` int(11) DEFAULT NULL,
  `cities_to_trade_with` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`cities_to_trade_with`)),
  `cities_to_trade_from` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`cities_to_trade_from`)),
  `shipment_modes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`shipment_modes`)),
  `payment_modes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`payment_modes`)),
  `arn_no` int(11) DEFAULT NULL,
  `start_day` varchar(9) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_time` varchar(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `end_day` varchar(9) COLLATE utf8mb4_unicode_ci NOT NULL,
  `end_time` varchar(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `states` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`states`)),
  `included_cities` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`included_cities`)),
  `excluded_cities` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`excluded_cities`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `additional_business_details`
--

INSERT INTO `additional_business_details` (`id`, `business_id`, `logo`, `description`, `import_export_no`, `company_id`, `bank_name`, `income_tax_number`, `ntn`, `no_of_production_units`, `affiliation_memberships`, `company_branches`, `owner_cnic`, `infrastructure_size`, `cities_to_trade_with`, `cities_to_trade_from`, `shipment_modes`, `payment_modes`, `arn_no`, `start_day`, `start_time`, `end_day`, `end_time`, `states`, `included_cities`, `excluded_cities`, `created_at`, `updated_at`) VALUES
(1, 2, 'http://localhost:8000/img/camera_icon.png', '<p> Company Description </p>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Monday', '9 A.M.', 'Friday', '9 P.M.', NULL, NULL, NULL, '2021-11-22 09:01:25', '2021-11-22 09:01:25'),
(2, 3, 'http://localhost:8000/img/camera_icon.png', '<p> Company Description </p>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Monday', '9 A.M.', 'Friday', '9 P.M.', NULL, NULL, NULL, '2021-11-22 09:01:25', '2021-11-22 09:01:25'),
(3, 4, 'http://localhost:8000/img/camera_icon.png', '<p> Company Description </p>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Monday', '9 A.M.', 'Friday', '9 P.M.', NULL, NULL, NULL, '2021-11-22 09:01:25', '2021-11-22 09:01:25'),
(4, 5, 'http://localhost:8000/img/camera_icon.png', '<p> Company Description </p>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Monday', '9 A.M.', 'Friday', '9 P.M.', NULL, NULL, NULL, '2021-11-22 09:01:25', '2021-11-22 09:01:25'),
(5, 6, 'http://localhost:8000/img/camera_icon.png', '<p> Company Description </p>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Monday', '9 A.M.', 'Friday', '9 P.M.', NULL, NULL, NULL, '2021-11-22 09:01:25', '2021-11-22 09:01:25'),
(6, 7, 'http://localhost:8000/img/camera_icon.png', '<p> Company Description </p>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Monday', '9 A.M.', 'Friday', '9 P.M.', NULL, NULL, NULL, '2021-11-22 09:01:25', '2021-11-22 09:01:25'),
(7, 8, 'http://localhost:8000/img/camera_icon.png', '<p> Company Description </p>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Monday', '9 A.M.', 'Friday', '9 P.M.', NULL, NULL, NULL, '2021-11-22 09:01:26', '2021-11-22 09:01:26'),
(8, 9, 'http://localhost:8000/img/camera_icon.png', '<p> Company Description </p>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Monday', '9 A.M.', 'Friday', '9 P.M.', NULL, NULL, NULL, '2021-11-22 09:01:26', '2021-11-22 09:01:26'),
(9, 10, 'http://localhost:8000/img/camera_icon.png', '<p> Company Description </p>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Monday', '9 A.M.', 'Friday', '9 P.M.', NULL, NULL, NULL, '2021-11-22 09:01:26', '2021-11-22 09:01:26'),
(10, 11, 'http://localhost:8000/img/camera_icon.png', '<p> Company Description </p>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Monday', '9 A.M.', 'Friday', '9 P.M.', NULL, NULL, NULL, '2021-11-22 09:01:26', '2021-11-22 09:01:26');

-- --------------------------------------------------------

--
-- Table structure for table `advertisments`
--

CREATE TABLE `advertisments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image_path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url_link` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `display_order` int(11) NOT NULL DEFAULT 1,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `display_section` enum('Top','Middle','Bottom') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `badges`
--

CREATE TABLE `badges` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `badges`
--

INSERT INTO `badges` (`id`, `name`, `image`, `created_at`, `updated_at`) VALUES
(1, 'Verified', 'images/badges/verified-seller.svg', '2021-11-11 12:27:23', '2021-11-11 12:27:23'),
(2, 'Top Seller', 'images/badges/top-seller.svg', '2021-11-11 12:27:23', '2021-11-11 12:27:23'),
(3, 'Most Active', 'images/badges/active-seller.svg', '2021-11-11 12:27:23', '2021-11-11 12:27:23'),
(4, 'Category Leader', 'images/badges/category-leader.svg', '2021-11-11 12:27:23', '2021-11-11 12:27:23');

-- --------------------------------------------------------

--
-- Table structure for table `booking_agreement_terms`
--

CREATE TABLE `booking_agreement_terms` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `booking_id` bigint(20) UNSIGNED NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `item` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` double DEFAULT NULL,
  `unit` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `area` double DEFAULT NULL,
  `type` enum('partial','fully') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'fully',
  `goods_value` double DEFAULT NULL,
  `price` double NOT NULL,
  `user_terms` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_terms` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `creator_role` bigint(20) UNSIGNED NOT NULL,
  `requestor_payment_status` tinyint(1) NOT NULL DEFAULT 0,
  `owner_paid_status` tinyint(1) NOT NULL DEFAULT 0,
  `tax_percentage` double NOT NULL DEFAULT 0,
  `tax_amount` double NOT NULL DEFAULT 0,
  `commission_percentage` double NOT NULL DEFAULT 10,
  `commission_paid` double DEFAULT NULL,
  `total_paid_to_owner` double DEFAULT NULL,
  `payment_method_id` bigint(20) UNSIGNED NOT NULL,
  `status` enum('pending','cancelled','confirmed','refunded') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `business_awards`
--

CREATE TABLE `business_awards` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `business_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `award_image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `business_certifications`
--

CREATE TABLE `business_certifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `business_id` bigint(20) UNSIGNED NOT NULL,
  `certification` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `membership` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_path` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `business_contact_details`
--

CREATE TABLE `business_contact_details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `business_id` bigint(20) UNSIGNED NOT NULL,
  `division` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_person` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `designation` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `locality` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cell_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telephone_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `toll_free_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `business_details`
--

CREATE TABLE `business_details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `company_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gst_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_decision_maker` tinyint(1) NOT NULL DEFAULT 0,
  `monthly_production_cap` int(11) DEFAULT NULL,
  `trade_brand_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pakistan',
  `city_id` bigint(20) UNSIGNED DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `locality` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zip_code` int(11) DEFAULT NULL,
  `phone_number` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alternate_website` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `year_of_establishment` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `no_of_employees` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `annual_turnover` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ownership_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `business_details`
--

INSERT INTO `business_details` (`id`, `user_id`, `company_name`, `gst_no`, `is_decision_maker`, `monthly_production_cap`, `trade_brand_name`, `country`, `city_id`, `address`, `locality`, `zip_code`, `phone_number`, `alternate_website`, `year_of_establishment`, `no_of_employees`, `annual_turnover`, `ownership_type`, `created_at`, `updated_at`) VALUES
(1, 1, 'Web Developer', NULL, 1, 100, NULL, 'Pakistan', 8, 'Shahrukne Allam Colony Houe#257', 'Multan', 66000, '+92+923087742186', 'http://lootmall.quickpowersolutions.com.pk/', '2005', '100', NULL, NULL, '2021-11-12 10:35:31', '2021-12-04 18:27:21'),
(2, 6, 'Jakayla Predovic V', NULL, 0, NULL, NULL, 'Pakistan', 8, '964 Elmer Mission Suite 097\nZulaufview, MS 08185', 'vMlFhQDsfe', 16401, '432-508-2822', 'https://OJQcHA1LBj.com', '2005', '620', '45323', 'Private Limited Company', '2021-11-22 09:01:25', '2021-11-22 09:01:25'),
(3, 7, 'Felicita Bahringer I', NULL, 0, NULL, NULL, 'Pakistan', 7, '850 Medhurst RanchAlisaview, DE 60606', 'n4H5PQ7qSA', 36673, '+15705946411', 'https://AfUAiX1IQy.com', '2011', '843', '89050', 'Private Limited Company', '2021-11-22 09:01:25', '2021-12-04 18:14:52'),
(4, 8, 'Ramona Wilkinson I', NULL, 0, NULL, NULL, 'Pakistan', 7, '300 Mills Court\nAlexanemouth, OH 62245', 'o6Wlc5UpJi', 38456, '470.874.0593', 'https://zwu4DT3GlB.com', '1998', '710', '76147', 'Private Limited Company', '2021-11-22 09:01:25', '2021-11-22 09:01:25'),
(5, 9, 'Russel Renner', NULL, 0, NULL, NULL, 'Pakistan', 10, '6648 Fletcher Cove Apt. 825\nWest Junius, IL 77323-9135', 'eGHuMSG3dn', 23743, '1-862-644-0888', 'https://WWXXt6PCVU.com', '2005', '620', '72648', 'Private Limited Company', '2021-11-22 09:01:25', '2021-11-22 09:01:25'),
(6, 10, 'Elenor Mosciski', NULL, 0, NULL, NULL, 'Pakistan', 10, '62961 Glover Locks\nLauriannefurt, WV 65064', 'BJYQHZrW6c', 25597, '323-747-9947', 'https://0lKL1fG6mV.com', '1970', '167', '39494', 'Private Limited Company', '2021-11-22 09:01:25', '2021-11-22 09:01:25'),
(7, 11, 'Dr. Javier Nicolas', NULL, 0, NULL, NULL, 'Pakistan', 8, '282 Swift Crescent\nArianeland, NY 46124-6891', '2cqTISGGk8', 40223, '1-504-474-0509', 'https://ATmQqx7tqi.com', '2014', '165', '86869', 'Private Limited Company', '2021-11-22 09:01:25', '2021-11-22 09:01:25'),
(8, 12, 'Estelle Cartwright', NULL, 0, NULL, NULL, 'Pakistan', 4, '67550 Champlin Run Suite 272\nFeeneyland, AZ 17645-2643', 'zN8wPX9CWn', 12880, '828.991.3663', 'https://GXWZyy8R6a.com', '1997', '196', '20977', 'Private Limited Company', '2021-11-22 09:01:25', '2021-11-22 09:01:25'),
(9, 13, 'Dr. Adriana Gottlieb', NULL, 0, NULL, NULL, 'Pakistan', 10, '114 Lesch Lock\nEast Aldatown, SD 70832', 'gPd88ihJKf', 41179, '850.803.4209', 'https://SouSUfTYG6.com', '1974', '837', '95780', 'Private Limited Company', '2021-11-22 09:01:26', '2021-11-22 09:01:26'),
(10, 14, 'Aileen Collins', NULL, 0, NULL, NULL, 'Pakistan', 3, '164 Lesch Points\nDelphiaville, MD 12841', 'TOdUXlC6DD', 35453, '+12524556207', 'https://QYFaO8XR5c.com', '2003', '720', '18417', 'Private Limited Company', '2021-11-22 09:01:26', '2021-11-22 09:01:26'),
(11, 15, 'Mr. Braden Nicolas III', NULL, 0, NULL, NULL, 'Pakistan', 5, '6618 Dietrich Ridge Suite 509\nEffertzmouth, WA 33369', 'EP27xCD61n', 28269, '718-851-3337', 'https://oQRo8OOLx0.com', '2006', '356', '25543', 'Private Limited Company', '2021-11-22 09:01:26', '2021-11-22 09:01:26');

-- --------------------------------------------------------

--
-- Table structure for table `business_directors`
--

CREATE TABLE `business_directors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `business_id` bigint(20) UNSIGNED DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `director_photo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `designation` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `business_directors`
--

INSERT INTO `business_directors` (`id`, `business_id`, `user_id`, `director_photo`, `name`, `designation`, `description`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'public/director-profile-pictures/9iW8ylSNR48ZN5s4lVt9qSGu8AqwwGUfZHRHwqG0.jpg', 'Asad Mahmood', 'software developer', NULL, '2021-12-04 17:59:23', '2021-12-04 17:59:23'),
(2, 1, 1, 'public/director-profile-pictures/IX6MgOTu8Wn5blfvVgfo2QkH0x1eBQRQ2oProZBO.jpg', 'Talha', 'sidjfpisd', '<p>slkdjhgiusdfjnvush</p>', '2021-12-06 12:14:42', '2021-12-06 12:14:42'),
(4, 1, 1, 'public/director-profile-pictures/ZEH5Die4Xeuvo3VVRTLoRiZ1krp4doXRIpjWwng2.jpg', 'Qazi shb', 'software developer', '<p>this is developer description</p>', '2021-12-07 08:14:30', '2021-12-07 08:14:30');

-- --------------------------------------------------------

--
-- Table structure for table `business_mode_of_payments`
--

CREATE TABLE `business_mode_of_payments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `business_id` bigint(20) UNSIGNED NOT NULL,
  `mode_of_payment_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `business_photos`
--

CREATE TABLE `business_photos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `business_id` bigint(20) UNSIGNED NOT NULL,
  `photo_path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `business_types`
--

CREATE TABLE `business_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `business_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `business_types`
--

INSERT INTO `business_types` (`id`, `business_type`, `created_at`, `updated_at`) VALUES
(1, 'Manufacturer', '2021-11-11 12:18:51', '2021-11-11 12:18:51'),
(2, 'Exporter', '2021-11-11 12:18:51', '2021-11-11 12:18:51'),
(3, 'Importer', '2021-11-11 12:18:51', '2021-11-11 12:18:51'),
(4, 'Distributor', '2021-11-11 12:18:51', '2021-11-11 12:18:51'),
(5, 'Supplier', '2021-11-11 12:18:51', '2021-11-11 12:18:51'),
(6, 'Trader', '2021-11-11 12:18:51', '2021-11-11 12:18:51'),
(7, 'Wholesaler', '2021-11-11 12:18:51', '2021-11-11 12:18:51'),
(8, 'Retailer', '2021-11-11 12:18:51', '2021-11-11 12:18:51'),
(9, 'Dealer', '2021-11-11 12:18:51', '2021-11-11 12:18:51'),
(10, 'Fabricator', '2021-11-11 12:18:52', '2021-11-11 12:18:52'),
(11, 'Producer', '2021-11-11 12:18:52', '2021-11-11 12:18:52'),
(12, 'Service Provider', '2021-11-11 12:18:52', '2021-11-11 12:18:52'),
(13, 'Manufacturer', '2021-11-11 12:27:35', '2021-11-11 12:27:35'),
(14, 'Exporter', '2021-11-11 12:27:35', '2021-11-11 12:27:35'),
(15, 'Importer', '2021-11-11 12:27:35', '2021-11-11 12:27:35'),
(16, 'Distributor', '2021-11-11 12:27:35', '2021-11-11 12:27:35'),
(17, 'Supplier', '2021-11-11 12:27:35', '2021-11-11 12:27:35'),
(18, 'Trader', '2021-11-11 12:27:35', '2021-11-11 12:27:35'),
(19, 'Wholesaler', '2021-11-11 12:27:35', '2021-11-11 12:27:35'),
(20, 'Retailer', '2021-11-11 12:27:35', '2021-11-11 12:27:35'),
(21, 'Dealer', '2021-11-11 12:27:35', '2021-11-11 12:27:35'),
(22, 'Fabricator', '2021-11-11 12:27:35', '2021-11-11 12:27:35'),
(23, 'Producer', '2021-11-11 12:27:35', '2021-11-11 12:27:35'),
(24, 'Service Provider', '2021-11-11 12:27:35', '2021-11-11 12:27:35');

-- --------------------------------------------------------

--
-- Table structure for table `catalogs`
--

CREATE TABLE `catalogs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `catalogs`
--

INSERT INTO `catalogs` (`id`, `user_id`, `title`, `path`, `created_at`, `updated_at`) VALUES
(1, 15, 'sdf', 'public/catalog/documents/kfszYqhs4cpWc7JYAI87hpHb9PahkHVXxDZlVX2W.pdf', '2021-12-15 11:52:12', '2021-12-15 11:52:12'),
(2, 15, 'Test', 'documents/61bb06ae224f5/1639646894-qDhH-catalog.pdf', '2021-12-16 09:28:14', '2021-12-16 09:28:14');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_cat_id` bigint(20) UNSIGNED DEFAULT NULL,
  `image_path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level` int(11) NOT NULL DEFAULT 1,
  `bread_crumb` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `title`, `parent_cat_id`, `image_path`, `level`, `bread_crumb`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Electronics', NULL, 'public/category/images/gpbHlEnZswJEV3aaiKZRzagfoNNvMs0Lbmj1sBkk.jpg', 1, NULL, '2021-11-11 12:18:51', '2021-11-26 11:52:33', NULL),
(2, 'Medical Equipments', 1, 'category', 2, NULL, '2021-11-11 12:18:51', '2021-11-11 12:18:51', NULL),
(3, 'Laptops', 1, 'category', 2, NULL, '2021-11-11 12:18:51', '2021-11-11 12:18:51', NULL),
(4, 'Mobiles', 1, 'category', 1, NULL, '2021-11-11 12:18:51', '2021-11-11 12:18:51', NULL),
(5, 'sub mobile', 4, 'category', 2, NULL, '2021-11-11 12:27:44', '2021-11-11 12:27:44', NULL),
(6, 'sub mobile 2', 4, 'category', 3, NULL, '2021-11-11 12:27:45', '2021-11-11 12:27:45', NULL),
(7, 'Laptops', NULL, 'category', 1, NULL, '2021-11-11 12:27:45', '2021-11-11 12:27:45', NULL),
(8, 'Mobiles', NULL, 'category', 1, NULL, '2021-11-11 12:27:45', '2021-11-11 12:27:45', NULL),
(9, 'Electronics', NULL, 'category', 1, NULL, '2021-11-26 11:37:29', '2021-11-26 11:37:29', NULL),
(10, 'Medical Equipments', NULL, 'category', 1, NULL, '2021-11-26 11:37:29', '2021-11-26 11:37:29', NULL),
(11, 'Laptops', NULL, 'category', 1, NULL, '2021-11-26 11:37:29', '2021-11-26 11:37:29', NULL),
(12, 'Mobiles', NULL, 'category', 1, NULL, '2021-11-26 11:37:29', '2021-11-26 11:37:29', NULL),
(13, 'Pakistan', 1, 'public/category/images/JJYbLGZctAFMUtR53iDPBJw53UyTai49LwEVpjfG.jpg', 2, ';1;', '2021-11-26 11:52:07', '2021-11-26 11:52:07', NULL),
(14, 'pak', 13, 'public/category/images/1h2IqWcKBdhEho7wTw55UPHVFHt77UwmURU4OFOr.jpg', 3, ';1;13;', '2021-12-04 17:38:59', '2021-12-04 17:38:59', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `challans`
--

CREATE TABLE `challans` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `from` bigint(20) UNSIGNED NOT NULL,
  `to` bigint(20) UNSIGNED NOT NULL,
  `challan_date` datetime NOT NULL,
  `items_included` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_of_pieces` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bilty_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `courier_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `digital_signature` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `challan_path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '/',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `chat_conversations`
--

CREATE TABLE `chat_conversations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `private` tinyint(1) NOT NULL DEFAULT 1,
  `direct_message` tinyint(1) NOT NULL DEFAULT 0,
  `data` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `chat_conversations`
--

INSERT INTO `chat_conversations` (`id`, `private`, `direct_message`, `data`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '{\"id\":2,\"user_id\":7,\"category_ids\":\"2\",\"required_product\":\"this is requirment\",\"image_path\":null,\"requirement_details\":\"this is details\",\"quantity\":\"10.00\",\"unit\":\"10\",\"budget\":1220,\"requirement_urgency\":\"immediate\",\"requirement_frequency\":\"regular\",\"supplier_location\":\"any where in pakistan\",\"terms_and_conditions\":0,\"created_at\":\"2021-11-24T09:00:39.000000Z\",\"updated_at\":null}', '2021-11-24 11:41:43', '2021-12-10 09:22:57'),
(2, 1, 1, '{\"id\":8,\"user_id\":8,\"category_ids\":\"2\",\"required_product\":\"this is product\",\"image_path\":null,\"requirement_details\":\"jasddfk\",\"quantity\":\"10.00\",\"unit\":\"10\",\"budget\":1000,\"requirement_urgency\":\"immediate\",\"requirement_frequency\":\"one time\",\"supplier_location\":\"any where in pakistan\",\"terms_and_conditions\":0,\"created_at\":\"2021-11-24T18:07:26.000000Z\",\"updated_at\":null}', '2021-12-07 08:20:34', '2021-12-07 08:20:34');

-- --------------------------------------------------------

--
-- Table structure for table `chat_labels`
--

CREATE TABLE `chat_labels` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `label_id` bigint(20) UNSIGNED NOT NULL,
  `conversation_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `chat_messages`
--

CREATE TABLE `chat_messages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `conversation_id` bigint(20) UNSIGNED NOT NULL,
  `participation_id` bigint(20) UNSIGNED DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'text',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `chat_messages`
--

INSERT INTO `chat_messages` (`id`, `body`, `conversation_id`, `participation_id`, `type`, `created_at`, `updated_at`) VALUES
(1, 'Hi Rosella McLaughlin', 1, 2, 'text', '2021-11-24 11:41:44', '2021-11-24 11:41:44'),
(2, 'public/quotations/1637754093.pdf', 1, 2, 'quotation', '2021-11-24 11:41:44', '2021-11-24 11:41:44'),
(3, 'Please find the quotation', 1, 2, 'text', '2021-11-24 11:41:44', '2021-11-24 11:41:44'),
(4, 'public/quotations/1637754367.pdf', 1, 2, 'quotation', '2021-11-24 11:46:10', '2021-11-24 11:46:10'),
(5, 'Please find the quotation', 1, 2, 'text', '2021-11-24 11:46:10', '2021-11-24 11:46:10'),
(6, 'hi there', 1, 2, 'text', '2021-12-10 09:20:53', '2021-12-10 09:20:53'),
(7, 'hi there', 1, 2, 'text', '2021-12-10 09:20:54', '2021-12-10 09:20:54'),
(8, 'this is Talha nizami', 1, 2, 'text', '2021-12-10 09:21:16', '2021-12-10 09:21:16'),
(9, 'public/conversations/1/attachments/yEel2n9TH58mOVEJ4RJYuTkDaJgiMD4ev9Bu3SuJ.jpg', 1, 2, 'image', '2021-12-10 09:22:57', '2021-12-10 09:22:57'),
(10, 'this is saudi flag', 1, 2, 'text', '2021-12-10 09:22:57', '2021-12-10 09:22:57');

-- --------------------------------------------------------

--
-- Table structure for table `chat_message_notifications`
--

CREATE TABLE `chat_message_notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `message_id` bigint(20) UNSIGNED NOT NULL,
  `messageable_id` bigint(20) UNSIGNED NOT NULL,
  `messageable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conversation_id` bigint(20) UNSIGNED NOT NULL,
  `participation_id` bigint(20) UNSIGNED NOT NULL,
  `is_seen` tinyint(1) NOT NULL DEFAULT 0,
  `is_sender` tinyint(1) NOT NULL DEFAULT 0,
  `flagged` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `chat_message_notifications`
--

INSERT INTO `chat_message_notifications` (`id`, `message_id`, `messageable_id`, `messageable_type`, `conversation_id`, `participation_id`, `is_seen`, `is_sender`, `flagged`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 7, 'App\\Models\\User', 1, 1, 1, 0, 0, '2021-11-24 11:41:44', '2021-12-07 08:18:17', NULL),
(2, 1, 1, 'App\\Models\\User', 1, 2, 1, 1, 0, '2021-11-24 11:41:44', '2021-12-10 09:20:13', NULL),
(3, 2, 7, 'App\\Models\\User', 1, 1, 1, 0, 0, '2021-11-24 11:41:44', '2021-12-07 08:18:17', NULL),
(4, 2, 1, 'App\\Models\\User', 1, 2, 1, 1, 0, '2021-11-24 11:41:44', '2021-12-10 09:20:13', NULL),
(5, 3, 7, 'App\\Models\\User', 1, 1, 1, 0, 0, '2021-11-24 11:41:44', '2021-12-07 08:18:17', NULL),
(6, 3, 1, 'App\\Models\\User', 1, 2, 1, 1, 0, '2021-11-24 11:41:44', '2021-12-10 09:20:13', NULL),
(7, 4, 7, 'App\\Models\\User', 1, 1, 1, 0, 0, '2021-11-24 11:46:10', '2021-12-07 08:18:17', NULL),
(8, 4, 1, 'App\\Models\\User', 1, 2, 1, 1, 0, '2021-11-24 11:46:10', '2021-12-10 09:20:13', NULL),
(9, 5, 7, 'App\\Models\\User', 1, 1, 1, 0, 0, '2021-11-24 11:46:10', '2021-12-07 08:18:17', NULL),
(10, 5, 1, 'App\\Models\\User', 1, 2, 1, 1, 0, '2021-11-24 11:46:10', '2021-12-10 09:20:13', NULL),
(11, 6, 1, 'App\\Models\\User', 1, 2, 1, 1, 0, '2021-12-10 09:20:53', NULL, NULL),
(12, 6, 7, 'App\\Models\\User', 1, 1, 0, 0, 0, '2021-12-10 09:20:53', NULL, NULL),
(13, 7, 1, 'App\\Models\\User', 1, 2, 1, 1, 0, '2021-12-10 09:20:54', NULL, NULL),
(14, 7, 7, 'App\\Models\\User', 1, 1, 0, 0, 0, '2021-12-10 09:20:54', NULL, NULL),
(15, 8, 1, 'App\\Models\\User', 1, 2, 1, 1, 0, '2021-12-10 09:21:16', NULL, NULL),
(16, 8, 7, 'App\\Models\\User', 1, 1, 0, 0, 0, '2021-12-10 09:21:16', NULL, NULL),
(17, 9, 1, 'App\\Models\\User', 1, 2, 1, 1, 0, '2021-12-10 09:22:57', NULL, NULL),
(18, 9, 7, 'App\\Models\\User', 1, 1, 0, 0, 0, '2021-12-10 09:22:57', NULL, NULL),
(19, 10, 1, 'App\\Models\\User', 1, 2, 1, 1, 0, '2021-12-10 09:22:57', NULL, NULL),
(20, 10, 7, 'App\\Models\\User', 1, 1, 0, 0, 0, '2021-12-10 09:22:57', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `chat_participation`
--

CREATE TABLE `chat_participation` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `conversation_id` bigint(20) UNSIGNED NOT NULL,
  `messageable_id` bigint(20) UNSIGNED NOT NULL,
  `messageable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `settings` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `chat_participation`
--

INSERT INTO `chat_participation` (`id`, `conversation_id`, `messageable_id`, `messageable_type`, `settings`, `created_at`, `updated_at`) VALUES
(1, 1, 7, 'App\\Models\\User', NULL, '2021-11-24 11:41:43', '2021-11-24 11:41:43'),
(2, 1, 1, 'App\\Models\\User', NULL, '2021-11-24 11:41:43', '2021-11-24 11:41:43'),
(3, 2, 8, 'App\\Models\\User', NULL, '2021-12-07 08:20:34', '2021-12-07 08:20:34'),
(4, 2, 1, 'App\\Models\\User', NULL, '2021-12-07 08:20:34', '2021-12-07 08:20:34');

-- --------------------------------------------------------

--
-- Table structure for table `chat_reminders`
--

CREATE TABLE `chat_reminders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `conversation_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `reminder_date_time` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_notification_sent` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city_ascii` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lat` decimal(10,8) NOT NULL,
  `lng` decimal(11,8) NOT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `iso2` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `iso3` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `capital` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `city`, `city_ascii`, `lat`, `lng`, `country`, `iso2`, `iso3`, `admin_name`, `capital`, `created_at`, `updated_at`) VALUES
(1, 'Karachi', 'Karachi', '24.86000000', '67.01000000', 'Pakistan', 'PK', 'PAK', 'Sindh', 'admin', '2021-11-11 12:18:47', '2021-11-11 12:18:47'),
(2, 'Lahore', 'Lahore', '31.54970000', '74.34360000', 'Pakistan', 'PK', 'PAK', 'Punjab', 'admin', '2021-11-11 12:18:47', '2021-11-11 12:18:47'),
(3, 'Sialkot City', 'Sialkot City', '32.50000000', '74.53330000', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '2021-11-11 12:18:47', '2021-11-11 12:18:47'),
(4, 'Faisalabad', 'Faisalabad', '31.41800000', '73.07900000', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '2021-11-11 12:18:47', '2021-11-11 12:18:47'),
(5, 'Rawalpindi', 'Rawalpindi', '33.60070000', '73.06790000', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '2021-11-11 12:18:47', '2021-11-11 12:18:47'),
(6, 'Peshawar', 'Peshawar', '34.00000000', '71.50000000', 'Pakistan', 'PK', 'PAK', 'Khyber Pakhtunkhwa', 'admin', '2021-11-11 12:18:47', '2021-11-11 12:18:47'),
(7, 'Saidu Sharif', 'Saidu Sharif', '34.75000000', '72.35720000', 'Pakistan', 'PK', 'PAK', 'Khyber Pakhtunkhwa', 'minor', '2021-11-11 12:18:47', '2021-11-11 12:18:47'),
(8, 'Multan', 'Multan', '30.19780000', '71.47110000', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '2021-11-11 12:18:47', '2021-11-11 12:18:47'),
(9, 'Gujranwala', 'Gujranwala', '32.15000000', '74.18330000', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '2021-11-11 12:18:47', '2021-11-11 12:18:47'),
(10, 'Islamabad', 'Islamabad', '33.69890000', '73.03690000', 'Pakistan', 'PK', 'PAK', 'Islāmābād', 'primary', '2021-11-11 12:18:48', '2021-11-11 12:18:48'),
(11, 'Quetta', 'Quetta', '30.19200000', '67.00700000', 'Pakistan', 'PK', 'PAK', 'Balochistān', 'admin', '2021-11-11 12:18:48', '2021-11-11 12:18:48'),
(12, 'Bahawalpur', 'Bahawalpur', '29.39560000', '71.67220000', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '2021-11-11 12:18:48', '2021-11-11 12:18:48'),
(13, 'Sargodha', 'Sargodha', '32.08360000', '72.67110000', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '2021-11-11 12:18:48', '2021-11-11 12:18:48'),
(14, 'New Mirpur', 'New Mirpur', '33.13330000', '73.75000000', 'Pakistan', 'PK', 'PAK', 'Azad Kashmir', 'minor', '2021-11-11 12:18:48', '2021-11-11 12:18:48'),
(15, 'Chiniot', 'Chiniot', '31.71670000', '72.98330000', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '2021-11-11 12:18:48', '2021-11-11 12:18:48'),
(16, 'Sukkur', 'Sukkur', '27.69950000', '68.86730000', 'Pakistan', 'PK', 'PAK', 'Sindh', 'minor', '2021-11-11 12:18:48', '2021-11-11 12:18:48'),
(17, 'Larkana', 'Larkana', '27.56000000', '68.22640000', 'Pakistan', 'PK', 'PAK', 'Sindh', 'minor', '2021-11-11 12:18:48', '2021-11-11 12:18:48'),
(18, 'Shekhupura', 'Shekhupura', '31.70830000', '74.00000000', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '2021-11-11 12:18:48', '2021-11-11 12:18:48'),
(19, 'Jhang City', 'Jhang City', '31.26810000', '72.31810000', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '2021-11-11 12:18:48', '2021-11-11 12:18:48'),
(20, 'Rahimyar Khan', 'Rahimyar Khan', '28.42020000', '70.29520000', 'Pakistan', 'PK', 'PAK', 'Punjab', '', '2021-11-11 12:18:48', '2021-11-11 12:18:48'),
(21, 'Gujrat', 'Gujrat', '32.57360000', '74.07890000', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '2021-11-11 12:18:48', '2021-11-11 12:18:48'),
(22, 'Kasur', 'Kasur', '31.11670000', '74.45000000', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '2021-11-11 12:18:48', '2021-11-11 12:18:48'),
(23, 'Mardan', 'Mardan', '34.19580000', '72.04470000', 'Pakistan', 'PK', 'PAK', 'Khyber Pakhtunkhwa', 'minor', '2021-11-11 12:18:48', '2021-11-11 12:18:48'),
(24, 'Mingaora', 'Mingaora', '34.77170000', '72.36000000', 'Pakistan', 'PK', 'PAK', 'Khyber Pakhtunkhwa', '', '2021-11-11 12:18:48', '2021-11-11 12:18:48'),
(25, 'Dera Ghazi Khan', 'Dera Ghazi Khan', '30.05000000', '70.63330000', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '2021-11-11 12:18:48', '2021-11-11 12:18:48'),
(26, 'Nawabshah', 'Nawabshah', '26.24420000', '68.41000000', 'Pakistan', 'PK', 'PAK', 'Sindh', 'minor', '2021-11-11 12:18:48', '2021-11-11 12:18:48'),
(27, 'Sahiwal', 'Sahiwal', '30.67060000', '73.10640000', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '2021-11-11 12:18:48', '2021-11-11 12:18:48'),
(28, 'Mirpur Khas', 'Mirpur Khas', '25.52690000', '69.01110000', 'Pakistan', 'PK', 'PAK', 'Sindh', 'minor', '2021-11-11 12:18:48', '2021-11-11 12:18:48'),
(29, 'Okara', 'Okara', '30.81000000', '73.45970000', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '2021-11-11 12:18:48', '2021-11-11 12:18:48'),
(30, 'Mandi Burewala', 'Mandi Burewala', '30.15000000', '72.68330000', 'Pakistan', 'PK', 'PAK', 'Punjab', '', '2021-11-11 12:18:48', '2021-11-11 12:18:48'),
(31, 'Jacobabad', 'Jacobabad', '28.27690000', '68.45140000', 'Pakistan', 'PK', 'PAK', 'Sindh', 'minor', '2021-11-11 12:18:48', '2021-11-11 12:18:48'),
(32, 'Saddiqabad', 'Saddiqabad', '28.30060000', '70.13020000', 'Pakistan', 'PK', 'PAK', 'Punjab', '', '2021-11-11 12:18:48', '2021-11-11 12:18:48'),
(33, 'Kohat', 'Kohat', '33.58690000', '71.44140000', 'Pakistan', 'PK', 'PAK', 'Khyber Pakhtunkhwa', 'minor', '2021-11-11 12:18:48', '2021-11-11 12:18:48'),
(34, 'Muridke', 'Muridke', '31.80200000', '74.25500000', 'Pakistan', 'PK', 'PAK', 'Punjab', '', '2021-11-11 12:18:48', '2021-11-11 12:18:48'),
(35, 'Muzaffargarh', 'Muzaffargarh', '30.07030000', '71.19330000', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '2021-11-11 12:18:48', '2021-11-11 12:18:48'),
(36, 'Khanpur', 'Khanpur', '28.64710000', '70.66200000', 'Pakistan', 'PK', 'PAK', 'Punjab', '', '2021-11-11 12:18:48', '2021-11-11 12:18:48'),
(37, 'Gojra', 'Gojra', '31.15000000', '72.68330000', 'Pakistan', 'PK', 'PAK', 'Punjab', '', '2021-11-11 12:18:48', '2021-11-11 12:18:48'),
(38, 'Mandi Bahauddin', 'Mandi Bahauddin', '32.58610000', '73.49170000', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '2021-11-11 12:18:48', '2021-11-11 12:18:48'),
(39, 'Abbottabad', 'Abbottabad', '34.15000000', '73.21670000', 'Pakistan', 'PK', 'PAK', 'Khyber Pakhtunkhwa', 'minor', '2021-11-11 12:18:49', '2021-11-11 12:18:49'),
(40, 'Dadu', 'Dadu', '26.73190000', '67.77500000', 'Pakistan', 'PK', 'PAK', 'Sindh', 'minor', '2021-11-11 12:18:49', '2021-11-11 12:18:49'),
(41, 'Khuzdar', 'Khuzdar', '27.80000000', '66.61670000', 'Pakistan', 'PK', 'PAK', 'Balochistān', '', '2021-11-11 12:18:49', '2021-11-11 12:18:49'),
(42, 'Pakpattan', 'Pakpattan', '30.35000000', '73.40000000', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '2021-11-11 12:18:49', '2021-11-11 12:18:49'),
(43, 'Tando Allahyar', 'Tando Allahyar', '25.46670000', '68.71670000', 'Pakistan', 'PK', 'PAK', 'Sindh', 'minor', '2021-11-11 12:18:49', '2021-11-11 12:18:49'),
(44, 'Jaranwala', 'Jaranwala', '31.33420000', '73.41940000', 'Pakistan', 'PK', 'PAK', 'Punjab', '', '2021-11-11 12:18:49', '2021-11-11 12:18:49'),
(45, 'Vihari', 'Vihari', '30.04190000', '72.35280000', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '2021-11-11 12:18:49', '2021-11-11 12:18:49'),
(46, 'Kamalia', 'Kamalia', '30.72580000', '72.64470000', 'Pakistan', 'PK', 'PAK', 'Punjab', '', '2021-11-11 12:18:49', '2021-11-11 12:18:49'),
(47, 'Kot Addu', 'Kot Addu', '30.47000000', '70.96440000', 'Pakistan', 'PK', 'PAK', 'Punjab', '', '2021-11-11 12:18:49', '2021-11-11 12:18:49'),
(48, 'Nowshera', 'Nowshera', '34.01530000', '71.97470000', 'Pakistan', 'PK', 'PAK', 'Khyber Pakhtunkhwa', 'minor', '2021-11-11 12:18:49', '2021-11-11 12:18:49'),
(49, 'Swabi', 'Swabi', '34.11670000', '72.46670000', 'Pakistan', 'PK', 'PAK', 'Khyber Pakhtunkhwa', 'minor', '2021-11-11 12:18:49', '2021-11-11 12:18:49'),
(50, 'Dera Ismail Khan', 'Dera Ismail Khan', '31.81670000', '70.91670000', 'Pakistan', 'PK', 'PAK', 'Khyber Pakhtunkhwa', 'minor', '2021-11-11 12:18:49', '2021-11-11 12:18:49'),
(51, 'Chaman', 'Chaman', '30.92100000', '66.45970000', 'Pakistan', 'PK', 'PAK', 'Balochistān', '', '2021-11-11 12:18:49', '2021-11-11 12:18:49'),
(52, 'Charsadda', 'Charsadda', '34.14530000', '71.73080000', 'Pakistan', 'PK', 'PAK', 'Khyber Pakhtunkhwa', 'minor', '2021-11-11 12:18:49', '2021-11-11 12:18:49'),
(53, 'Kandhkot', 'Kandhkot', '28.40000000', '69.30000000', 'Pakistan', 'PK', 'PAK', 'Sindh', '', '2021-11-11 12:18:49', '2021-11-11 12:18:49'),
(54, 'Hasilpur', 'Hasilpur', '29.69670000', '72.55420000', 'Pakistan', 'PK', 'PAK', 'Punjab', '', '2021-11-11 12:18:49', '2021-11-11 12:18:49'),
(55, 'Muzaffarabad', 'Muzaffarabad', '34.37000000', '73.47110000', 'Pakistan', 'PK', 'PAK', 'Azad Kashmir', '', '2021-11-11 12:18:49', '2021-11-11 12:18:49'),
(56, 'Mianwali', 'Mianwali', '32.58530000', '71.54360000', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '2021-11-11 12:18:49', '2021-11-11 12:18:49'),
(57, 'Jalalpur Jattan', 'Jalalpur Jattan', '32.76670000', '74.21670000', 'Pakistan', 'PK', 'PAK', 'Punjab', '', '2021-11-11 12:18:49', '2021-11-11 12:18:49'),
(58, 'Bhakkar', 'Bhakkar', '31.63330000', '71.06670000', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '2021-11-11 12:18:49', '2021-11-11 12:18:49'),
(59, 'Zhob', 'Zhob', '31.34170000', '69.44860000', 'Pakistan', 'PK', 'PAK', 'Balochistān', 'minor', '2021-11-11 12:18:49', '2021-11-11 12:18:49'),
(60, 'Kharian', 'Kharian', '32.81100000', '73.86500000', 'Pakistan', 'PK', 'PAK', 'Punjab', '', '2021-11-11 12:18:49', '2021-11-11 12:18:49'),
(61, 'Mian Channun', 'Mian Channun', '30.43970000', '72.35440000', 'Pakistan', 'PK', 'PAK', 'Punjab', '', '2021-11-11 12:18:50', '2021-11-11 12:18:50'),
(62, 'Jamshoro', 'Jamshoro', '25.42830000', '68.28220000', 'Pakistan', 'PK', 'PAK', 'Sindh', 'minor', '2021-11-11 12:18:50', '2021-11-11 12:18:50'),
(63, 'Pattoki', 'Pattoki', '31.02140000', '73.85280000', 'Pakistan', 'PK', 'PAK', 'Punjab', '', '2021-11-11 12:18:50', '2021-11-11 12:18:50'),
(64, 'Harunabad', 'Harunabad', '29.61000000', '73.13610000', 'Pakistan', 'PK', 'PAK', 'Punjab', '', '2021-11-11 12:18:50', '2021-11-11 12:18:50'),
(65, 'Toba Tek Singh', 'Toba Tek Singh', '30.96670000', '72.48330000', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '2021-11-11 12:18:50', '2021-11-11 12:18:50'),
(66, 'Shakargarh', 'Shakargarh', '32.26280000', '75.15830000', 'Pakistan', 'PK', 'PAK', 'Punjab', '', '2021-11-11 12:18:50', '2021-11-11 12:18:50'),
(67, 'Hujra Shah Muqim', 'Hujra Shah Muqim', '30.73330000', '73.81670000', 'Pakistan', 'PK', 'PAK', 'Punjab', '', '2021-11-11 12:18:50', '2021-11-11 12:18:50'),
(68, 'Kabirwala', 'Kabirwala', '30.40680000', '71.86670000', 'Pakistan', 'PK', 'PAK', 'Punjab', '', '2021-11-11 12:18:50', '2021-11-11 12:18:50'),
(69, 'Mansehra', 'Mansehra', '34.33330000', '73.20000000', 'Pakistan', 'PK', 'PAK', 'Khyber Pakhtunkhwa', 'minor', '2021-11-11 12:18:50', '2021-11-11 12:18:50'),
(70, 'Lala Musa', 'Lala Musa', '32.70120000', '73.96050000', 'Pakistan', 'PK', 'PAK', 'Punjab', '', '2021-11-11 12:18:50', '2021-11-11 12:18:50'),
(71, 'Nankana Sahib', 'Nankana Sahib', '31.44920000', '73.71240000', 'Pakistan', 'PK', 'PAK', 'Punjab', '', '2021-11-11 12:18:50', '2021-11-11 12:18:50'),
(72, 'Bannu', 'Bannu', '32.98890000', '70.60560000', 'Pakistan', 'PK', 'PAK', 'Khyber Pakhtunkhwa', 'minor', '2021-11-11 12:18:50', '2021-11-11 12:18:50'),
(73, 'Timargara', 'Timargara', '34.82810000', '71.84080000', 'Pakistan', 'PK', 'PAK', 'Khyber Pakhtunkhwa', 'minor', '2021-11-11 12:18:50', '2021-11-11 12:18:50'),
(74, 'Parachinar', 'Parachinar', '33.89920000', '70.10080000', 'Pakistan', 'PK', 'PAK', 'Khyber Pakhtunkhwa', '', '2021-11-11 12:18:50', '2021-11-11 12:18:50'),
(75, 'Abdul Hakim', 'Abdul Hakim', '30.55220000', '72.12780000', 'Pakistan', 'PK', 'PAK', 'Punjab', '', '2021-11-11 12:18:50', '2021-11-11 12:18:50'),
(76, 'Gwadar', 'Gwadar', '25.12640000', '62.32250000', 'Pakistan', 'PK', 'PAK', 'Balochistān', 'minor', '2021-11-11 12:18:50', '2021-11-11 12:18:50'),
(77, 'Hassan Abdal', 'Hassan Abdal', '33.81950000', '72.68900000', 'Pakistan', 'PK', 'PAK', 'Punjab', '', '2021-11-11 12:18:50', '2021-11-11 12:18:50'),
(78, 'Tank', 'Tank', '32.21670000', '70.38330000', 'Pakistan', 'PK', 'PAK', 'Khyber Pakhtunkhwa', 'minor', '2021-11-11 12:18:50', '2021-11-11 12:18:50'),
(79, 'Hangu', 'Hangu', '33.52810000', '71.05720000', 'Pakistan', 'PK', 'PAK', 'Khyber Pakhtunkhwa', 'minor', '2021-11-11 12:18:50', '2021-11-11 12:18:50'),
(80, 'Risalpur Cantonment', 'Risalpur Cantonment', '34.00490000', '71.99890000', 'Pakistan', 'PK', 'PAK', 'Khyber Pakhtunkhwa', '', '2021-11-11 12:18:50', '2021-11-11 12:18:50'),
(81, 'Karak', 'Karak', '33.11670000', '71.08330000', 'Pakistan', 'PK', 'PAK', 'Khyber Pakhtunkhwa', 'minor', '2021-11-11 12:18:50', '2021-11-11 12:18:50'),
(82, 'Kundian', 'Kundian', '32.45220000', '71.47180000', 'Pakistan', 'PK', 'PAK', 'Punjab', '', '2021-11-11 12:18:50', '2021-11-11 12:18:50'),
(83, 'Umarkot', 'Umarkot', '25.36140000', '69.73610000', 'Pakistan', 'PK', 'PAK', 'Sindh', 'minor', '2021-11-11 12:18:50', '2021-11-11 12:18:50'),
(84, 'Chitral', 'Chitral', '35.85110000', '71.78890000', 'Pakistan', 'PK', 'PAK', 'Khyber Pakhtunkhwa', 'minor', '2021-11-11 12:18:50', '2021-11-11 12:18:50'),
(85, 'Dainyor', 'Dainyor', '35.92060000', '74.37830000', 'Pakistan', 'PK', 'PAK', 'Gilgit-Baltistan', '', '2021-11-11 12:18:50', '2021-11-11 12:18:50'),
(86, 'Kulachi', 'Kulachi', '31.92860000', '70.45920000', 'Pakistan', 'PK', 'PAK', 'Khyber Pakhtunkhwa', '', '2021-11-11 12:18:50', '2021-11-11 12:18:50'),
(87, 'Kotli', 'Kotli', '33.51560000', '73.90190000', 'Pakistan', 'PK', 'PAK', 'Azad Kashmir', 'minor', '2021-11-11 12:18:50', '2021-11-11 12:18:50'),
(88, 'Murree', 'Murree', '33.90420000', '73.39030000', 'Pakistan', 'PK', 'PAK', 'Punjab', '', '2021-11-11 12:18:51', '2021-11-11 12:18:51'),
(89, 'Mithi', 'Mithi', '24.73330000', '69.80000000', 'Pakistan', 'PK', 'PAK', 'Sindh', '', '2021-11-11 12:18:51', '2021-11-11 12:18:51'),
(90, 'Gilgit', 'Gilgit', '35.92080000', '74.31440000', 'Pakistan', 'PK', 'PAK', 'Gilgit-Baltistan', 'minor', '2021-11-11 12:18:51', '2021-11-11 12:18:51');

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `client_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `user_id`, `client_id`, `created_at`, `updated_at`) VALUES
(1, 15, 17, '2021-12-16 11:35:52', '2021-12-16 11:35:52');

-- --------------------------------------------------------

--
-- Table structure for table `company_page_banners`
--

CREATE TABLE `company_page_banners` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `banner_image_path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `company_page_products`
--

CREATE TABLE `company_page_products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `display_section` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `inquiry_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `home_page_categories`
--

CREATE TABLE `home_page_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `display_section` enum('Top Bar','Middle Section') COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_order` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inventory_product_definitions`
--

CREATE TABLE `inventory_product_definitions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `product_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brand_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `purchase_unit` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `conversion_factor` int(11) NOT NULL DEFAULT 1,
  `product_group` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supplier` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_gender` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accquire_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value_addition` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `life_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `purchase_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `additional_attributes` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `technical_details` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `additional_description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `purchase_production_interval` int(11) NOT NULL DEFAULT 1,
  `purchase_production_unit` enum('days','months','years') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'days',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `inventory_product_definitions`
--

INSERT INTO `inventory_product_definitions` (`id`, `product_id`, `product_code`, `brand_name`, `purchase_unit`, `conversion_factor`, `product_group`, `supplier`, `product_gender`, `accquire_type`, `value_addition`, `life_type`, `tax_code`, `purchase_type`, `additional_attributes`, `technical_details`, `additional_description`, `purchase_production_interval`, `purchase_production_unit`, `created_at`, `updated_at`) VALUES
(1, 9, 'code', 'New Brand', 'kg', 1, 'casual use', 'common', 'common', 'manafactured', 'premium', '6 Months', 'djnak', 'local', 'out sourced', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', 52, 'days', '2021-11-26 11:50:50', '2021-11-26 11:50:50');

-- --------------------------------------------------------

--
-- Table structure for table `inventory_product_pricings`
--

CREATE TABLE `inventory_product_pricings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `total_units` decimal(8,2) NOT NULL,
  `price_per_unit` decimal(8,2) NOT NULL,
  `avg_cost_per_unit` decimal(8,2) NOT NULL,
  `sales_tax_percentage` decimal(8,2) NOT NULL DEFAULT 0.00,
  `allow_below_cost_sale` tinyint(1) NOT NULL DEFAULT 0,
  `allow_price_change` tinyint(1) NOT NULL DEFAULT 0,
  `discount_percentage` decimal(8,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `invitations`
--

CREATE TABLE `invitations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `token` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `invitations`
--

INSERT INTO `invitations` (`id`, `user_id`, `token`, `created_at`, `updated_at`) VALUES
(1, 2, '5392e415acc16ec4f4b31bda9614343d', '2021-11-13 10:26:03', '2021-11-13 10:26:03'),
(2, 3, '32cc3d407a4b5081fd92134891c505d1', '2021-11-13 10:29:36', '2021-11-13 10:29:36'),
(3, 17, 'd9556df496aa7976e7d6c2167d623624', '2021-12-16 11:35:40', '2021-12-16 11:35:40');

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

CREATE TABLE `invoices` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `number` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ref_invoice` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_date` datetime NOT NULL,
  `payment_due_date` datetime NOT NULL,
  `delivery_date` datetime NOT NULL,
  `seller_id` bigint(20) UNSIGNED NOT NULL,
  `seller_details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`seller_details`)),
  `buyer_id` bigint(20) UNSIGNED NOT NULL,
  `buyer_details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`buyer_details`)),
  `terms_and_conditions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`terms_and_conditions`)),
  `contact_email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `freight_charges` int(10) UNSIGNED DEFAULT NULL,
  `status` enum('due','partial_paid','paid','cancelled','refunded','expired') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'due',
  `is_shared` tinyint(1) NOT NULL DEFAULT 0,
  `is_shared_date` datetime DEFAULT NULL,
  `updated_by` bigint(20) UNSIGNED NOT NULL,
  `invoice_path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '/',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `invoice_attachments`
--

CREATE TABLE `invoice_attachments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `invoice_id` bigint(20) UNSIGNED NOT NULL,
  `type` enum('logo','purchase_order','delivery_receipt','shipment_receipt','signature','tax_certificate') COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `invoice_items`
--

CREATE TABLE `invoice_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `invoice_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int(11) NOT NULL,
  `quantity_unit` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rate` int(10) UNSIGNED NOT NULL,
  `gst` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `labels`
--

CREATE TABLE `labels` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `labels`
--

INSERT INTO `labels` (`id`, `title`, `created_at`, `updated_at`) VALUES
(1, 'Important', '2021-11-11 12:28:02', '2021-11-11 12:28:02'),
(2, 'Contacted', '2021-11-11 12:28:02', '2021-11-11 12:28:02'),
(3, 'Follow Up', '2021-11-11 12:28:03', '2021-11-11 12:28:03'),
(4, 'Deal Done', '2021-11-11 12:28:03', '2021-11-11 12:28:03'),
(5, 'Irrelevant', '2021-11-11 12:28:03', '2021-11-11 12:28:03'),
(6, 'Negotiation', '2021-11-11 12:28:03', '2021-11-11 12:28:03'),
(7, 'Quotation Sent', '2021-11-11 12:28:03', '2021-11-11 12:28:03');

-- --------------------------------------------------------

--
-- Table structure for table `lead_quotations`
--

CREATE TABLE `lead_quotations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `lead_id` bigint(20) UNSIGNED NOT NULL,
  `seller_id` bigint(20) UNSIGNED NOT NULL,
  `product` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` double NOT NULL,
  `unit` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `localities`
--

CREATE TABLE `localities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `city_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` bigint(20) UNSIGNED DEFAULT NULL,
  `coordinates` point NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `localities`
--

INSERT INTO `localities` (`id`, `city_id`, `name`, `parent_id`, `coordinates`, `created_at`, `updated_at`) VALUES
(3, 2, 'DHA PHASE 4', NULL, 0x000000000101000000986a662d05985240f767507e9c763f40, '2021-11-23 07:26:37', '2021-11-23 07:26:37'),
(4, 2, 'Sector AA', 3, 0x000000000101000000f9539918819752403b4b3558dd753f40, '2021-11-23 07:26:37', '2021-11-23 07:26:37'),
(5, 2, 'Sector BB', 3, 0x000000000101000000f9bce2a9c797524021600894a8763f40, '2021-11-23 07:26:37', '2021-11-23 07:26:37'),
(6, 2, 'New Garden Town', NULL, 0x00000000010100000059e9a4ad009452404a44f81741813f40, '2021-11-23 07:26:37', '2021-11-23 07:26:37'),
(7, 2, 'Ali Block', 6, 0x000000000101000000b586f7c19e945240272f3201bf803f40, '2021-11-23 07:26:37', '2021-11-23 07:26:37');

-- --------------------------------------------------------

--
-- Table structure for table `matter_sheets`
--

CREATE TABLE `matter_sheets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `file_path` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `is_cpa_approved` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `matter_sheet_products`
--

CREATE TABLE `matter_sheet_products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `matter_sheet_id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'category',
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` decimal(8,2) NOT NULL,
  `product_code` varchar(13) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `web_category` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brand_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approx_price` double(8,2) DEFAULT NULL,
  `currency_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `min_price` double(8,2) DEFAULT NULL,
  `max_price` double(8,2) DEFAULT NULL,
  `currency_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `min_order_quantity` double(8,2) DEFAULT NULL,
  `unit_measure_quantity` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supply_ability` double(8,2) DEFAULT NULL,
  `unit_measure_supply` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_cpa_approved` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2020_01_01_000001_create_plans_table', 1),
(2, '2020_01_01_000002_create_plan_features_table', 1),
(3, '2020_01_01_000003_create_plan_subscriptions_table', 1),
(4, '2020_01_01_000004_create_plan_subscription_usage_table', 1),
(5, '2021_07_19_125034_rename_morph_user_column_to_subscriber', 1),
(6, '2021_07_27_155427_alter_unique_key_plan_subscription_usage', 1),
(7, '2014_10_11_000000_create_cities_table', 2),
(8, '2014_10_11_000001_create_localities_table', 2),
(9, '2014_10_12_000000_create_users_table', 2),
(10, '2014_10_12_100000_create_password_resets_table', 2),
(11, '2014_10_12_200000_add_two_factor_columns_to_users_table', 2),
(12, '2018_12_23_120000_create_shoppingcart_table', 2),
(13, '2019_08_19_000000_create_failed_jobs_table', 2),
(14, '2019_12_14_000001_create_personal_access_tokens_table', 2),
(15, '2020_05_21_100000_create_teams_table', 2),
(16, '2020_05_21_200000_create_team_user_table', 2),
(17, '2020_07_12_000000_create_otps_table', 2),
(18, '2020_11_10_134345_create_categories_table', 2),
(19, '2020_11_10_134552_create_products_table', 2),
(20, '2020_11_10_134733_create_product_details_table', 2),
(21, '2020_11_10_134826_create_product_images_table', 2),
(22, '2020_11_10_134908_create_product_videos_table', 2),
(23, '2020_11_10_135003_create_product_documents_table', 2),
(24, '2020_11_10_193123_create_sessions_table', 2),
(25, '2020_11_16_171425_create_permission_tables', 2),
(26, '2020_12_07_175631_create_promocodes_table', 2),
(27, '2020_12_08_174615_create_user_product_interests_table', 2),
(28, '2020_12_10_172627_create_business_types_table', 2),
(29, '2020_12_10_181310_create_user_product_services_table', 2),
(30, '2020_12_16_141000_create_payment_methods_table', 2),
(31, '2020_12_16_182820_create_subscription_orders_table', 2),
(32, '2020_12_17_122556_create_business_details_table', 2),
(33, '2020_12_17_153420_create_additional_business_details_table', 2),
(34, '2020_12_17_172447_create_mode_of_payments_table', 2),
(35, '2020_12_17_174404_create_business_mode_of_payments_table', 2),
(36, '2020_12_17_191623_create_business_photos_table', 2),
(37, '2020_12_17_194633_create_transaction_logs_table', 2),
(38, '2020_12_23_181016_create_contact_us_table', 2),
(39, '2020_12_24_010320_create_business_contact_details_table', 2),
(40, '2020_12_26_130334_create_business_certifications_table', 2),
(41, '2020_12_28_110939_create_business_awards_table', 2),
(42, '2021_01_13_193018_create_subscription_payment_logs_table', 2),
(43, '2021_01_13_193718_create_subscription_payment_images_table', 2),
(44, '2021_01_19_130610_create_testimonials_table', 2),
(45, '2021_01_22_113453_create_property_types_table', 2),
(46, '2021_01_22_145434_create_warehouses_table', 2),
(47, '2021_01_22_172325_create_warehouse_feature_keys_table', 2),
(48, '2021_01_22_172718_create_warehouse_features_table', 2),
(49, '2021_01_26_133439_create_warehouse_images_table', 2),
(50, '2021_02_01_194922_create_warehouse_bookings_table', 2),
(51, '2021_02_11_175847_create_notifications_table', 2),
(52, '2021_02_19_121825_create_warehouse_related_loggings_table', 2),
(53, '2021_02_19_180418_create_booking_agreement_terms_table', 2),
(54, '2021_02_26_115711_create_payments_table', 2),
(55, '2021_03_10_194202_create_product_buy_requirements_table', 2),
(56, '2021_03_18_114025_create_chat_tables', 2),
(57, '2021_03_19_115858_create_lead_quotations_table', 2),
(58, '2021_04_02_132808_create_catalogs_table', 2),
(59, '2021_04_12_112751_create_chat_reminders_table', 2),
(60, '2021_04_12_130417_create_labels_table', 2),
(61, '2021_04_12_152548_create_chat_labels_table', 2),
(62, '2021_04_14_142107_create_user_favorites_table', 2),
(63, '2021_04_26_114819_create_quotation_requests_table', 2),
(64, '2021_04_27_133649_create_quotations_table', 2),
(65, '2021_04_27_141344_create_quotation_products_table', 2),
(66, '2021_04_27_142054_create_quotation_terms_table', 2),
(67, '2021_04_30_121905_add_is_active_to_users_table', 2),
(68, '2021_04_30_122332_create_invitations_table', 2),
(69, '2021_05_05_125249_create_quotation_seller_details_table', 2),
(70, '2021_05_06_122731_create_quotation_request_details_table', 2),
(71, '2021_05_06_143428_create_clients_table', 2),
(72, '2021_05_18_131622_create_advertisments_table', 2),
(73, '2021_05_25_140547_create_invoice_tables', 2),
(74, '2021_06_03_190626_create_home_page_categories_table', 2),
(75, '2021_06_18_161752_create_trending_categories_table', 2),
(76, '2021_06_18_181344_create_trending_products_table', 2),
(77, '2021_06_28_132644_create_purchase_orders_table', 2),
(78, '2021_06_29_115129_create_challans_table', 2),
(79, '2021_06_30_113152_create_popular_warehouses_table', 2),
(80, '2021_07_14_161628_create_badges_table', 2),
(81, '2021_07_14_165124_create_user_badges_table', 2),
(82, '2021_07_19_152210_add-featured-columns-products-table', 2),
(83, '2021_07_28_115331_add_invoices_received_colum_users_table', 2),
(84, '2021_07_28_163645_create_business_directors_table', 2),
(85, '2021_07_30_183340_add_is_shared_date_column_invoices', 2),
(86, '2021_08_05_153311_add_cnic_tax_related_verification_users_table', 2),
(87, '2021_08_06_173249_add_gst_decision_production_trading_company', 2),
(88, '2021_08_06_174933_add_designation_user', 2),
(89, '2021_08_06_175556_add_multiple_fields_additional_business_details', 2),
(90, '2021_08_09_161636_alter_product_price_column_set_0_as_default', 2),
(91, '2021_08_09_165000_create_inventory_product_definitions_table', 2),
(92, '2021_08_16_121635_create_inventory_product_pricings_table', 2),
(93, '2021_08_16_191539_create_matter_sheets_table', 2),
(94, '2021_08_17_182949_create_matter_sheet_products_table', 2),
(95, '2021_08_23_105225_add_quotation_path_column_quotation_table', 2),
(96, '2021_08_23_190056_add_index_on_parent_cat_id_categories_table', 2),
(97, '2021_08_31_132431_add_product_id_column_invoice_items_table', 2),
(98, '2021_09_01_174424_create_jobs_table', 2),
(99, '2021_09_01_192319_add_fields_product', 2),
(100, '2021_09_08_161399_create_notification_types_table', 2),
(101, '2021_09_08_161400_create_notifications_subscription_table', 2),
(102, '2021_09_10_153341_create_company_page_banners_table', 2),
(103, '2021_09_10_153553_create_company_page_products_table', 2),
(104, '2021_09_17_140053_create_promotional_products_table', 2),
(105, '2021_09_17_172730_remove_promotion_columns_inventory_product_pricings', 2),
(106, '2021_09_21_171833_create_purchase_returns_table', 2),
(107, '2021_09_23_175140_alter_column_order_no_purchase_order', 2),
(108, '2021_09_23_193550_alter_number_column_invoice', 2),
(109, '2021_09_28_190408_add_ref_invoice_field_in_invoices', 2),
(110, '2021_09_29_171048_alter_quantity_field_invoice_item', 2),
(111, '2021_09_24_114808_create_vehicles_table', 3),
(112, '2021_09_28_123942_create_booking_requests_table', 3),
(113, '2021_09_30_113000_create_drivers_table', 3),
(114, '2021_09_30_113001_create_driver_vehicles_table', 3),
(115, '2021_09_30_113848_create_ride_offers_table', 3),
(116, '2021_10_04_110926_create_driver_locations_table', 3),
(117, '2021_10_04_111607_create_accepted_rides_table', 3),
(118, '2021_10_04_111608_create_shipment_trackings_table', 3),
(119, '2021_10_04_175121_create_receipts_table', 3),
(120, '2021_10_04_183425_create_driver_feedback_table', 3),
(121, '2021_06_07_163352_create_category_view_stats_table', 4),
(122, '2021_06_07_163954_create_category_impression_stats_table', 4),
(123, '2021_06_07_174712_create_product_view_stats_table', 4),
(124, '2021_06_07_174843_create_product_impression_stats_table', 4),
(125, '2021_06_16_181404_create_product_contacted_stats_table', 4),
(126, '2021_06_30_112034_create_warehouse_impression_stats_table', 4),
(127, '2021_06_30_112445_create_warehouse_view_stats_table', 4),
(128, '2021_06_30_112907_create_warehouse_contacted_stats_table', 4),
(129, '2021_06_30_151230_create_general_stats_table', 4),
(130, '2021_10_21_160056_create_booking_consignments_table', 5);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\Models\\User', 4),
(2, 'App\\Models\\User', 5),
(3, 'App\\Models\\User', 6),
(3, 'App\\Models\\User', 8),
(3, 'App\\Models\\User', 9),
(3, 'App\\Models\\User', 10),
(3, 'App\\Models\\User', 11),
(3, 'App\\Models\\User', 12),
(3, 'App\\Models\\User', 13),
(3, 'App\\Models\\User', 14),
(3, 'App\\Models\\User', 15),
(4, 'App\\Models\\User', 1),
(4, 'App\\Models\\User', 7),
(4, 'App\\Models\\User', 16),
(6, 'App\\Models\\User', 2),
(6, 'App\\Models\\User', 3),
(6, 'App\\Models\\User', 17);

-- --------------------------------------------------------

--
-- Table structure for table `mode_of_payments`
--

CREATE TABLE `mode_of_payments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `mode_of_payment` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mode_of_payments`
--

INSERT INTO `mode_of_payments` (`id`, `mode_of_payment`, `created_at`, `updated_at`) VALUES
(1, 'Cash Against Delivery (CAD)', '2021-11-11 12:27:14', '2021-11-11 12:27:14'),
(2, 'Cash on Delivery (COD)', '2021-11-11 12:27:14', '2021-11-11 12:27:14'),
(3, 'Cash Advance (CA)', '2021-11-11 12:27:14', '2021-11-11 12:27:14'),
(4, 'Cash in Advance (CID)', '2021-11-11 12:27:14', '2021-11-11 12:27:14'),
(5, 'Cheque', '2021-11-11 12:27:14', '2021-11-11 12:27:14'),
(6, 'Days after Acceptance (DA)', '2021-11-11 12:27:14', '2021-11-11 12:27:14'),
(7, 'Delivery Point (DP)', '2021-11-11 12:27:14', '2021-11-11 12:27:14'),
(8, 'Letter of Credit (L/C)', '2021-11-11 12:27:14', '2021-11-11 12:27:14'),
(9, 'Letter of Credit at Sight (Sight L/C)', '2021-11-11 12:27:14', '2021-11-11 12:27:14'),
(10, 'Telegraphic Transfer (T/T)', '2021-11-11 12:27:14', '2021-11-11 12:27:14'),
(11, 'Western Union', '2021-11-11 12:27:14', '2021-11-11 12:27:14'),
(12, 'Paypal', '2021-11-11 12:27:14', '2021-11-11 12:27:14'),
(13, 'Others', '2021-11-11 12:27:14', '2021-11-11 12:27:14');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint(20) UNSIGNED NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notification_subscriptions`
--

CREATE TABLE `notification_subscriptions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `notification_type_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notification_types`
--

CREATE TABLE `notification_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notification_types`
--

INSERT INTO `notification_types` (`id`, `title`, `slug`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Stock Alerts', 'stock_alerts', 1, '2021-11-11 12:28:29', '2021-11-11 12:28:29'),
(2, 'invoice', 'invoice', 1, '2021-11-11 12:28:29', '2021-11-11 12:28:29'),
(3, 'quotation', 'quotation', 1, '2021-11-11 12:28:29', '2021-11-11 12:28:29');

-- --------------------------------------------------------

--
-- Table structure for table `otps`
--

CREATE TABLE `otps` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `client_req_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `otp` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `retry` tinyint(4) NOT NULL,
  `status` enum('new','used','expired') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `otps`
--

INSERT INTO `otps` (`id`, `client_req_id`, `number`, `email`, `type`, `otp`, `uuid`, `retry`, `status`, `created_at`, `updated_at`) VALUES
(1, '1', '+923087742186', 'asadbala41@gmail.com', 'verify-phone', '648398', '2cca7c5ae174fbf5d569d4a5e41c0d96', 0, 'new', '2021-11-11 12:19:52', '2021-11-11 12:19:52'),
(2, '4', '+923012345678', 'super.admin@emandii.com', 'verify-phone', '833312', '72a3143b62578053a9ba02007f91451a', 0, 'new', '2021-11-22 09:02:40', '2021-11-22 09:02:40'),
(3, '6', '551.843.9313', 'block.madaline@example.org', 'verify-phone', '450070', '475654af3fd6e3537a6b2a20582caa65', 1, 'new', '2021-11-22 16:44:01', '2021-11-22 16:44:31'),
(4, '16', '+923087542186', 'asadbala51@gmail.com', 'verify-phone', '857891', 'f4201ebe2fce6cf46df83a695179f0d4', 0, 'new', '2021-11-22 18:53:37', '2021-11-22 18:53:37'),
(5, '5', '+923012345679', 'admin@emandii.com', 'verify-phone', '746182', '5b6d31d0a811c6a1fce16bb85ba65cb2', 0, 'new', '2021-11-23 07:19:41', '2021-11-23 07:19:41');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL,
  `amount` double NOT NULL,
  `transaction_date` date NOT NULL,
  `payment_method_id` bigint(20) UNSIGNED NOT NULL,
  `bank_account_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ref_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_text` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_image_document` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_status` enum('pending','paid','cancelled','refunded','received') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `is_closed` tinyint(1) NOT NULL DEFAULT 0,
  `updated_by` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment_methods`
--

CREATE TABLE `payment_methods` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_online` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payment_methods`
--

INSERT INTO `payment_methods` (`id`, `name`, `is_online`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Cash Against Delivery (CAD)', 0, 1, NULL, NULL, NULL),
(2, 'Cash on Delivery (COD)', 0, 1, NULL, NULL, NULL),
(3, 'Cash Advance (CA)', 1, 1, NULL, NULL, NULL),
(4, 'Cash in Advance (CID)', 1, 1, NULL, NULL, NULL),
(5, 'Cheque', 0, 1, NULL, NULL, NULL),
(6, 'Days after Acceptance (DA)', 0, 1, NULL, NULL, NULL),
(7, 'Delivery Point (DP)', 0, 1, NULL, NULL, NULL),
(8, 'Letter of Credit (L/C)', 1, 1, NULL, NULL, NULL),
(9, 'Letter of Credit at Sight (Sight L/C)', 0, 1, NULL, NULL, NULL),
(10, 'Telegraphic Transfer (T/T)', 1, 1, NULL, NULL, NULL),
(11, 'Western Union', 1, 1, NULL, NULL, NULL),
(12, 'Paypal', 1, 1, NULL, NULL, NULL),
(13, 'Others', 0, 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `plans`
--

CREATE TABLE `plans` (
  `id` int(10) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `price` decimal(8,2) NOT NULL DEFAULT 0.00,
  `signup_fee` decimal(8,2) NOT NULL DEFAULT 0.00,
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `trial_period` smallint(5) UNSIGNED NOT NULL DEFAULT 0,
  `trial_interval` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'day',
  `invoice_period` smallint(5) UNSIGNED NOT NULL DEFAULT 0,
  `invoice_interval` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'month',
  `grace_period` smallint(5) UNSIGNED NOT NULL DEFAULT 0,
  `grace_interval` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'day',
  `prorate_day` tinyint(3) UNSIGNED DEFAULT NULL,
  `prorate_period` tinyint(3) UNSIGNED DEFAULT NULL,
  `prorate_extend_due` tinyint(3) UNSIGNED DEFAULT NULL,
  `active_subscribers_limit` smallint(5) UNSIGNED DEFAULT NULL,
  `sort_order` mediumint(8) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `plans`
--

INSERT INTO `plans` (`id`, `slug`, `name`, `description`, `is_active`, `price`, `signup_fee`, `currency`, `trial_period`, `trial_interval`, `invoice_period`, `invoice_interval`, `grace_period`, `grace_interval`, `prorate_day`, `prorate_period`, `prorate_extend_due`, `active_subscribers_limit`, `sort_order`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'gold', '{\"en\":\"Gold\"}', '{\"en\":\"Gold plan\"}', 1, '2000.00', '0.00', 'PKR', 0, 'day', 1, 'month', 0, 'day', NULL, NULL, NULL, NULL, 1, '2021-11-11 12:26:27', '2021-11-11 12:26:27', NULL),
(2, 'silver', '{\"en\":\"Silver\"}', '{\"en\":\"Silver plan\"}', 1, '1500.00', '0.00', 'PKR', 0, 'day', 1, 'month', 0, 'day', NULL, NULL, NULL, NULL, 2, '2021-11-11 12:26:28', '2021-11-11 12:26:28', NULL),
(3, 'bronze', '{\"en\":\"Bronze\"}', '{\"en\":\"Bronze plan\"}', 1, '1000.00', '0.00', 'PKR', 0, 'day', 1, 'month', 0, 'day', NULL, NULL, NULL, NULL, 3, '2021-11-11 12:26:28', '2021-11-11 12:26:28', NULL),
(4, 'bonus-features-gold', '{\"en\":\"Bonus Features Gold\"}', '{\"en\":\"Additional Bonus Features Gold\"}', 1, '0.00', '0.00', 'PKR', 0, 'day', 1, 'month', 0, 'day', NULL, NULL, NULL, NULL, 4, '2021-11-11 12:26:29', '2021-11-11 12:26:29', NULL),
(5, 'bonus-features-silver', '{\"en\":\"Bonus Features Silver\"}', '{\"en\":\"Additional Bonus Features Silver\"}', 1, '0.00', '0.00', 'PKR', 0, 'day', 1, 'month', 0, 'day', NULL, NULL, NULL, NULL, 5, '2021-11-11 12:26:29', '2021-11-11 12:26:29', NULL),
(6, 'bonus-features-bronze', '{\"en\":\"Bonus Features Bronze\"}', '{\"en\":\"Additional Bonus Features Bronze\"}', 1, '0.00', '0.00', 'PKR', 0, 'day', 1, 'month', 0, 'day', NULL, NULL, NULL, NULL, 6, '2021-11-11 12:26:29', '2021-11-11 12:26:29', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `plan_features`
--

CREATE TABLE `plan_features` (
  `id` int(10) UNSIGNED NOT NULL,
  `plan_id` int(10) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `resettable_period` smallint(5) UNSIGNED NOT NULL DEFAULT 0,
  `resettable_interval` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'month',
  `sort_order` mediumint(8) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `plan_features`
--

INSERT INTO `plan_features` (`id`, `plan_id`, `slug`, `name`, `description`, `value`, `resettable_period`, `resettable_interval`, `sort_order`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 'emails_gold', '{\"en\":\"emails\"}', NULL, '50', 1, 'month', 1, '2021-11-11 12:26:27', '2021-11-11 12:26:27', NULL),
(2, 1, 'sms_gold', '{\"en\":\"sms\"}', NULL, '50', 1, 'month', 2, '2021-11-11 12:26:27', '2021-11-11 12:26:27', NULL),
(3, 1, 'leads_gold', '{\"en\":\"leads\"}', NULL, '50', 1, 'month', 3, '2021-11-11 12:26:28', '2021-11-11 12:26:28', NULL),
(4, 1, 'no_of_products_gold', '{\"en\":\"no_of_products\"}', NULL, '50', 1, 'month', 4, '2021-11-11 12:26:28', '2021-11-11 12:26:28', NULL),
(5, 1, 'featured_products_gold', '{\"en\":\"featured_products\"}', NULL, '50', 1, 'month', 5, '2021-11-11 12:26:28', '2021-11-11 12:26:28', NULL),
(6, 1, 'can_add_additional_detail_photos_gold', '{\"en\":\"can_add_additional_detail_photos\"}', NULL, '1', 1, 'month', 6, '2021-11-11 12:26:28', '2021-11-11 12:26:28', NULL),
(7, 1, 'can_add_certificates_n_awards_gold', '{\"en\":\"can_add_certificates_n_awards\"}', NULL, '1', 1, 'month', 7, '2021-11-11 12:26:28', '2021-11-11 12:26:28', NULL),
(8, 1, 'can_view_buying_selling_analytics_gold', '{\"en\":\"can_view_buying_selling_analytics\"}', NULL, '1', 1, 'month', 8, '2021-11-11 12:26:28', '2021-11-11 12:26:28', NULL),
(9, 1, 'can_add_director_profile_gold', '{\"en\":\"can_add_director_profile\"}', NULL, '1', 1, 'month', 9, '2021-11-11 12:26:28', '2021-11-11 12:26:28', NULL),
(10, 1, 'company_banner_products_gold', '{\"en\":\"company_banner_products\"}', NULL, '10', 1, 'month', 10, '2021-11-11 12:26:28', '2021-11-11 12:26:28', NULL),
(11, 1, 'company_top_products_gold', '{\"en\":\"company_top_products\"}', NULL, '10', 1, 'month', 11, '2021-11-11 12:26:28', '2021-11-11 12:26:28', NULL),
(12, 2, 'emails_silver', '{\"en\":\"emails\"}', NULL, '25', 1, 'month', 12, '2021-11-11 12:26:28', '2021-11-11 12:26:28', NULL),
(13, 2, 'sms_silver', '{\"en\":\"sms\"}', NULL, '25', 1, 'month', 13, '2021-11-11 12:26:28', '2021-11-11 12:26:28', NULL),
(14, 2, 'leads_silver', '{\"en\":\"leads\"}', NULL, '25', 1, 'month', 14, '2021-11-11 12:26:28', '2021-11-11 12:26:28', NULL),
(15, 2, 'no_of_products_silver', '{\"en\":\"no_of_products\"}', NULL, '25', 1, 'month', 15, '2021-11-11 12:26:28', '2021-11-11 12:26:28', NULL),
(16, 2, 'featured_products_silver', '{\"en\":\"featured_products\"}', NULL, '25', 1, 'month', 16, '2021-11-11 12:26:28', '2021-11-11 12:26:28', NULL),
(17, 2, 'can_add_additional_detail_photos_silver', '{\"en\":\"can_add_additional_detail_photos\"}', NULL, '1', 1, 'month', 17, '2021-11-11 12:26:28', '2021-11-11 12:26:28', NULL),
(18, 2, 'can_add_certificates_n_awards_silver', '{\"en\":\"can_add_certificates_n_awards\"}', NULL, '1', 1, 'month', 18, '2021-11-11 12:26:28', '2021-11-11 12:26:28', NULL),
(19, 2, 'company_banner_products_silver', '{\"en\":\"company_banner_products\"}', NULL, '5', 1, 'month', 19, '2021-11-11 12:26:28', '2021-11-11 12:26:28', NULL),
(20, 2, 'company_top_products_silver', '{\"en\":\"company_top_products\"}', NULL, '5', 1, 'month', 20, '2021-11-11 12:26:28', '2021-11-11 12:26:28', NULL),
(21, 3, 'emails_bronze', '{\"en\":\"emails\"}', NULL, '10', 1, 'month', 21, '2021-11-11 12:26:28', '2021-11-11 12:26:28', NULL),
(22, 3, 'sms_bronze', '{\"en\":\"sms\"}', NULL, '10', 1, 'month', 22, '2021-11-11 12:26:28', '2021-11-11 12:26:28', NULL),
(23, 3, 'leads_bronze', '{\"en\":\"leads\"}', NULL, '10', 1, 'month', 23, '2021-11-11 12:26:28', '2021-11-11 12:26:28', NULL),
(24, 3, 'no_of_products_bronze', '{\"en\":\"no_of_products\"}', NULL, '4', 1, 'month', 24, '2021-11-11 12:26:29', '2021-11-11 12:26:29', NULL),
(25, 3, 'featured_products_bronze', '{\"en\":\"featured_products\"}', NULL, '4', 1, 'month', 25, '2021-11-11 12:26:29', '2021-11-11 12:26:29', NULL),
(26, 3, 'can_add_additional_detail_photos_bronze', '{\"en\":\"can_add_additional_detail_photos\"}', NULL, '1', 1, 'month', 26, '2021-11-11 12:26:29', '2021-11-11 12:26:29', NULL),
(27, 3, 'can_add_certificates_n_awards_bronze', '{\"en\":\"can_add_certificates_n_awards\"}', NULL, '1', 1, 'month', 27, '2021-11-11 12:26:29', '2021-11-11 12:26:29', NULL),
(28, 3, 'company_banner_products_bronze', '{\"en\":\"company_banner_products\"}', NULL, '3', 1, 'month', 28, '2021-11-11 12:26:29', '2021-11-11 12:26:29', NULL),
(29, 3, 'company_top_products_bronze', '{\"en\":\"company_top_products\"}', NULL, '3', 1, 'month', 29, '2021-11-11 12:26:29', '2021-11-11 12:26:29', NULL),
(30, 4, 'leads_bonus-features-gold', '{\"en\":\"leads\"}', NULL, '10', 1, 'day', 30, '2021-11-11 12:26:29', '2021-11-11 12:26:29', NULL),
(31, 5, 'leads_bonus-features-silver', '{\"en\":\"leads\"}', NULL, '5', 1, 'day', 31, '2021-11-11 12:26:29', '2021-11-11 12:26:29', NULL),
(32, 6, 'leads_bonus-features-bronze', '{\"en\":\"leads\"}', NULL, '1', 1, 'day', 32, '2021-11-11 12:26:29', '2021-11-11 12:26:29', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `plan_subscriptions`
--

CREATE TABLE `plan_subscriptions` (
  `id` int(10) UNSIGNED NOT NULL,
  `subscriber_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subscriber_id` bigint(20) UNSIGNED NOT NULL,
  `plan_id` int(10) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trial_ends_at` datetime DEFAULT NULL,
  `starts_at` datetime DEFAULT NULL,
  `ends_at` datetime DEFAULT NULL,
  `cancels_at` datetime DEFAULT NULL,
  `canceled_at` datetime DEFAULT NULL,
  `timezone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `plan_subscriptions`
--

INSERT INTO `plan_subscriptions` (`id`, `subscriber_type`, `subscriber_id`, `plan_id`, `slug`, `name`, `description`, `trial_ends_at`, `starts_at`, `ends_at`, `cancels_at`, `canceled_at`, `timezone`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'App\\Models\\User', 1, 1, 'leads', '{\"en\":\"leads\"}', NULL, '2021-11-23 13:48:35', '2021-11-23 13:48:35', '2021-12-23 13:48:35', NULL, NULL, NULL, '2021-11-23 08:48:35', '2021-11-23 08:48:35', NULL),
(2, 'App\\Models\\User', 7, 1, 'leads-1', '{\"en\":\"leads\"}', NULL, '2021-11-24 23:14:15', '2021-11-24 23:14:15', '2021-12-24 23:14:15', NULL, NULL, NULL, '2021-11-24 18:14:15', '2021-11-24 18:14:15', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `plan_subscription_usage`
--

CREATE TABLE `plan_subscription_usage` (
  `id` int(10) UNSIGNED NOT NULL,
  `subscription_id` int(10) UNSIGNED NOT NULL,
  `feature_id` int(10) UNSIGNED NOT NULL,
  `used` smallint(5) UNSIGNED NOT NULL,
  `valid_until` datetime DEFAULT NULL,
  `timezone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `plan_subscription_usage`
--

INSERT INTO `plan_subscription_usage` (`id`, `subscription_id`, `feature_id`, `used`, `valid_until`, `timezone`, `created_at`, `updated_at`, `deleted_at`) VALUES
(3, 1, 3, 3, '2021-12-23 13:48:35', NULL, '2021-11-24 11:41:42', '2021-12-07 08:20:33', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `popular_warehouses`
--

CREATE TABLE `popular_warehouses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `warehouse_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'category',
  `product_code` varchar(13) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `web_category` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brand_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approx_price` double(8,2) DEFAULT NULL,
  `currency_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `min_price` double(8,2) DEFAULT NULL,
  `max_price` double(8,2) DEFAULT NULL,
  `currency_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `min_order_quantity` double(8,2) DEFAULT NULL,
  `unit_measure_quantity` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supply_ability` double(8,2) DEFAULT NULL,
  `unit_measure_supply` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` decimal(8,2) NOT NULL DEFAULT 0.00,
  `is_featured` tinyint(1) NOT NULL DEFAULT 0,
  `on_sale` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category_id`, `category`, `product_code`, `web_category`, `brand_name`, `approx_price`, `currency_1`, `min_price`, `max_price`, `currency_2`, `min_order_quantity`, `unit_measure_quantity`, `supply_ability`, `unit_measure_supply`, `user_id`, `title`, `description`, `price`, `is_featured`, `on_sale`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 3, 'Laptops', '123456', 'web category', 'brand name', 123.00, 'RS', 12.00, 123.00, 'CAD', 10.00, '1', 5.00, '2', 1, 'title of product', '<p>this is the sort description of this product</p>', '100.00', 0, 0, '2021-11-13 09:05:23', '2021-11-24 19:17:35', NULL),
(2, 1, 'Electronics', '123456', 'web category2', 'brand name2', 123.00, 'RS', 12.00, 123.00, 'CAD', 10.00, '1', 5.00, '2', 1, 'title of product 2', 'this is the sort description of this product', '100.00', 0, 0, '2021-11-13 09:05:23', '2021-11-26 11:52:33', NULL),
(3, 2, 'Medical Equipments', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'title', '<p>this is description</p>', '2500.00', 0, 0, '2021-11-23 08:58:40', '2021-12-04 17:40:02', NULL),
(4, 3, 'Laptops', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'title', '<p>this is product description</p>', '123.00', 0, 0, '2021-11-24 08:55:56', '2021-11-24 08:55:56', NULL),
(5, 2, 'Medical Equipments', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'title asidknfa l', '<p>zkjsdn fljsndj fvp;sjdm fasld</p>', '2500.00', 0, 0, '2021-11-24 18:24:57', '2021-11-24 18:24:57', NULL),
(6, 2, 'Medical Equipments', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'this  is new product', '<p>this is description</p>', '2500.00', 0, 0, '2021-11-25 06:13:40', '2021-11-25 06:13:40', NULL),
(9, 5, 'category', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'name', NULL, '0.00', 0, 0, '2021-11-26 11:50:50', '2021-11-26 11:50:50', NULL),
(10, 2, 'Medical Equipments', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'kdjfni', '<p>nvisdfj i</p>', '213.00', 0, 0, '2021-12-04 08:39:10', '2021-12-04 08:39:10', NULL),
(11, 2, 'Medical Equipments', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'skdfjn', '<p>lskdn fgl</p>', '23.00', 0, 0, '2021-12-04 17:50:23', '2021-12-04 17:50:23', NULL),
(12, 5, 'sub mobile', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'this is city pictures', '<p>this is description</p>', '123456.00', 0, 0, '2021-12-07 08:15:19', '2021-12-07 08:15:19', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product_buy_requirements`
--

CREATE TABLE `product_buy_requirements` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `category_ids` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `required_product` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_path` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `requirement_details` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` decimal(8,2) NOT NULL,
  `unit` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `budget` double DEFAULT NULL,
  `requirement_urgency` enum('immediate','after one month') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `requirement_frequency` enum('one time','regular') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supplier_location` enum('local','any where in pakistan') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'any where in pakistan',
  `terms_and_conditions` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_buy_requirements`
--

INSERT INTO `product_buy_requirements` (`id`, `user_id`, `category_ids`, `required_product`, `image_path`, `requirement_details`, `quantity`, `unit`, `budget`, `requirement_urgency`, `requirement_frequency`, `supplier_location`, `terms_and_conditions`, `created_at`, `updated_at`) VALUES
(6, 1, '2', 'this is product', NULL, 'jasddfk', '10.00', '10', 1000, 'immediate', 'one time', 'any where in pakistan', 0, '2021-11-24 18:07:26', NULL),
(7, 1, '2', 'this is product', NULL, 'jasddfk', '10.00', '10', 1000, 'immediate', 'one time', 'any where in pakistan', 0, '2021-11-24 18:07:26', NULL),
(8, 8, '2', 'this is product', NULL, 'jasddfk', '10.00', '10', 1000, 'immediate', 'one time', 'any where in pakistan', 0, '2021-11-24 18:07:26', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product_details`
--

CREATE TABLE `product_details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_details`
--

INSERT INTO `product_details` (`id`, `product_id`, `key`, `value`, `created_at`, `updated_at`) VALUES
(1, 3, 'abcKeyks', 'Vale', '2021-11-23 08:58:41', '2021-12-04 17:40:02'),
(2, 4, 'abcKey', 'Vale', '2021-11-24 08:55:56', '2021-11-24 08:55:56'),
(3, 5, 'abcKey', 'Vale', '2021-11-24 18:24:58', '2021-11-24 18:24:58'),
(4, 6, 'abcKey', 'Vale', '2021-11-25 06:13:40', '2021-11-25 06:13:40'),
(5, 10, 'abcKey', 'Vale', '2021-12-04 08:39:10', '2021-12-04 08:39:10'),
(6, 11, 'abcKey', 'Vale', '2021-12-04 17:50:23', '2021-12-04 17:50:23'),
(7, 12, 'abcKey', 'Vale', '2021-12-07 08:15:19', '2021-12-07 08:15:19');

-- --------------------------------------------------------

--
-- Table structure for table `product_documents`
--

CREATE TABLE `product_documents` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_documents`
--

INSERT INTO `product_documents` (`id`, `product_id`, `title`, `path`, `created_at`, `updated_at`) VALUES
(1, 3, 'Positive-Life-Goes-On-Quotes.jpg', 'product/documents/1639810618-ZH1Q-product-document.jpg', '2021-12-18 06:56:58', '2021-12-18 06:56:58'),
(2, 3, '1639639442-fl6O-profile-picture.jfif', 'product/documents/1639810634-m6D2-product-document.jfif', '2021-12-18 06:57:14', '2021-12-18 06:57:14'),
(3, 3, '1639718741-oRyS-category.png', 'product/documents/1639815801-qtTE-product-document.png', '2021-12-18 08:23:21', '2021-12-18 08:23:21');

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

CREATE TABLE `product_images` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_main` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_images`
--

INSERT INTO `product_images` (`id`, `product_id`, `title`, `path`, `is_main`, `created_at`, `updated_at`) VALUES
(2, 3, 'pakistn.jpg', 'public/product/images/EYxjsM9Qsu96yzBw1N9ksRxkkxkLWdgxrVSpJoy1.jpg', 0, '2021-11-23 08:58:40', '2021-11-23 08:58:40'),
(3, 3, 'saudi arabia.jpg', 'public/product/images/l0xdnrtzORPYiWuIGD8GDIfR6CQZUAviiOEFSvTF.jpg', 0, '2021-11-23 08:58:40', '2021-11-23 08:58:40'),
(4, 4, 'pakistn.jpg', 'public/product/images/SkE1kDEe00AXKm0hyDQijlE5mCcrjViSzQC1VLQ8.jpg', 1, '2021-11-24 08:55:56', '2021-11-24 08:55:56'),
(5, 4, 'saudi arabia.jpg', 'public/product/images/FYwYBMTz3VToisepfVxkhYwWascvO0CMuwXj5FjA.jpg', 0, '2021-11-24 08:55:56', '2021-11-24 08:55:56'),
(6, 5, 'pakistn.jpg', 'public/product/images/n6h6VGr7a7zkJnYymjtgL4eVvWFenReOtexR5hT3.jpg', 1, '2021-11-24 18:24:57', '2021-11-24 18:24:57'),
(7, 5, 'saudi arabia.jpg', 'public/product/images/eK3JUAhv2oJ21sIIECkvAuNsbbLxaHTC2F1ZuIvQ.jpg', 0, '2021-11-24 18:24:57', '2021-11-24 18:24:57'),
(8, 5, 'screencapture-mail-google-mail-u-0-2021-11-24-13_26_22.png', 'public/product/images/sKW8ysbmpW9BjfRYLEJJkPk7iDD7zcjKSdnUI8l1.png', 0, '2021-11-24 18:24:57', '2021-11-24 18:24:57'),
(9, 6, 'pakistn.jpg', 'public/product/images/cWhR90M4Tsf08RuIcp2A6XAW7abY8oDEk6DAVVi2.jpg', 1, '2021-11-25 06:13:40', '2021-11-25 06:13:40'),
(10, 6, 'saudi arabia.jpg', 'public/product/images/BDLWDWcuRchytpV534tDMSTWDhisFhH8qnmZp8vB.jpg', 0, '2021-11-25 06:13:40', '2021-11-25 06:13:40'),
(11, 6, 'screencapture-mail-google-mail-u-0-2021-11-24-13_26_22.png', 'public/product/images/abwXacYchCix9mkeh0iOuhWuTrfDrPCtRsEPpFHg.png', 0, '2021-11-25 06:13:40', '2021-11-25 06:13:40'),
(14, 9, 'pakistn.jpg', 'public/product/images/Hr9qFyI0UZw3etqTOXBjQCGX9Bz2M26QjOXBdApD.jpg', 1, '2021-11-26 11:50:50', '2021-11-26 11:50:50'),
(15, 10, 'saudi arabia.jpg', 'public/product/images/H9w12uOFUfuTl1SxtvbEVgO0wBnsdNUiJTfM2clE.jpg', 1, '2021-12-04 08:39:10', '2021-12-04 08:45:45'),
(16, 11, 'pakistn.jpg', 'public/product/images/6ufbuwsIF22OBbn5HbBdnf0LusrOJzmWGSRxCjzA.jpg', 1, '2021-12-04 17:50:23', '2021-12-04 17:50:23'),
(17, 12, 'Cities_City_at_night.jpg', 'public/product/images/MOPUbp9bf0KE5EwQkVJojP7xa1xch8ON3sS4JyxG.jpg', 1, '2021-12-07 08:15:19', '2021-12-07 08:15:19'),
(18, 12, 'Cities_Evening_Manhattan_New_York.jpg', 'public/product/images/jWgb0vYu3FbFTikeKwwIulj6v3vHkjessodwNKBi.jpg', 0, '2021-12-07 08:15:19', '2021-12-07 08:15:19'),
(19, 12, 'Cities_Formula_1_night_in_Monaco.jpg', 'public/product/images/AO5aWzALVATj9VJS5glC4s84H5cjJz8fs2bTiwie.jpg', 0, '2021-12-07 08:15:19', '2021-12-07 08:15:19'),
(20, 12, 'Cities_Kuala_Lumpur_Malaysia.jpg', 'public/product/images/7tBh3dHLAGsmuT9l0mjqX0EaQvZJlLapLqpWJStM.jpg', 0, '2021-12-07 08:15:19', '2021-12-07 08:15:19'),
(21, 12, 'Cities_London__View_of_Tower_Bridge.jpg', 'public/product/images/FqpCgH1t3VvpYvi21zMhiTc4nHvMxvNkVxg95Bdz.jpg', 0, '2021-12-07 08:15:19', '2021-12-07 08:15:19');

-- --------------------------------------------------------

--
-- Table structure for table `product_videos`
--

CREATE TABLE `product_videos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `host` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `promocodes`
--

CREATE TABLE `promocodes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `code` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reward` double(10,2) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `data` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_disposable` tinyint(1) NOT NULL DEFAULT 0,
  `expires_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `promocodes`
--

INSERT INTO `promocodes` (`id`, `code`, `reward`, `quantity`, `data`, `is_disposable`, `expires_at`) VALUES
(1, '36K-QS6', 100.00, NULL, '{\"is_fixed\":true}', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `promocode_user`
--

CREATE TABLE `promocode_user` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `promocode_id` bigint(20) UNSIGNED NOT NULL,
  `used_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `promotional_products`
--

CREATE TABLE `promotional_products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `promotional_product_id` bigint(20) UNSIGNED DEFAULT NULL,
  `discount_percentage` decimal(8,2) DEFAULT NULL,
  `by_date` tinyint(1) NOT NULL DEFAULT 0,
  `by_no_of_units` tinyint(1) NOT NULL DEFAULT 0,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `no_of_units` int(10) UNSIGNED DEFAULT NULL,
  `remaining_no_of_units` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `property_types`
--

CREATE TABLE `property_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `property_types`
--

INSERT INTO `property_types` (`id`, `title`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Sheltered', '2021-11-11 12:28:53', '2021-11-11 12:28:53', NULL),
(2, 'Shop', '2021-11-11 12:28:53', '2021-11-11 12:28:53', NULL),
(3, 'Apartment', '2021-11-11 12:28:53', '2021-11-11 12:28:53', NULL),
(4, 'Plaza', '2021-11-11 12:28:53', '2021-11-11 12:28:53', NULL),
(5, 'Single Storey', '2021-11-11 12:28:53', '2021-11-11 12:28:53', NULL),
(6, 'Double Storey', '2021-11-11 12:28:53', '2021-11-11 12:28:53', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_orders`
--

CREATE TABLE `purchase_orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `number` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `po_date` datetime NOT NULL,
  `po_delivery_date` datetime NOT NULL,
  `attachment` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_details` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `purchase_order_path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '/',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `purchase_orders`
--

INSERT INTO `purchase_orders` (`id`, `number`, `po_date`, `po_delivery_date`, `attachment`, `order_description`, `payment_details`, `created_by`, `purchase_order_path`, `created_at`, `updated_at`) VALUES
(2, '1637658827', '2021-11-23 00:00:00', '2021-11-25 14:11:00', 'public/khata/purchase-order/attachments/B0Zyje2KFR50bNhyKPv6J6pjvC6gcANXch87vo8B.jpg', ';kjasdni;fasj', 'msnpdj', 1, 'public/khata/purchase-order/1637658827.pdf', '2021-11-23 09:13:47', '2021-11-23 09:13:48'),
(3, '2', '2021-11-23 00:00:00', '2021-11-26 14:14:00', 'public/khata/purchase-order/attachments/Sxi1oEkbqzTiFNcsXyCVUkqF2kbbaSEqwy9qPlCj.jpg', 'PO Details', 'Payment Details', 1, 'public/khata/purchase-order/1637658877.pdf', '2021-11-23 09:14:37', '2021-11-23 09:14:37');

-- --------------------------------------------------------

--
-- Table structure for table `purchase_returns`
--

CREATE TABLE `purchase_returns` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `product_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `return_quantity` int(11) NOT NULL,
  `return_amount` double(8,2) NOT NULL,
  `purchase_order_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoice_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('Pending','Approved','Declined') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pending',
  `comments` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `is_return_product` tinyint(1) NOT NULL DEFAULT 0,
  `product_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `quotations`
--

CREATE TABLE `quotations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `seller_id` bigint(20) UNSIGNED NOT NULL,
  `buyer_id` bigint(20) UNSIGNED NOT NULL,
  `quotation_request_id` bigint(20) UNSIGNED DEFAULT NULL,
  `quotation_path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `quotations`
--

INSERT INTO `quotations` (`id`, `seller_id`, `buyer_id`, `quotation_request_id`, `quotation_path`, `created_at`, `updated_at`) VALUES
(1, 1, 1, NULL, 'public/quotations/1637754093.pdf', '2021-11-24 11:41:43', '2021-11-24 11:41:43'),
(2, 1, 7, NULL, 'public/quotations/1637754273.pdf', '2021-11-24 11:44:34', '2021-11-24 11:44:34'),
(3, 1, 7, NULL, 'public/quotations/1637754367.pdf', '2021-11-24 11:46:09', '2021-11-24 11:46:09'),
(4, 1, 7, NULL, 'public/quotations/1638638707.pdf', '2021-12-04 17:25:09', '2021-12-04 17:25:09'),
(5, 1, 7, NULL, 'public/quotations/1638865044.pdf', '2021-12-07 08:17:26', '2021-12-07 08:17:26'),
(6, 1, 8, NULL, 'public/quotations/1638865232.pdf', '2021-12-07 08:20:34', '2021-12-07 08:20:34'),
(7, 1, 7, NULL, 'public/quotations/1639128133.pdf', '2021-12-10 09:22:15', '2021-12-10 09:22:15');

-- --------------------------------------------------------

--
-- Table structure for table `quotation_products`
--

CREATE TABLE `quotation_products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `quotation_id` bigint(20) UNSIGNED NOT NULL,
  `product` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_path` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` decimal(8,2) NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `unit` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `quotation_products`
--

INSERT INTO `quotation_products` (`id`, `quotation_id`, `product`, `image_path`, `quantity`, `price`, `unit`, `description`, `created_at`, `updated_at`) VALUES
(5, 1, 'this is quotation product', NULL, '10.00', '50.00', '10', 'description', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `quotation_requests`
--

CREATE TABLE `quotation_requests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `seller_id` bigint(20) UNSIGNED NOT NULL,
  `buyer_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `quotation_requests`
--

INSERT INTO `quotation_requests` (`id`, `seller_id`, `buyer_id`, `created_at`, `updated_at`) VALUES
(1, 1, 6, '2021-11-24 11:14:38', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `quotation_request_details`
--

CREATE TABLE `quotation_request_details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `quotation_request_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `product` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `budget` double NOT NULL,
  `quantity` decimal(8,2) NOT NULL,
  `unit` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `requirements` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `quotation_seller_details`
--

CREATE TABLE `quotation_seller_details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `quotation_id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alternate_email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `quotation_seller_details`
--

INSERT INTO `quotation_seller_details` (`id`, `quotation_id`, `email`, `alternate_email`, `phone`, `address`, `created_at`, `updated_at`) VALUES
(1, 1, 'asadbala41@gmail.com', NULL, '+923087742186', 'multan', '2021-11-24 11:41:43', '2021-11-24 11:41:43'),
(2, 3, 'asadbala41@gmail.com', NULL, '+923087742186', 'multan', '2021-11-24 11:46:10', '2021-11-24 11:46:10');

-- --------------------------------------------------------

--
-- Table structure for table `quotation_terms`
--

CREATE TABLE `quotation_terms` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `quotation_id` bigint(20) UNSIGNED NOT NULL,
  `discount` decimal(8,2) DEFAULT NULL,
  `applicable_taxes` decimal(8,2) DEFAULT NULL,
  `shipping_taxes` decimal(8,2) DEFAULT NULL,
  `delivery_period` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_terms` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `additional_info` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `quotation_terms`
--

INSERT INTO `quotation_terms` (`id`, `quotation_id`, `discount`, `applicable_taxes`, `shipping_taxes`, `delivery_period`, `payment_terms`, `additional_info`, `created_at`, `updated_at`) VALUES
(1, 1, '123.00', '10.00', '10.00', '10 weeks', NULL, 'ADDITIONAL INFORMATION', '2021-11-24 11:41:43', '2021-11-24 11:41:43'),
(2, 3, '0.00', '0.00', '0.00', '1 weeks', NULL, NULL, '2021-11-24 11:46:10', '2021-11-24 11:46:10');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'super-admin', 'web', '2021-11-11 12:18:47', '2021-11-11 12:18:47'),
(2, 'admin', 'web', '2021-11-11 12:18:47', '2021-11-11 12:18:47'),
(3, 'corporate', 'web', '2021-11-11 12:18:47', '2021-11-11 12:18:47'),
(4, 'business', 'web', '2021-11-11 12:18:47', '2021-11-11 12:18:47'),
(5, 'individual', 'web', '2021-11-11 12:18:47', '2021-11-11 12:18:47'),
(6, 'buyer', 'web', '2021-11-11 12:18:47', '2021-11-11 12:18:47'),
(7, 'warehouse-owner', 'web', '2021-11-11 12:18:47', '2021-11-11 12:18:47'),
(8, 'driver', 'web', '2021-11-11 12:18:47', '2021-11-11 12:18:47');

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shoppingcart`
--

CREATE TABLE `shoppingcart` (
  `identifier` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `instance` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subscription_orders`
--

CREATE TABLE `subscription_orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `plan_id` int(10) UNSIGNED NOT NULL,
  `payment_method_id` bigint(20) UNSIGNED NOT NULL,
  `promo_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_amount` double(8,2) NOT NULL,
  `total_tax` double(8,2) NOT NULL,
  `total_discount` double(8,2) NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','paid','cancelled','refunded') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subscription_orders`
--

INSERT INTO `subscription_orders` (`id`, `user_id`, `plan_id`, `payment_method_id`, `promo_code`, `total_amount`, `total_tax`, `total_discount`, `notes`, `status`, `created_at`, `updated_at`) VALUES
(5, 1, 1, 1, NULL, 2340.00, 340.00, 0.00, NULL, 'paid', '2021-11-23 08:48:10', '2021-11-23 08:48:35'),
(6, 7, 1, 11, NULL, 2340.00, 340.00, 0.00, NULL, 'pending', '2021-11-24 18:01:15', '2021-11-24 18:01:15'),
(7, 7, 1, 2, NULL, 2340.00, 340.00, 0.00, NULL, 'paid', '2021-11-24 18:05:31', '2021-11-24 18:05:31'),
(8, 7, 1, 2, NULL, 2340.00, 340.00, 0.00, NULL, 'paid', '2021-11-24 18:13:34', '2021-11-24 18:14:15'),
(9, 7, 1, 2, NULL, 2340.00, 340.00, 0.00, NULL, 'paid', '2021-11-24 18:13:34', '2021-11-24 18:14:15'),
(10, 7, 1, 2, NULL, 2340.00, 340.00, 0.00, NULL, 'paid', '2021-11-24 18:13:34', '2021-11-24 18:14:15'),
(11, 7, 1, 2, NULL, 2340.00, 340.00, 0.00, NULL, 'paid', '2021-11-24 18:13:34', '2021-11-24 18:14:15'),
(12, 1, 1, 1, NULL, 2340.00, 340.00, 0.00, NULL, 'paid', '2021-11-23 08:48:10', '2021-11-23 08:48:35'),
(13, 7, 1, 11, NULL, 2340.00, 340.00, 0.00, NULL, 'pending', '2021-11-24 18:01:15', '2021-11-24 18:01:15'),
(14, 7, 1, 2, NULL, 2340.00, 340.00, 0.00, NULL, 'paid', '2021-11-24 18:05:31', '2021-11-24 18:05:31'),
(15, 7, 1, 2, NULL, 2340.00, 340.00, 0.00, NULL, 'paid', '2021-11-24 18:13:34', '2021-11-24 18:14:15'),
(16, 7, 1, 2, NULL, 2340.00, 340.00, 0.00, NULL, 'paid', '2021-11-24 18:13:34', '2021-11-24 18:14:15'),
(17, 7, 1, 2, NULL, 2340.00, 340.00, 0.00, NULL, 'paid', '2021-11-24 18:13:34', '2021-11-24 18:14:15'),
(18, 7, 1, 2, NULL, 2340.00, 340.00, 0.00, NULL, 'paid', '2021-11-24 18:13:34', '2021-11-24 18:14:15'),
(19, 15, 2, 2, NULL, 1755.00, 255.00, 0.00, 'sdfdsfdsf', 'paid', '2021-12-17 12:22:04', '2021-12-17 12:22:04');

-- --------------------------------------------------------

--
-- Table structure for table `subscription_payment_images`
--

CREATE TABLE `subscription_payment_images` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `subscription_payment_log_id` bigint(20) UNSIGNED NOT NULL,
  `image_path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subscription_payment_images`
--

INSERT INTO `subscription_payment_images` (`id`, `subscription_payment_log_id`, `image_path`, `created_at`, `updated_at`) VALUES
(1, 1, 'public/subscription/payment/images/JD8xpf9HszHwXtbB5JObwtm1whrIZW0WCIQyuykr.jpg', '2021-11-23 08:48:35', '2021-11-23 08:48:35'),
(2, 1, 'public/subscription/payment/images/Cwlga9dUfvUyyzV3ic2TDi8uu4VZ0I0gBF8yyDvY.jpg', '2021-11-23 08:48:35', '2021-11-23 08:48:35'),
(3, 2, 'public/subscription/payment/images/9SlOTmX3OTQ0gzeNJ2xeYfQQPoe8WIIxpBxJ0SpU.jpg', '2021-11-24 18:14:15', '2021-11-24 18:14:15');

-- --------------------------------------------------------

--
-- Table structure for table `subscription_payment_logs`
--

CREATE TABLE `subscription_payment_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `subscription_order_id` bigint(20) UNSIGNED NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `old_status` enum('pending','paid','cancelled','refunded') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `added_by` bigint(20) UNSIGNED NOT NULL,
  `amount` double(8,2) DEFAULT NULL,
  `is_closed` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subscription_payment_logs`
--

INSERT INTO `subscription_payment_logs` (`id`, `subscription_order_id`, `description`, `old_status`, `added_by`, `amount`, `is_closed`, `created_at`, `updated_at`) VALUES
(1, 5, 'this is done', 'pending', 4, 2340.00, 0, '2021-11-23 08:48:35', '2021-11-23 08:48:35'),
(2, 8, 'an;ksdnpfjia;', 'pending', 4, 2340.00, 0, '2021-11-24 18:14:15', '2021-11-24 18:14:15');

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_team` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`id`, `user_id`, `name`, `personal_team`, `created_at`, `updated_at`) VALUES
(1, 1, 'asad\'s Team', 1, '2021-11-11 12:19:52', '2021-11-11 12:19:52'),
(2, 16, 'asad\'s Team', 1, '2021-11-22 18:53:36', '2021-11-22 18:53:36');

-- --------------------------------------------------------

--
-- Table structure for table `team_user`
--

CREATE TABLE `team_user` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `team_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--

CREATE TABLE `testimonials` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `designation` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_website` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `transaction_logs`
--

CREATE TABLE `transaction_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `ip` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `transaction_logs`
--

INSERT INTO `transaction_logs` (`id`, `model_type`, `model_id`, `user_id`, `ip`, `action`, `created_at`, `updated_at`) VALUES
(1, 'App\\Models\\SubscriptionOrder', 1, 1, '127.0.0.1', 'order_created', '2021-11-11 12:40:12', '2021-11-11 12:40:12'),
(2, 'App\\Models\\SubscriptionOrder', 2, 1, '127.0.0.1', 'order_created', '2021-11-11 12:40:22', '2021-11-11 12:40:22'),
(3, 'App\\Models\\SubscriptionOrder', 3, 1, '127.0.0.1', 'order_created', '2021-11-12 10:26:52', '2021-11-12 10:26:52'),
(4, 'App\\Models\\SubscriptionOrder', 4, 1, '127.0.0.1', 'order_created', '2021-11-23 07:13:18', '2021-11-23 07:13:18'),
(5, 'App\\Models\\SubscriptionOrder', 5, 1, '127.0.0.1', 'order_created', '2021-11-23 08:48:10', '2021-11-23 08:48:10'),
(6, 'App\\Models\\SubscriptionOrder', 5, 4, '127.0.0.1', 'order_paid', '2021-11-23 08:48:35', '2021-11-23 08:48:35'),
(7, 'App\\Models\\SubscriptionOrder', 6, 7, '127.0.0.1', 'order_created', '2021-11-24 18:01:16', '2021-11-24 18:01:16'),
(8, 'App\\Models\\SubscriptionOrder', 7, 7, '127.0.0.1', 'order_created', '2021-11-24 18:05:31', '2021-11-24 18:05:31'),
(9, 'App\\Models\\SubscriptionOrder', 8, 7, '127.0.0.1', 'order_created', '2021-11-24 18:13:34', '2021-11-24 18:13:34'),
(10, 'App\\Models\\SubscriptionOrder', 8, 4, '127.0.0.1', 'order_paid', '2021-11-24 18:14:15', '2021-11-24 18:14:15'),
(11, 'App\\Models\\SubscriptionOrder', 19, 15, '127.0.0.1', 'order_created', '2021-12-17 12:22:04', '2021-12-17 12:22:04');

-- --------------------------------------------------------

--
-- Table structure for table `trending_categories`
--

CREATE TABLE `trending_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `trending_products`
--

CREATE TABLE `trending_products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `designation` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city_id` bigint(20) UNSIGNED NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `industry` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job_freelance` tinyint(1) DEFAULT NULL,
  `start_as` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`start_as`)),
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_team_id` bigint(20) UNSIGNED DEFAULT NULL,
  `profile_photo_path` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoices_received` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `cnic` varchar(13) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ntn` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stn` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `designation`, `email`, `email_verified_at`, `phone`, `phone_verified_at`, `password`, `two_factor_secret`, `two_factor_recovery_codes`, `city_id`, `address`, `industry`, `job_freelance`, `start_as`, `remember_token`, `current_team_id`, `profile_photo_path`, `invoices_received`, `cnic`, `ntn`, `stn`, `created_at`, `updated_at`, `deleted_at`, `is_active`) VALUES
(1, 'Micky Aurthor', NULL, 'asadbala41@gmail.com', '2021-11-11 08:42:39', '+923087742186', '2021-11-11 12:20:04', '$2y$10$cLAMFDxzs8NM2EtdjgWAiuHtlU32/QJkbG2DI/oTmOesO8cusQOkO', 'eyJpdiI6ImZhYndXaWNzWnZaU0EwRTJDd2QreHc9PSIsInZhbHVlIjoiQ2FwekFyU2xTMjRpRjZPazZzUVhxY3ZBb2syMGVHV1lLdTNnemg0bjlvRT0iLCJtYWMiOiIyYTQzMjllOGU4ZTYyMzgyMTgyMjNmODAzZjIyY2Q0NzlkNmQwY2FjZmM0ZjY5ODU5YjdhYjM5MWNiY2U5OGE2In0=', 'eyJpdiI6ImhYemZLaWpzY2lDVEoyTkk5c3FvNXc9PSIsInZhbHVlIjoiV1NDYm5VOXA2L0d4VjZieWtTTnBJY2NUaUdtaUE1OWZqWFp6YU5kRTAvTEpJblJKSkYydE5uRjdyTGhlemYyRnlYZGxXaWVwMzFSVksxOUN6RmZzUkV6ME9KY2NPQnRBWEV5SjlPRnpxTW12bndxc0ZaNEM0aWY3NCtVVHpaZ1J1NjZ6elBJY29mR09MVlA2ekxKcHQ5cWpCSVFSSEFxWERVWnZySGlVa0hsSzVhdHhGWFJFaG1aMUt0UUM0SmRjTWpjMlh4MUxwUkQweUNzRFpqbGhqWXlxT29kOFJweW9JdDhQUmFKcFFjcVRLS2ZPZEduMmMzZUhjZjh2b2tHa3AvK1JEYzQ0UDhZMDN5OVV0YnVHRnc9PSIsIm1hYyI6IjEwMmYxNjY0YzUyZTIzNDdlMGU3NWI0YWFjODVmMDk4MDAyNmIwMWZjMTI4MmM0ODZkMThjMWU2ZmQ1ZTc1MDkifQ==', 8, 'multan', 'developer', NULL, NULL, NULL, NULL, 'profile-photos/9gMxrBbtYKENwCB9I7G3kF5SAcPPhQjUNo0JvFkF.jpg', 100, NULL, NULL, NULL, '2021-11-11 12:19:52', '2021-12-10 09:16:14', NULL, 1),
(4, 'SuperAdmin', NULL, 'super.admin@emandii.com', NULL, '+923012345678', '2021-11-22 09:02:52', '$2y$10$m2GEqPCGmqUsLywWgpR5FO0OgM4FcIfV5p2BJWN8.GJRlO10vG.Nu', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 'profile-photos/LI9txME39ycIHB4pJOYJf9unh50GqjvS7NUs1XQv.jpg', 0, NULL, NULL, NULL, '2021-11-22 09:01:23', '2021-12-04 17:34:51', NULL, 1),
(5, 'Admin', NULL, 'admin@emandii.com', '2021-11-23 07:19:48', '+923012345679', '2021-11-23 07:20:14', '$2y$10$cLAMFDxzs8NM2EtdjgWAiuHtlU32/QJkbG2DI/oTmOesO8cusQOkO', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2021-11-22 09:01:23', '2021-11-22 09:01:23', NULL, 1),
(6, 'Durward Hauck', NULL, 'block.madaline@example.org', '2021-11-22 09:01:24', '551.843.9313', '2021-11-22 16:45:10', '$2y$10$QwscGm2GN4w4DA.1xSjJE.Y/SdCz89KqXzXmZLlVx5/kfLBSaNyaa', NULL, NULL, 13, NULL, NULL, NULL, NULL, 'a5l9F0PDFoidDvvUCMEm8jORsKWYFU2mPCZobhrpFsRXSgUtOqsHDRY4IzDa', NULL, NULL, 0, NULL, NULL, NULL, '2021-11-22 09:01:24', '2021-11-22 16:49:19', '2021-11-22 16:49:19', 1),
(7, 'Rosella McLaughlin', NULL, 'kherman@example.com', '2021-11-22 09:01:24', '936-887-1583', '2021-11-22 09:01:24', '$2y$10$cLAMFDxzs8NM2EtdjgWAiuHtlU32/QJkbG2DI/oTmOesO8cusQOkO', NULL, NULL, 69, NULL, NULL, NULL, NULL, 'pGuX5bjAiVE3BC5S00LUQIZjNyEKy5VV0hHztxeJnL6fbPJSIrHq2cYBCQSI', NULL, NULL, 0, NULL, NULL, NULL, '2021-11-22 09:01:24', '2021-11-22 09:01:24', NULL, 1),
(8, 'Ebba Labadie', NULL, 'rath.ettie@example.net', '2021-11-22 09:01:24', '228-906-0906', '2021-11-22 09:01:24', '$2y$10$cLAMFDxzs8NM2EtdjgWAiuHtlU32/QJkbG2DI/oTmOesO8cusQOkO', NULL, NULL, 12, NULL, NULL, NULL, NULL, 'E8F0sbUvLL5wIvDoZzGpK6PI0UgxecyHlGktcbE8DD7UzkxFldS0uMRnxRGc', NULL, NULL, 0, NULL, NULL, NULL, '2021-11-22 09:01:25', '2021-11-24 17:27:31', NULL, 1),
(9, 'Ara Kovacek', NULL, 'mathew93@example.com', '2021-11-22 09:01:24', '+1-720-858-5526', NULL, '$2y$10$CNNHKuf.vsdwm.NIqDcw2.aRsxrRH2q6ltJF0hb0PQViQCFDCHGti', NULL, NULL, 76, NULL, NULL, NULL, NULL, 'CwQIQg0yN5', NULL, NULL, 0, NULL, NULL, NULL, '2021-11-22 09:01:25', '2021-11-22 09:01:25', NULL, 1),
(10, 'Marianne Sporer', NULL, 'khalil08@example.com', '2021-11-22 09:01:24', '+1.470.247.7269', NULL, '$2y$10$G6ZuB7tIC/8i4gAX9DHUIudDU9bngFhjEzF2awZgFrKK.7E22UsEm', NULL, NULL, 45, NULL, NULL, NULL, NULL, 'ITQJj5vyw6', NULL, NULL, 0, NULL, NULL, NULL, '2021-11-22 09:01:25', '2021-11-22 09:01:25', NULL, 1),
(11, 'Ardella Hickle', NULL, 'rowe.jayne@example.com', '2021-11-22 09:01:24', '337.779.0438', NULL, '$2y$10$FvwcgiQCId4Pwle3Ucp1HeP32KbN.TpbDt6.c639PadOuM/7fHM7O', NULL, NULL, 90, NULL, NULL, NULL, NULL, '1ybh8uF4mt', NULL, NULL, 0, NULL, NULL, NULL, '2021-11-22 09:01:25', '2021-11-22 09:01:25', NULL, 1),
(12, 'Leslie Effertz', NULL, 'kiehn.cierra@example.net', '2021-11-22 09:01:24', '801.950.6007', '2021-11-22 09:01:24', '$2y$10$R/6x4hKY1hLLCZoiJyDcQOA1qx4Ok0KNYik5KtrNNjPq96XtGZDCi', NULL, NULL, 7, NULL, NULL, NULL, NULL, 'm1ccaYjhs0', NULL, NULL, 0, NULL, NULL, NULL, '2021-11-22 09:01:25', '2021-11-22 09:01:25', NULL, 1),
(13, 'Cortney Pouros', NULL, 'fhill@example.org', '2021-11-22 09:01:24', '(979) 734-9318', '2021-11-22 09:01:24', '$2y$10$1q0OfYyM8blrWgbucUhSGe6prVI9FGXqeaFTS6Y/GRhje7gryBrSe', NULL, NULL, 72, NULL, NULL, NULL, NULL, 'GCyIT0sGPR', NULL, NULL, 0, NULL, NULL, NULL, '2021-11-22 09:01:25', '2021-11-22 09:01:25', NULL, 1),
(14, 'Horace Witting', NULL, 'iyundt@example.org', '2021-11-22 09:01:24', '+1.931.722.3089', '2021-11-22 09:01:24', '$2y$10$d5tMK2cqI6idBpmXGPK2fu/8ZUh06js6dnKizWwkcNxLUhweaZsue', NULL, NULL, 46, NULL, NULL, NULL, NULL, 'XYVHocwprw', NULL, NULL, 0, NULL, NULL, NULL, '2021-11-22 09:01:25', '2021-11-22 09:01:25', NULL, 1),
(15, 'Jefferey Brekke', NULL, 'parker.jazlyn@example.org', '2021-11-22 09:01:24', '678-956-6577', '2021-11-22 09:01:24', '$2y$10$m2GEqPCGmqUsLywWgpR5FO0OgM4FcIfV5p2BJWN8.GJRlO10vG.Nu', NULL, NULL, 15, NULL, NULL, NULL, NULL, 'H7PuaCGf7h8yBqtTvpV6hXS9GE1FeeS0HEdqxzHWWngFm59NJkTd5tiZWzy5', NULL, 'uploads/user-profile-pics/15/1639563109-WBwz-profile-picture.png', 0, NULL, NULL, NULL, '2021-11-22 09:01:25', '2021-12-15 10:11:49', NULL, 1),
(17, 'dfsds', NULL, 'sdf@lksd.com', NULL, '+923087879878', NULL, 'd9556df496aa7976e7d6c2167d623624', NULL, NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2021-12-16 11:35:40', '2021-12-16 11:35:40', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_badges`
--

CREATE TABLE `user_badges` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `badge_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_favorites`
--

CREATE TABLE `user_favorites` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `favorable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `favorable_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_product_interests`
--

CREATE TABLE `user_product_interests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `required_product` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `frequency` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int(11) NOT NULL,
  `quantity_unit` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_product_interests`
--

INSERT INTO `user_product_interests` (`id`, `user_id`, `required_product`, `frequency`, `quantity`, `quantity_unit`, `created_at`, `updated_at`) VALUES
(1, 1, 'this is requirmets', 'after one month', 1, 'kg', '2021-11-12 10:37:33', '2021-11-12 10:37:33'),
(2, 1, 'requiremnt of product', 'immediate', 500, 'kg', '2021-11-23 07:06:04', '2021-11-23 07:06:04'),
(3, 15, 'sdfdsf', 'immediate', 3, 'tons', '2021-12-17 11:11:34', '2021-12-17 11:11:34');

-- --------------------------------------------------------

--
-- Table structure for table `user_product_services`
--

CREATE TABLE `user_product_services` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `business_type_id` bigint(20) UNSIGNED NOT NULL,
  `keywords` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`keywords`)),
  `is_primary` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_product_services`
--

INSERT INTO `user_product_services` (`id`, `user_id`, `business_type_id`, `keywords`, `is_primary`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'null', 1, '2021-11-23 07:04:46', '2021-11-23 07:04:46'),
(2, 1, 1, 'null', 0, '2021-11-23 07:04:46', '2021-11-23 07:04:46');

-- --------------------------------------------------------

--
-- Table structure for table `warehouses`
--

CREATE TABLE `warehouses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `city_id` bigint(20) UNSIGNED NOT NULL,
  `locality_id` bigint(20) UNSIGNED NOT NULL,
  `property_type_id` bigint(20) UNSIGNED NOT NULL,
  `coordinates` point NOT NULL,
  `area` double NOT NULL,
  `price` double NOT NULL,
  `can_be_shared` tinyint(1) NOT NULL DEFAULT 0,
  `is_approved` tinyint(1) NOT NULL DEFAULT 0,
  `instant_booking` tinyint(1) NOT NULL DEFAULT 0,
  `is_verified` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `warehouses`
--

INSERT INTO `warehouses` (`id`, `user_id`, `city_id`, `locality_id`, `property_type_id`, `coordinates`, `area`, `price`, `can_be_shared`, `is_approved`, `instant_booking`, `is_verified`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES
(2, 1, 36, 6, 2, 0x000000000101000000f9bce2a9c797524021600894a8763f40, 1718, 2304283, 0, 1, 0, 1, 1, '2021-11-23 07:50:34', '2021-11-23 07:50:34', NULL),
(3, 1, 46, 5, 1, 0x000000000101000000f9bce2a9c797524021600894a8763f40, 1817, 1729731, 0, 1, 1, 1, 1, '2021-11-23 07:50:34', '2021-11-23 07:50:34', NULL),
(4, 1, 30, 7, 4, 0x000000000101000000f9bce2a9c797524021600894a8763f40, 4930, 314535, 1, 1, 0, 1, 1, '2021-11-23 07:50:34', '2021-11-23 07:50:34', NULL),
(5, 11, 29, 7, 2, 0x000000000101000000f9bce2a9c797524021600894a8763f40, 2121, 959789, 1, 1, 0, 1, 1, '2021-11-23 07:50:34', '2021-11-23 07:50:34', NULL),
(6, 5, 85, 6, 6, 0x000000000101000000f9bce2a9c797524021600894a8763f40, 1813, 445102, 1, 1, 0, 1, 1, '2021-11-23 07:50:35', '2021-11-23 07:50:35', NULL),
(7, 5, 23, 3, 1, 0x000000000101000000f9bce2a9c797524021600894a8763f40, 2906, 4732820, 0, 1, 1, 0, 1, '2021-11-23 07:50:35', '2021-11-23 07:50:35', NULL),
(8, 9, 12, 4, 2, 0x000000000101000000f9bce2a9c797524021600894a8763f40, 3392, 4547347, 0, 1, 0, 1, 1, '2021-11-23 07:50:35', '2021-11-23 07:50:35', NULL),
(9, 9, 41, 6, 4, 0x000000000101000000f9bce2a9c797524021600894a8763f40, 2426, 452973, 1, 1, 0, 1, 1, '2021-11-23 07:50:35', '2021-11-23 07:50:35', NULL),
(10, 13, 83, 4, 5, 0x000000000101000000f9bce2a9c797524021600894a8763f40, 1250, 1901247, 1, 1, 0, 0, 1, '2021-11-23 07:50:35', '2021-11-23 07:50:35', NULL),
(11, 7, 79, 3, 6, 0x000000000101000000f9bce2a9c797524021600894a8763f40, 1588, 4928800, 0, 1, 1, 1, 1, '2021-11-23 07:50:35', '2021-11-23 07:50:35', NULL),
(12, 1, 8, 6, 2, 0x00000000010100000018265305a3323e4052499d8026de5140, 200, 2500, 1, 0, 0, 0, 1, '2021-11-23 08:16:19', '2021-11-23 08:16:19', NULL),
(13, 1, 8, 6, 1, 0x00000000010100000018265305a3323e4052499d8026de5140, 200, 2500, 0, 0, 0, 0, 1, '2021-11-23 08:21:40', '2021-11-23 08:21:40', NULL),
(14, 1, 8, 7, 2, 0x00000000010100000018265305a3323e4052499d8026de5140, 200, 2500, 0, 0, 0, 0, 1, '2021-11-23 08:31:47', '2021-11-23 08:31:47', NULL),
(15, 1, 8, 4, 3, 0x00000000010100000018265305a3323e4052499d8026de5140, 200, 2500, 1, 1, 0, 0, 1, '2021-11-24 19:27:50', '2021-11-24 19:28:17', NULL),
(16, 1, 8, 3, 2, 0x00000000010100000018265305a3323e4052499d8026de5140, 200, 2500, 1, 0, 0, 0, 1, '2021-11-25 06:17:28', '2021-11-25 06:17:28', NULL),
(17, 1, 8, 4, 1, 0x00000000010100000018265305a3323e4052499d8026de5140, 200, 1111, 1, 0, 0, 0, 1, '2021-11-27 07:08:11', '2021-11-27 07:08:11', NULL),
(18, 1, 8, 6, 2, 0x00000000010100000018265305a3323e4052499d8026de5140, 200, 2500, 1, 0, 0, 0, 1, '2021-12-03 11:22:59', '2021-12-04 09:27:00', NULL),
(19, 1, 8, 3, 2, 0x00000000010100000018265305a3323e4052499d8026de5140, 200, 2500, 0, 0, 0, 0, 1, '2021-12-04 08:59:47', '2021-12-04 09:21:08', NULL),
(20, 1, 8, 3, 2, 0x00000000010100000052499d8026de514018265305a3323e40, 200, 2500, 1, 0, 0, 0, 1, '2021-12-04 09:19:24', '2021-12-04 09:21:33', NULL),
(21, 1, 8, 7, 1, 0x00000000010100000052499d8026de514018265305a3323e40, 123, 2500, 0, 0, 0, 0, 1, '2021-12-04 17:11:20', '2021-12-04 17:46:28', NULL),
(22, 15, 15, 5, 4, 0x0000000001010000000f0bb5a679b73f40098a1f63ee3e5240, 3, 3, 1, 0, 0, 0, 1, '2021-12-16 08:56:04', '2021-12-16 08:56:04', NULL),
(23, 15, 15, 5, 2, 0x0000000001010000000f0bb5a679b73f40098a1f63ee3e5240, 1, 1, 1, 0, 0, 0, 1, '2021-12-16 10:07:03', '2021-12-16 10:07:03', NULL),
(24, 15, 15, 5, 2, 0x0000000001010000000f0bb5a679b73f40098a1f63ee3e5240, 1, 1, 1, 0, 0, 0, 1, '2021-12-16 10:40:18', '2021-12-16 10:40:18', NULL),
(25, 15, 15, 4, 2, 0x0000000001010000000f0bb5a679b73f40098a1f63ee3e5240, 1, 1, 1, 0, 0, 0, 1, '2021-12-16 11:11:37', '2021-12-16 11:11:37', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `warehouse_bookings`
--

CREATE TABLE `warehouse_bookings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `warehouse_id` bigint(20) UNSIGNED NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `item` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `booking_status` enum('pending','approved','confirmed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `quantity` double DEFAULT NULL,
  `unit` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `area` double DEFAULT NULL,
  `type` enum('partial','fully') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'fully',
  `goods_value` double DEFAULT NULL,
  `booked_by` bigint(20) UNSIGNED NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `warehouse_features`
--

CREATE TABLE `warehouse_features` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `warehouse_id` bigint(20) UNSIGNED NOT NULL,
  `feature_id` bigint(20) UNSIGNED NOT NULL,
  `feature` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `warehouse_features`
--

INSERT INTO `warehouse_features` (`id`, `warehouse_id`, `feature_id`, `feature`, `created_at`, `updated_at`) VALUES
(1, 2, 1, '1', '2021-11-23 07:50:35', '2021-11-23 07:50:35'),
(2, 2, 2, '3', '2021-11-23 07:50:35', '2021-11-23 07:50:35'),
(3, 2, 3, '3', '2021-11-23 07:50:35', '2021-11-23 07:50:35'),
(4, 2, 4, '2', '2021-11-23 07:50:35', '2021-11-23 07:50:35'),
(5, 2, 5, '1', '2021-11-23 07:50:35', '2021-11-23 07:50:35'),
(6, 2, 6, '1', '2021-11-23 07:50:35', '2021-11-23 07:50:35'),
(7, 2, 7, '0', '2021-11-23 07:50:35', '2021-11-23 07:50:35'),
(8, 2, 8, '0', '2021-11-23 07:50:35', '2021-11-23 07:50:35'),
(9, 2, 9, '0', '2021-11-23 07:50:35', '2021-11-23 07:50:35'),
(10, 2, 10, '1', '2021-11-23 07:50:35', '2021-11-23 07:50:35'),
(11, 2, 11, '1', '2021-11-23 07:50:35', '2021-11-23 07:50:35'),
(12, 2, 12, '4', '2021-11-23 07:50:35', '2021-11-23 07:50:35'),
(13, 2, 13, '1', '2021-11-23 07:50:35', '2021-11-23 07:50:35'),
(14, 2, 14, '5', '2021-11-23 07:50:35', '2021-11-23 07:50:35'),
(15, 2, 15, '2', '2021-11-23 07:50:35', '2021-11-23 07:50:35'),
(16, 2, 16, '10', '2021-11-23 07:50:35', '2021-11-23 07:50:35'),
(17, 2, 17, '1', '2021-11-23 07:50:35', '2021-11-23 07:50:35'),
(18, 2, 18, '0', '2021-11-23 07:50:35', '2021-11-23 07:50:35'),
(19, 2, 19, '1', '2021-11-23 07:50:35', '2021-11-23 07:50:35'),
(20, 2, 20, '1', '2021-11-23 07:50:35', '2021-11-23 07:50:35'),
(21, 2, 21, '1', '2021-11-23 07:50:35', '2021-11-23 07:50:35'),
(22, 2, 22, '1', '2021-11-23 07:50:35', '2021-11-23 07:50:35'),
(23, 3, 1, '5', '2021-11-23 07:50:35', '2021-11-23 07:50:35'),
(24, 3, 2, '9', '2021-11-23 07:50:36', '2021-11-23 07:50:36'),
(25, 3, 3, '2', '2021-11-23 07:50:36', '2021-11-23 07:50:36'),
(26, 3, 4, '10', '2021-11-23 07:50:36', '2021-11-23 07:50:36'),
(27, 3, 5, '6', '2021-11-23 07:50:36', '2021-11-23 07:50:36'),
(28, 3, 6, '0', '2021-11-23 07:50:36', '2021-11-23 07:50:36'),
(29, 3, 7, '0', '2021-11-23 07:50:36', '2021-11-23 07:50:36'),
(30, 3, 8, '1', '2021-11-23 07:50:36', '2021-11-23 07:50:36'),
(31, 3, 9, '1', '2021-11-23 07:50:36', '2021-11-23 07:50:36'),
(32, 3, 10, '0', '2021-11-23 07:50:36', '2021-11-23 07:50:36'),
(33, 3, 11, '1', '2021-11-23 07:50:36', '2021-11-23 07:50:36'),
(34, 3, 12, '6', '2021-11-23 07:50:36', '2021-11-23 07:50:36'),
(35, 3, 13, '3', '2021-11-23 07:50:36', '2021-11-23 07:50:36'),
(36, 3, 14, '5', '2021-11-23 07:50:36', '2021-11-23 07:50:36'),
(37, 3, 15, '3', '2021-11-23 07:50:36', '2021-11-23 07:50:36'),
(38, 3, 16, '8', '2021-11-23 07:50:36', '2021-11-23 07:50:36'),
(39, 3, 17, '1', '2021-11-23 07:50:36', '2021-11-23 07:50:36'),
(40, 3, 18, '1', '2021-11-23 07:50:36', '2021-11-23 07:50:36'),
(41, 3, 19, '0', '2021-11-23 07:50:36', '2021-11-23 07:50:36'),
(42, 3, 20, '0', '2021-11-23 07:50:36', '2021-11-23 07:50:36'),
(43, 3, 21, '0', '2021-11-23 07:50:36', '2021-11-23 07:50:36'),
(44, 3, 22, '0', '2021-11-23 07:50:36', '2021-11-23 07:50:36'),
(45, 4, 1, '4', '2021-11-23 07:50:36', '2021-11-23 07:50:36'),
(46, 4, 2, '4', '2021-11-23 07:50:36', '2021-11-23 07:50:36'),
(47, 4, 3, '6', '2021-11-23 07:50:36', '2021-11-23 07:50:36'),
(48, 4, 4, '1', '2021-11-23 07:50:36', '2021-11-23 07:50:36'),
(49, 4, 5, '3', '2021-11-23 07:50:36', '2021-11-23 07:50:36'),
(50, 4, 6, '0', '2021-11-23 07:50:36', '2021-11-23 07:50:36'),
(51, 4, 7, '1', '2021-11-23 07:50:36', '2021-11-23 07:50:36'),
(52, 4, 8, '0', '2021-11-23 07:50:36', '2021-11-23 07:50:36'),
(53, 4, 9, '1', '2021-11-23 07:50:37', '2021-11-23 07:50:37'),
(54, 4, 10, '1', '2021-11-23 07:50:37', '2021-11-23 07:50:37'),
(55, 4, 11, '0', '2021-11-23 07:50:37', '2021-11-23 07:50:37'),
(56, 4, 12, '8', '2021-11-23 07:50:37', '2021-11-23 07:50:37'),
(57, 4, 13, '3', '2021-11-23 07:50:37', '2021-11-23 07:50:37'),
(58, 4, 14, '7', '2021-11-23 07:50:37', '2021-11-23 07:50:37'),
(59, 4, 15, '4', '2021-11-23 07:50:37', '2021-11-23 07:50:37'),
(60, 4, 16, '4', '2021-11-23 07:50:37', '2021-11-23 07:50:37'),
(61, 4, 17, '0', '2021-11-23 07:50:37', '2021-11-23 07:50:37'),
(62, 4, 18, '1', '2021-11-23 07:50:37', '2021-11-23 07:50:37'),
(63, 4, 19, '0', '2021-11-23 07:50:37', '2021-11-23 07:50:37'),
(64, 4, 20, '0', '2021-11-23 07:50:37', '2021-11-23 07:50:37'),
(65, 4, 21, '0', '2021-11-23 07:50:37', '2021-11-23 07:50:37'),
(66, 4, 22, '0', '2021-11-23 07:50:37', '2021-11-23 07:50:37'),
(67, 5, 1, '1', '2021-11-23 07:50:37', '2021-11-23 07:50:37'),
(68, 5, 2, '8', '2021-11-23 07:50:37', '2021-11-23 07:50:37'),
(69, 5, 3, '1', '2021-11-23 07:50:37', '2021-11-23 07:50:37'),
(70, 5, 4, '8', '2021-11-23 07:50:37', '2021-11-23 07:50:37'),
(71, 5, 5, '7', '2021-11-23 07:50:37', '2021-11-23 07:50:37'),
(72, 5, 6, '1', '2021-11-23 07:50:37', '2021-11-23 07:50:37'),
(73, 5, 7, '1', '2021-11-23 07:50:37', '2021-11-23 07:50:37'),
(74, 5, 8, '0', '2021-11-23 07:50:37', '2021-11-23 07:50:37'),
(75, 5, 9, '1', '2021-11-23 07:50:37', '2021-11-23 07:50:37'),
(76, 5, 10, '1', '2021-11-23 07:50:37', '2021-11-23 07:50:37'),
(77, 5, 11, '0', '2021-11-23 07:50:37', '2021-11-23 07:50:37'),
(78, 5, 12, '6', '2021-11-23 07:50:37', '2021-11-23 07:50:37'),
(79, 5, 13, '5', '2021-11-23 07:50:37', '2021-11-23 07:50:37'),
(80, 5, 14, '9', '2021-11-23 07:50:37', '2021-11-23 07:50:37'),
(81, 5, 15, '7', '2021-11-23 07:50:37', '2021-11-23 07:50:37'),
(82, 5, 16, '3', '2021-11-23 07:50:37', '2021-11-23 07:50:37'),
(83, 5, 17, '1', '2021-11-23 07:50:37', '2021-11-23 07:50:37'),
(84, 5, 18, '1', '2021-11-23 07:50:38', '2021-11-23 07:50:38'),
(85, 5, 19, '1', '2021-11-23 07:50:38', '2021-11-23 07:50:38'),
(86, 5, 20, '1', '2021-11-23 07:50:38', '2021-11-23 07:50:38'),
(87, 5, 21, '0', '2021-11-23 07:50:38', '2021-11-23 07:50:38'),
(88, 5, 22, '1', '2021-11-23 07:50:38', '2021-11-23 07:50:38'),
(89, 6, 1, '1', '2021-11-23 07:50:38', '2021-11-23 07:50:38'),
(90, 6, 2, '1', '2021-11-23 07:50:38', '2021-11-23 07:50:38'),
(91, 6, 3, '6', '2021-11-23 07:50:38', '2021-11-23 07:50:38'),
(92, 6, 4, '2', '2021-11-23 07:50:38', '2021-11-23 07:50:38'),
(93, 6, 5, '1', '2021-11-23 07:50:38', '2021-11-23 07:50:38'),
(94, 6, 6, '0', '2021-11-23 07:50:38', '2021-11-23 07:50:38'),
(95, 6, 7, '1', '2021-11-23 07:50:38', '2021-11-23 07:50:38'),
(96, 6, 8, '0', '2021-11-23 07:50:38', '2021-11-23 07:50:38'),
(97, 6, 9, '0', '2021-11-23 07:50:38', '2021-11-23 07:50:38'),
(98, 6, 10, '1', '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(99, 6, 11, '1', '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(100, 6, 12, '6', '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(101, 6, 13, '1', '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(102, 6, 14, '8', '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(103, 6, 15, '8', '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(104, 6, 16, '4', '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(105, 6, 17, '0', '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(106, 6, 18, '1', '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(107, 6, 19, '1', '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(108, 6, 20, '0', '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(109, 6, 21, '1', '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(110, 6, 22, '1', '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(111, 7, 1, '1', '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(112, 7, 2, '3', '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(113, 7, 3, '6', '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(114, 7, 4, '8', '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(115, 7, 5, '1', '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(116, 7, 6, '1', '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(117, 7, 7, '0', '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(118, 7, 8, '0', '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(119, 7, 9, '1', '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(120, 7, 10, '0', '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(121, 7, 11, '1', '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(122, 7, 12, '8', '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(123, 7, 13, '3', '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(124, 7, 14, '6', '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(125, 7, 15, '5', '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(126, 7, 16, '9', '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(127, 7, 17, '1', '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(128, 7, 18, '1', '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(129, 7, 19, '0', '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(130, 7, 20, '0', '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(131, 7, 21, '1', '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(132, 7, 22, '1', '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(133, 8, 1, '1', '2021-11-23 07:50:40', '2021-11-23 07:50:40'),
(134, 8, 2, '3', '2021-11-23 07:50:40', '2021-11-23 07:50:40'),
(135, 8, 3, '8', '2021-11-23 07:50:40', '2021-11-23 07:50:40'),
(136, 8, 4, '3', '2021-11-23 07:50:40', '2021-11-23 07:50:40'),
(137, 8, 5, '1', '2021-11-23 07:50:40', '2021-11-23 07:50:40'),
(138, 8, 6, '0', '2021-11-23 07:50:40', '2021-11-23 07:50:40'),
(139, 8, 7, '0', '2021-11-23 07:50:40', '2021-11-23 07:50:40'),
(140, 8, 8, '0', '2021-11-23 07:50:40', '2021-11-23 07:50:40'),
(141, 8, 9, '1', '2021-11-23 07:50:40', '2021-11-23 07:50:40'),
(142, 8, 10, '1', '2021-11-23 07:50:40', '2021-11-23 07:50:40'),
(143, 8, 11, '0', '2021-11-23 07:50:40', '2021-11-23 07:50:40'),
(144, 8, 12, '2', '2021-11-23 07:50:40', '2021-11-23 07:50:40'),
(145, 8, 13, '9', '2021-11-23 07:50:40', '2021-11-23 07:50:40'),
(146, 8, 14, '7', '2021-11-23 07:50:40', '2021-11-23 07:50:40'),
(147, 8, 15, '7', '2021-11-23 07:50:40', '2021-11-23 07:50:40'),
(148, 8, 16, '10', '2021-11-23 07:50:40', '2021-11-23 07:50:40'),
(149, 8, 17, '0', '2021-11-23 07:50:40', '2021-11-23 07:50:40'),
(150, 8, 18, '1', '2021-11-23 07:50:40', '2021-11-23 07:50:40'),
(151, 8, 19, '1', '2021-11-23 07:50:40', '2021-11-23 07:50:40'),
(152, 8, 20, '1', '2021-11-23 07:50:40', '2021-11-23 07:50:40'),
(153, 8, 21, '0', '2021-11-23 07:50:40', '2021-11-23 07:50:40'),
(154, 8, 22, '0', '2021-11-23 07:50:40', '2021-11-23 07:50:40'),
(155, 9, 1, '10', '2021-11-23 07:50:40', '2021-11-23 07:50:40'),
(156, 9, 2, '8', '2021-11-23 07:50:40', '2021-11-23 07:50:40'),
(157, 9, 3, '1', '2021-11-23 07:50:40', '2021-11-23 07:50:40'),
(158, 9, 4, '4', '2021-11-23 07:50:40', '2021-11-23 07:50:40'),
(159, 9, 5, '9', '2021-11-23 07:50:40', '2021-11-23 07:50:40'),
(160, 9, 6, '1', '2021-11-23 07:50:40', '2021-11-23 07:50:40'),
(161, 9, 7, '0', '2021-11-23 07:50:40', '2021-11-23 07:50:40'),
(162, 9, 8, '0', '2021-11-23 07:50:40', '2021-11-23 07:50:40'),
(163, 9, 9, '0', '2021-11-23 07:50:41', '2021-11-23 07:50:41'),
(164, 9, 10, '1', '2021-11-23 07:50:41', '2021-11-23 07:50:41'),
(165, 9, 11, '1', '2021-11-23 07:50:41', '2021-11-23 07:50:41'),
(166, 9, 12, '6', '2021-11-23 07:50:41', '2021-11-23 07:50:41'),
(167, 9, 13, '3', '2021-11-23 07:50:41', '2021-11-23 07:50:41'),
(168, 9, 14, '8', '2021-11-23 07:50:41', '2021-11-23 07:50:41'),
(169, 9, 15, '6', '2021-11-23 07:50:41', '2021-11-23 07:50:41'),
(170, 9, 16, '5', '2021-11-23 07:50:41', '2021-11-23 07:50:41'),
(171, 9, 17, '1', '2021-11-23 07:50:41', '2021-11-23 07:50:41'),
(172, 9, 18, '0', '2021-11-23 07:50:41', '2021-11-23 07:50:41'),
(173, 9, 19, '0', '2021-11-23 07:50:41', '2021-11-23 07:50:41'),
(174, 9, 20, '1', '2021-11-23 07:50:41', '2021-11-23 07:50:41'),
(175, 9, 21, '0', '2021-11-23 07:50:41', '2021-11-23 07:50:41'),
(176, 9, 22, '1', '2021-11-23 07:50:41', '2021-11-23 07:50:41'),
(177, 10, 1, '7', '2021-11-23 07:50:41', '2021-11-23 07:50:41'),
(178, 10, 2, '6', '2021-11-23 07:50:41', '2021-11-23 07:50:41'),
(179, 10, 3, '7', '2021-11-23 07:50:41', '2021-11-23 07:50:41'),
(180, 10, 4, '9', '2021-11-23 07:50:41', '2021-11-23 07:50:41'),
(181, 10, 5, '7', '2021-11-23 07:50:41', '2021-11-23 07:50:41'),
(182, 10, 6, '0', '2021-11-23 07:50:41', '2021-11-23 07:50:41'),
(183, 10, 7, '0', '2021-11-23 07:50:41', '2021-11-23 07:50:41'),
(184, 10, 8, '0', '2021-11-23 07:50:41', '2021-11-23 07:50:41'),
(185, 10, 9, '1', '2021-11-23 07:50:41', '2021-11-23 07:50:41'),
(186, 10, 10, '0', '2021-11-23 07:50:41', '2021-11-23 07:50:41'),
(187, 10, 11, '0', '2021-11-23 07:50:41', '2021-11-23 07:50:41'),
(188, 10, 12, '5', '2021-11-23 07:50:41', '2021-11-23 07:50:41'),
(189, 10, 13, '3', '2021-11-23 07:50:41', '2021-11-23 07:50:41'),
(190, 10, 14, '7', '2021-11-23 07:50:41', '2021-11-23 07:50:41'),
(191, 10, 15, '8', '2021-11-23 07:50:41', '2021-11-23 07:50:41'),
(192, 10, 16, '2', '2021-11-23 07:50:41', '2021-11-23 07:50:41'),
(193, 10, 17, '1', '2021-11-23 07:50:41', '2021-11-23 07:50:41'),
(194, 10, 18, '0', '2021-11-23 07:50:42', '2021-11-23 07:50:42'),
(195, 10, 19, '0', '2021-11-23 07:50:42', '2021-11-23 07:50:42'),
(196, 10, 20, '0', '2021-11-23 07:50:42', '2021-11-23 07:50:42'),
(197, 10, 21, '1', '2021-11-23 07:50:42', '2021-11-23 07:50:42'),
(198, 10, 22, '1', '2021-11-23 07:50:42', '2021-11-23 07:50:42'),
(199, 11, 1, '7', '2021-11-23 07:50:42', '2021-11-23 07:50:42'),
(200, 11, 2, '4', '2021-11-23 07:50:42', '2021-11-23 07:50:42'),
(201, 11, 3, '7', '2021-11-23 07:50:42', '2021-11-23 07:50:42'),
(202, 11, 4, '6', '2021-11-23 07:50:42', '2021-11-23 07:50:42'),
(203, 11, 5, '3', '2021-11-23 07:50:42', '2021-11-23 07:50:42'),
(204, 11, 6, '0', '2021-11-23 07:50:42', '2021-11-23 07:50:42'),
(205, 11, 7, '1', '2021-11-23 07:50:42', '2021-11-23 07:50:42'),
(206, 11, 8, '0', '2021-11-23 07:50:42', '2021-11-23 07:50:42'),
(207, 11, 9, '0', '2021-11-23 07:50:42', '2021-11-23 07:50:42'),
(208, 11, 10, '1', '2021-11-23 07:50:42', '2021-11-23 07:50:42'),
(209, 11, 11, '1', '2021-11-23 07:50:42', '2021-11-23 07:50:42'),
(210, 11, 12, '10', '2021-11-23 07:50:42', '2021-11-23 07:50:42'),
(211, 11, 13, '5', '2021-11-23 07:50:42', '2021-11-23 07:50:42'),
(212, 11, 14, '1', '2021-11-23 07:50:42', '2021-11-23 07:50:42'),
(213, 11, 15, '5', '2021-11-23 07:50:42', '2021-11-23 07:50:42'),
(214, 11, 16, '1', '2021-11-23 07:50:42', '2021-11-23 07:50:42'),
(215, 11, 17, '0', '2021-11-23 07:50:42', '2021-11-23 07:50:42'),
(216, 11, 18, '1', '2021-11-23 07:50:42', '2021-11-23 07:50:42'),
(217, 11, 19, '0', '2021-11-23 07:50:42', '2021-11-23 07:50:42'),
(218, 11, 20, '0', '2021-11-23 07:50:42', '2021-11-23 07:50:42'),
(219, 11, 21, '1', '2021-11-23 07:50:42', '2021-11-23 07:50:42'),
(220, 11, 22, '1', '2021-11-23 07:50:43', '2021-11-23 07:50:43'),
(221, 14, 11, 'on', '2021-11-23 08:31:47', '2021-11-23 08:31:47'),
(222, 14, 10, 'on', '2021-11-23 08:31:47', '2021-11-23 08:31:47'),
(223, 14, 9, 'on', '2021-11-23 08:31:47', '2021-11-23 08:31:47'),
(224, 14, 5, '200', '2021-11-23 08:31:47', '2021-11-23 08:31:47'),
(225, 14, 4, '2', '2021-11-23 08:31:47', '2021-11-23 08:31:47'),
(226, 14, 3, '20', '2021-11-23 08:31:47', '2021-11-23 08:31:47'),
(227, 14, 2, '10', '2021-11-23 08:31:47', '2021-11-23 08:31:47'),
(228, 14, 1, '1', '2021-11-23 08:31:47', '2021-11-23 08:31:47'),
(229, 17, 17, 'on', '2021-11-27 07:08:11', '2021-11-27 07:08:11'),
(230, 17, 11, 'on', '2021-11-27 07:08:11', '2021-11-27 07:08:11'),
(231, 17, 10, 'on', '2021-11-27 07:08:11', '2021-11-27 07:08:11'),
(232, 17, 9, 'on', '2021-11-27 07:08:11', '2021-11-27 07:08:11'),
(233, 17, 15, '1', '2021-11-27 07:08:11', '2021-11-27 07:08:11'),
(234, 17, 14, '1', '2021-11-27 07:08:11', '2021-11-27 07:08:11'),
(235, 17, 13, '1', '2021-11-27 07:08:11', '2021-11-27 07:08:11'),
(236, 17, 12, '2', '2021-11-27 07:08:11', '2021-11-27 07:08:11'),
(237, 17, 5, '2', '2021-11-27 07:08:11', '2021-11-27 07:08:11'),
(238, 17, 4, '15', '2021-11-27 07:08:11', '2021-11-27 07:08:11'),
(239, 17, 2, '2', '2021-11-27 07:08:11', '2021-11-27 07:08:11'),
(253, 19, 15, '1', '2021-12-04 09:21:08', '2021-12-04 09:21:08'),
(254, 19, 14, '1', '2021-12-04 09:21:08', '2021-12-04 09:21:08'),
(255, 19, 13, '1', '2021-12-04 09:21:09', '2021-12-04 09:21:09'),
(256, 19, 12, '1', '2021-12-04 09:21:09', '2021-12-04 09:21:09'),
(257, 19, 5, '1', '2021-12-04 09:21:09', '2021-12-04 09:21:09'),
(258, 19, 4, '1', '2021-12-04 09:21:09', '2021-12-04 09:21:09'),
(271, 18, 9, 'on', '2021-12-04 09:27:00', '2021-12-04 09:27:00'),
(272, 18, 15, '1', '2021-12-04 09:27:00', '2021-12-04 09:27:00'),
(273, 18, 14, '1', '2021-12-04 09:27:00', '2021-12-04 09:27:00'),
(274, 18, 13, '1', '2021-12-04 09:27:00', '2021-12-04 09:27:00'),
(275, 18, 12, '1', '2021-12-04 09:27:00', '2021-12-04 09:27:00'),
(276, 18, 5, '1', '2021-12-04 09:27:00', '2021-12-04 09:27:00'),
(283, 21, 16, '1', '2021-12-04 17:46:28', '2021-12-04 17:46:28'),
(284, 21, 15, '1', '2021-12-04 17:46:28', '2021-12-04 17:46:28'),
(285, 21, 14, '1', '2021-12-04 17:46:29', '2021-12-04 17:46:29'),
(286, 21, 13, '1', '2021-12-04 17:46:29', '2021-12-04 17:46:29'),
(287, 21, 12, '1', '2021-12-04 17:46:29', '2021-12-04 17:46:29'),
(288, 21, 5, '1', '2021-12-04 17:46:29', '2021-12-04 17:46:29'),
(289, 22, 22, 'on', '2021-12-16 08:56:04', '2021-12-16 08:56:04'),
(290, 22, 17, 'on', '2021-12-16 08:56:04', '2021-12-16 08:56:04'),
(291, 22, 10, 'on', '2021-12-16 08:56:04', '2021-12-16 08:56:04'),
(292, 22, 9, 'on', '2021-12-16 08:56:04', '2021-12-16 08:56:04'),
(293, 22, 8, 'on', '2021-12-16 08:56:04', '2021-12-16 08:56:04'),
(294, 22, 16, '4', '2021-12-16 08:56:04', '2021-12-16 08:56:04'),
(295, 22, 15, '5', '2021-12-16 08:56:04', '2021-12-16 08:56:04'),
(296, 22, 14, '5', '2021-12-16 08:56:04', '2021-12-16 08:56:04'),
(297, 22, 13, '4', '2021-12-16 08:56:04', '2021-12-16 08:56:04'),
(298, 22, 12, '5', '2021-12-16 08:56:04', '2021-12-16 08:56:04'),
(299, 22, 5, '5', '2021-12-16 08:56:04', '2021-12-16 08:56:04'),
(300, 22, 4, '4', '2021-12-16 08:56:04', '2021-12-16 08:56:04'),
(301, 22, 3, '5', '2021-12-16 08:56:04', '2021-12-16 08:56:04'),
(302, 22, 2, '4', '2021-12-16 08:56:04', '2021-12-16 08:56:04'),
(303, 22, 1, '4', '2021-12-16 08:56:04', '2021-12-16 08:56:04'),
(304, 23, 22, 'on', '2021-12-16 10:07:03', '2021-12-16 10:07:03'),
(305, 23, 17, 'on', '2021-12-16 10:07:03', '2021-12-16 10:07:03'),
(306, 23, 11, 'on', '2021-12-16 10:07:03', '2021-12-16 10:07:03'),
(307, 23, 10, 'on', '2021-12-16 10:07:03', '2021-12-16 10:07:03'),
(308, 23, 9, 'on', '2021-12-16 10:07:03', '2021-12-16 10:07:03'),
(309, 23, 8, 'on', '2021-12-16 10:07:03', '2021-12-16 10:07:03'),
(310, 23, 7, 'on', '2021-12-16 10:07:03', '2021-12-16 10:07:03'),
(311, 23, 6, 'on', '2021-12-16 10:07:03', '2021-12-16 10:07:03'),
(312, 23, 16, '1', '2021-12-16 10:07:03', '2021-12-16 10:07:03'),
(313, 23, 15, '1', '2021-12-16 10:07:03', '2021-12-16 10:07:03'),
(314, 23, 14, '1', '2021-12-16 10:07:03', '2021-12-16 10:07:03'),
(315, 23, 13, '1', '2021-12-16 10:07:03', '2021-12-16 10:07:03'),
(316, 23, 12, '1', '2021-12-16 10:07:03', '2021-12-16 10:07:03'),
(317, 23, 5, '1', '2021-12-16 10:07:03', '2021-12-16 10:07:03'),
(318, 23, 4, '1', '2021-12-16 10:07:03', '2021-12-16 10:07:03'),
(319, 23, 3, '1', '2021-12-16 10:07:03', '2021-12-16 10:07:03'),
(320, 23, 2, '1', '2021-12-16 10:07:03', '2021-12-16 10:07:03'),
(321, 23, 1, '1', '2021-12-16 10:07:03', '2021-12-16 10:07:03'),
(322, 24, 10, 'on', '2021-12-16 10:40:18', '2021-12-16 10:40:18'),
(323, 24, 9, 'on', '2021-12-16 10:40:18', '2021-12-16 10:40:18'),
(324, 24, 8, 'on', '2021-12-16 10:40:18', '2021-12-16 10:40:18'),
(325, 24, 7, 'on', '2021-12-16 10:40:18', '2021-12-16 10:40:18'),
(326, 24, 6, 'on', '2021-12-16 10:40:18', '2021-12-16 10:40:18'),
(327, 24, 20, 'on', '2021-12-16 10:40:18', '2021-12-16 10:40:18'),
(328, 24, 16, '1', '2021-12-16 10:40:18', '2021-12-16 10:40:18'),
(329, 24, 15, '1', '2021-12-16 10:40:18', '2021-12-16 10:40:18'),
(330, 24, 14, '1', '2021-12-16 10:40:18', '2021-12-16 10:40:18'),
(331, 24, 13, '1', '2021-12-16 10:40:18', '2021-12-16 10:40:18'),
(332, 24, 12, '1', '2021-12-16 10:40:18', '2021-12-16 10:40:18'),
(333, 24, 5, '1', '2021-12-16 10:40:18', '2021-12-16 10:40:18'),
(334, 24, 4, '1', '2021-12-16 10:40:18', '2021-12-16 10:40:18'),
(335, 24, 3, '1', '2021-12-16 10:40:18', '2021-12-16 10:40:18'),
(336, 24, 2, '1', '2021-12-16 10:40:18', '2021-12-16 10:40:18'),
(337, 24, 1, '1', '2021-12-16 10:40:18', '2021-12-16 10:40:18'),
(338, 25, 6, 'on', '2021-12-16 11:11:37', '2021-12-16 11:11:37'),
(339, 25, 18, 'on', '2021-12-16 11:11:37', '2021-12-16 11:11:37'),
(340, 25, 16, '1', '2021-12-16 11:11:37', '2021-12-16 11:11:37'),
(341, 25, 15, '1', '2021-12-16 11:11:37', '2021-12-16 11:11:37'),
(342, 25, 14, '1', '2021-12-16 11:11:37', '2021-12-16 11:11:37'),
(343, 25, 13, '1', '2021-12-16 11:11:37', '2021-12-16 11:11:37'),
(344, 25, 12, '1', '2021-12-16 11:11:37', '2021-12-16 11:11:37'),
(345, 25, 5, '1', '2021-12-16 11:11:37', '2021-12-16 11:11:37'),
(346, 25, 4, '1', '2021-12-16 11:11:37', '2021-12-16 11:11:37'),
(347, 25, 3, '1', '2021-12-16 11:11:37', '2021-12-16 11:11:37'),
(348, 25, 2, '1', '2021-12-16 11:11:37', '2021-12-16 11:11:37'),
(349, 25, 1, '21', '2021-12-16 11:11:37', '2021-12-16 11:11:37');

-- --------------------------------------------------------

--
-- Table structure for table `warehouse_feature_keys`
--

CREATE TABLE `warehouse_feature_keys` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key_type` enum('boolean','string') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'boolean',
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `warehouse_feature_keys`
--

INSERT INTO `warehouse_feature_keys` (`id`, `key`, `key_type`, `status`, `created_at`, `updated_at`) VALUES
(1, 'washrooms', 'string', 1, '2021-11-11 12:29:18', '2021-11-11 12:29:18'),
(2, 'fans', 'string', 1, '2021-11-11 12:29:19', '2021-11-11 12:29:19'),
(3, 'lights', 'string', 1, '2021-11-11 12:29:19', '2021-11-11 12:29:19'),
(4, 'rooms', 'string', 1, '2021-11-11 12:29:19', '2021-11-11 12:29:19'),
(5, 'parking spaces', 'string', 1, '2021-11-11 12:29:19', '2021-11-11 12:29:19'),
(6, 'electrical backup', 'boolean', 1, '2021-11-11 12:29:19', '2021-11-11 12:29:19'),
(7, 'waste disposal', 'boolean', 1, '2021-11-11 12:29:19', '2021-11-11 12:29:19'),
(8, 'refrigerator facility (cold storage)', 'boolean', 1, '2021-11-11 12:29:19', '2021-11-11 12:29:19'),
(9, 'shelves', 'boolean', 1, '2021-11-11 12:29:19', '2021-11-11 12:29:19'),
(10, 'safety', 'boolean', 1, '2021-11-11 12:29:19', '2021-11-11 12:29:19'),
(11, 'security', 'boolean', 1, '2021-11-11 12:29:19', '2021-11-11 12:29:19'),
(12, 'washrooms', 'string', 1, '2021-11-23 07:50:26', '2021-11-23 07:50:26'),
(13, 'fans', 'string', 1, '2021-11-23 07:50:26', '2021-11-23 07:50:26'),
(14, 'lights', 'string', 1, '2021-11-23 07:50:26', '2021-11-23 07:50:26'),
(15, 'rooms', 'string', 1, '2021-11-23 07:50:26', '2021-11-23 07:50:26'),
(16, 'parking spaces', 'string', 1, '2021-11-23 07:50:26', '2021-11-23 07:50:26'),
(17, 'electrical backup', 'boolean', 1, '2021-11-23 07:50:26', '2021-11-23 07:50:26'),
(18, 'waste disposal', 'boolean', 1, '2021-11-23 07:50:26', '2021-11-23 07:50:26'),
(19, 'refrigerator facility (cold storage)', 'boolean', 1, '2021-11-23 07:50:26', '2021-11-23 07:50:26'),
(20, 'shelves', 'boolean', 1, '2021-11-23 07:50:26', '2021-11-23 07:50:26'),
(21, 'safety', 'boolean', 1, '2021-11-23 07:50:27', '2021-11-23 07:50:27'),
(22, 'security', 'boolean', 1, '2021-11-23 07:50:27', '2021-11-23 07:50:27');

-- --------------------------------------------------------

--
-- Table structure for table `warehouse_images`
--

CREATE TABLE `warehouse_images` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `warehouse_id` bigint(20) UNSIGNED NOT NULL,
  `image_path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_main` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `warehouse_images`
--

INSERT INTO `warehouse_images` (`id`, `warehouse_id`, `image_path`, `title`, `is_main`, `created_at`, `updated_at`) VALUES
(1, 2, 'http://localhost:8000/img/warehouse.jpg', 'warehouse image', 1, '2021-11-23 07:50:35', '2021-11-23 07:50:35'),
(2, 3, 'http://localhost:8000/img/warehouse.jpg', 'warehouse image', 1, '2021-11-23 07:50:36', '2021-11-23 07:50:36'),
(3, 4, 'http://localhost:8000/img/warehouse.jpg', 'warehouse image', 0, '2021-11-23 07:50:37', '2021-11-23 07:50:37'),
(4, 5, 'http://localhost:8000/img/warehouse.jpg', 'warehouse image', 0, '2021-11-23 07:50:38', '2021-11-23 07:50:38'),
(5, 6, 'http://localhost:8000/img/warehouse.jpg', 'warehouse image', 0, '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(6, 7, 'http://localhost:8000/img/warehouse.jpg', 'warehouse image', 1, '2021-11-23 07:50:39', '2021-11-23 07:50:39'),
(7, 8, 'http://localhost:8000/img/warehouse.jpg', 'warehouse image', 1, '2021-11-23 07:50:40', '2021-11-23 07:50:40'),
(8, 9, 'http://localhost:8000/img/warehouse.jpg', 'warehouse image', 0, '2021-11-23 07:50:41', '2021-11-23 07:50:41'),
(9, 10, 'http://localhost:8000/img/warehouse.jpg', 'warehouse image', 0, '2021-11-23 07:50:42', '2021-11-23 07:50:42'),
(10, 11, 'http://localhost:8000/img/warehouse.jpg', 'warehouse image', 1, '2021-11-23 07:50:43', '2021-11-23 07:50:43'),
(11, 14, 'public/warehouse/images/zZIAJGvWxHD8XtVpl6M20z5AKo0RS3tk6PQbOS8f.jpg', 'pakistn.jpg', 0, '2021-11-23 08:31:47', '2021-11-23 08:31:47'),
(12, 14, 'public/warehouse/images/9SKRIYl6BKtY6aGuiciK3JCYpsbi8uU3yzOsnXgJ.jpg', 'saudi arabia.jpg', 1, '2021-11-23 08:31:47', '2021-11-23 08:31:47'),
(13, 17, 'public/warehouse/images/gfpEJbPwk7TmCd9pxs2LiBcWxykT38kXKSNp0uX6.jpg', 'pakistn.jpg', 1, '2021-11-27 07:08:11', '2021-11-27 07:08:11'),
(14, 18, 'public/warehouse/images/Ard6Bd95q7QrOcWs4GzlOI6uFe7K2xyjaUZhXL8U.jpg', 'pakistn.jpg', 1, '2021-12-03 11:22:59', '2021-12-03 11:22:59'),
(15, 21, 'public/warehouse/images/pvZpnaQDPF3Mvc2LU7M2SKbwrsYZ1Dx92Xfd6oXS.jpg', 'saudi arabia.jpg', 1, '2021-12-04 17:11:20', '2021-12-04 17:11:20'),
(16, 22, 'public/warehouse/images/17rJRwaRqsMp25N7QTT5GQWG0yJp8N59N8JtCZYZ.png', 'avatar.png', 1, '2021-12-16 08:56:04', '2021-12-16 08:56:04'),
(17, 23, 'warehouse/61bb0fc769344/1639649223-pxaC-warehouse-image.jpg', '123136979_818710618931666_8864283153276116360_n.jpg', 1, '2021-12-16 10:07:03', '2021-12-16 10:07:03'),
(18, 24, 'warehouse/61bb1792b74d4/1639651218-n3IP-warehouse-image.jpg', 'sd', 1, '2021-12-16 10:40:18', '2021-12-16 10:40:18'),
(19, 25, 'warehouse/61bb1ee9bbc31/1639653097-mJHD-warehouse-image.jpg', 'warehouse-61bb1ee9bc695', 1, '2021-12-16 11:11:37', '2021-12-16 11:11:37');

-- --------------------------------------------------------

--
-- Table structure for table `warehouse_related_loggings`
--

CREATE TABLE `warehouse_related_loggings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `ip` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`data`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `additional_business_details`
--
ALTER TABLE `additional_business_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `advertisments`
--
ALTER TABLE `advertisments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `badges`
--
ALTER TABLE `badges`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `booking_agreement_terms`
--
ALTER TABLE `booking_agreement_terms`
  ADD PRIMARY KEY (`id`),
  ADD KEY `booking_agreement_terms_booking_id_foreign` (`booking_id`),
  ADD KEY `booking_agreement_terms_created_by_foreign` (`created_by`),
  ADD KEY `booking_agreement_terms_creator_role_foreign` (`creator_role`),
  ADD KEY `booking_agreement_terms_payment_method_id_foreign` (`payment_method_id`);

--
-- Indexes for table `business_awards`
--
ALTER TABLE `business_awards`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `business_certifications`
--
ALTER TABLE `business_certifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `business_contact_details`
--
ALTER TABLE `business_contact_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `business_details`
--
ALTER TABLE `business_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `business_details_user_id_foreign` (`user_id`),
  ADD KEY `business_details_city_id_foreign` (`city_id`);

--
-- Indexes for table `business_directors`
--
ALTER TABLE `business_directors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `business_mode_of_payments`
--
ALTER TABLE `business_mode_of_payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `business_photos`
--
ALTER TABLE `business_photos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `business_types`
--
ALTER TABLE `business_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `catalogs`
--
ALTER TABLE `catalogs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `catalogs_user_id_foreign` (`user_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `categories_parent_cat_id_index` (`parent_cat_id`);

--
-- Indexes for table `challans`
--
ALTER TABLE `challans`
  ADD PRIMARY KEY (`id`),
  ADD KEY `challans_from_foreign` (`from`),
  ADD KEY `challans_to_foreign` (`to`);

--
-- Indexes for table `chat_conversations`
--
ALTER TABLE `chat_conversations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chat_labels`
--
ALTER TABLE `chat_labels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `chat_labels_label_id_foreign` (`label_id`),
  ADD KEY `chat_labels_conversation_id_foreign` (`conversation_id`),
  ADD KEY `chat_labels_user_id_foreign` (`user_id`);

--
-- Indexes for table `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `chat_messages_participation_id_foreign` (`participation_id`),
  ADD KEY `chat_messages_conversation_id_foreign` (`conversation_id`);

--
-- Indexes for table `chat_message_notifications`
--
ALTER TABLE `chat_message_notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `participation_message_index` (`participation_id`,`message_id`),
  ADD KEY `chat_message_notifications_message_id_foreign` (`message_id`),
  ADD KEY `chat_message_notifications_conversation_id_foreign` (`conversation_id`);

--
-- Indexes for table `chat_participation`
--
ALTER TABLE `chat_participation`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `participation_index` (`conversation_id`,`messageable_id`,`messageable_type`);

--
-- Indexes for table `chat_reminders`
--
ALTER TABLE `chat_reminders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `chat_reminders_conversation_id_foreign` (`conversation_id`),
  ADD KEY `chat_reminders_user_id_foreign` (`user_id`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `clients_user_id_client_id_unique` (`user_id`,`client_id`);

--
-- Indexes for table `company_page_banners`
--
ALTER TABLE `company_page_banners`
  ADD PRIMARY KEY (`id`),
  ADD KEY `company_page_banners_user_id_foreign` (`user_id`);

--
-- Indexes for table `company_page_products`
--
ALTER TABLE `company_page_products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `company_page_products_user_id_product_id_display_section_unique` (`user_id`,`product_id`,`display_section`),
  ADD KEY `company_page_products_product_id_foreign` (`product_id`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `home_page_categories`
--
ALTER TABLE `home_page_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `home_page_categories_category_id_unique` (`category_id`);

--
-- Indexes for table `inventory_product_definitions`
--
ALTER TABLE `inventory_product_definitions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `inventory_product_definitions_product_id_unique` (`product_id`);

--
-- Indexes for table `inventory_product_pricings`
--
ALTER TABLE `inventory_product_pricings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `inventory_product_pricings_product_id_unique` (`product_id`);

--
-- Indexes for table `invitations`
--
ALTER TABLE `invitations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `invitations_token_unique` (`token`);

--
-- Indexes for table `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `invoices_number_unique` (`number`),
  ADD KEY `invoices_seller_id_foreign` (`seller_id`),
  ADD KEY `invoices_buyer_id_foreign` (`buyer_id`),
  ADD KEY `invoices_updated_by_foreign` (`updated_by`);

--
-- Indexes for table `invoice_attachments`
--
ALTER TABLE `invoice_attachments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `invoice_attachments_invoice_id_foreign` (`invoice_id`);

--
-- Indexes for table `invoice_items`
--
ALTER TABLE `invoice_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `invoice_items_invoice_id_foreign` (`invoice_id`),
  ADD KEY `invoice_items_product_id_foreign` (`product_id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `labels`
--
ALTER TABLE `labels`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lead_quotations`
--
ALTER TABLE `lead_quotations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lead_quotations_lead_id_foreign` (`lead_id`),
  ADD KEY `lead_quotations_seller_id_foreign` (`seller_id`);

--
-- Indexes for table `localities`
--
ALTER TABLE `localities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `localities_city_id_foreign` (`city_id`);

--
-- Indexes for table `matter_sheets`
--
ALTER TABLE `matter_sheets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `matter_sheets_user_id_foreign` (`user_id`),
  ADD KEY `matter_sheets_category_id_foreign` (`category_id`);

--
-- Indexes for table `matter_sheet_products`
--
ALTER TABLE `matter_sheet_products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `matter_sheet_products_matter_sheet_id_foreign` (`matter_sheet_id`),
  ADD KEY `matter_sheet_products_category_id_foreign` (`category_id`),
  ADD KEY `matter_sheet_products_user_id_foreign` (`user_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `mode_of_payments`
--
ALTER TABLE `mode_of_payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`);

--
-- Indexes for table `notification_subscriptions`
--
ALTER TABLE `notification_subscriptions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notification_subscriptions_user_id_foreign` (`user_id`),
  ADD KEY `notification_subscriptions_notification_type_id_foreign` (`notification_type_id`);

--
-- Indexes for table `notification_types`
--
ALTER TABLE `notification_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `notification_types_slug_unique` (`slug`);

--
-- Indexes for table `otps`
--
ALTER TABLE `otps`
  ADD PRIMARY KEY (`id`),
  ADD KEY `otps_client_req_id_uuid_status_type_index` (`client_req_id`,`uuid`,`status`,`type`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `payments_model_type_model_id_index` (`model_type`,`model_id`),
  ADD KEY `payments_payment_method_id_foreign` (`payment_method_id`),
  ADD KEY `payments_updated_by_foreign` (`updated_by`);

--
-- Indexes for table `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `plans`
--
ALTER TABLE `plans`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `plans_slug_unique` (`slug`);

--
-- Indexes for table `plan_features`
--
ALTER TABLE `plan_features`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `plan_features_plan_id_slug_unique` (`plan_id`,`slug`);

--
-- Indexes for table `plan_subscriptions`
--
ALTER TABLE `plan_subscriptions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `plan_subscriptions_slug_unique` (`slug`),
  ADD KEY `plan_subscriptions_user_type_user_id_index` (`subscriber_type`,`subscriber_id`),
  ADD KEY `plan_subscriptions_plan_id_foreign` (`plan_id`);

--
-- Indexes for table `plan_subscription_usage`
--
ALTER TABLE `plan_subscription_usage`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `plan_subscription_usage_unique` (`subscription_id`,`feature_id`,`deleted_at`),
  ADD KEY `plan_subscription_usage_feature_id_foreign` (`feature_id`);

--
-- Indexes for table `popular_warehouses`
--
ALTER TABLE `popular_warehouses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `products_category_id_foreign` (`category_id`),
  ADD KEY `products_user_id_foreign` (`user_id`);

--
-- Indexes for table `product_buy_requirements`
--
ALTER TABLE `product_buy_requirements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_buy_requirements_user_id_foreign` (`user_id`);

--
-- Indexes for table `product_details`
--
ALTER TABLE `product_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_details_product_id_foreign` (`product_id`);

--
-- Indexes for table `product_documents`
--
ALTER TABLE `product_documents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_documents_product_id_foreign` (`product_id`);

--
-- Indexes for table `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_images_product_id_foreign` (`product_id`);

--
-- Indexes for table `product_videos`
--
ALTER TABLE `product_videos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_videos_product_id_foreign` (`product_id`);

--
-- Indexes for table `promocodes`
--
ALTER TABLE `promocodes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `promocodes_code_unique` (`code`);

--
-- Indexes for table `promocode_user`
--
ALTER TABLE `promocode_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `promocode_user_user_id_foreign` (`user_id`),
  ADD KEY `promocode_user_promocode_id_foreign` (`promocode_id`);

--
-- Indexes for table `promotional_products`
--
ALTER TABLE `promotional_products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `promotional_products_product_id_foreign` (`product_id`),
  ADD KEY `promotional_products_promotional_product_id_foreign` (`promotional_product_id`);

--
-- Indexes for table `property_types`
--
ALTER TABLE `property_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchase_orders`
--
ALTER TABLE `purchase_orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `purchase_orders_number_unique` (`number`),
  ADD KEY `purchase_orders_created_by_foreign` (`created_by`);

--
-- Indexes for table `purchase_returns`
--
ALTER TABLE `purchase_returns`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quotations`
--
ALTER TABLE `quotations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `quotations_seller_id_foreign` (`seller_id`),
  ADD KEY `quotations_buyer_id_foreign` (`buyer_id`);

--
-- Indexes for table `quotation_products`
--
ALTER TABLE `quotation_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quotation_requests`
--
ALTER TABLE `quotation_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `quotation_requests_seller_id_foreign` (`seller_id`),
  ADD KEY `quotation_requests_buyer_id_foreign` (`buyer_id`);

--
-- Indexes for table `quotation_request_details`
--
ALTER TABLE `quotation_request_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quotation_seller_details`
--
ALTER TABLE `quotation_seller_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quotation_terms`
--
ALTER TABLE `quotation_terms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `shoppingcart`
--
ALTER TABLE `shoppingcart`
  ADD PRIMARY KEY (`identifier`,`instance`);

--
-- Indexes for table `subscription_orders`
--
ALTER TABLE `subscription_orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subscription_orders_user_id_foreign` (`user_id`),
  ADD KEY `subscription_orders_plan_id_foreign` (`plan_id`),
  ADD KEY `subscription_orders_payment_method_id_foreign` (`payment_method_id`);

--
-- Indexes for table `subscription_payment_images`
--
ALTER TABLE `subscription_payment_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscription_payment_logs`
--
ALTER TABLE `subscription_payment_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subscription_payment_logs_subscription_order_id_foreign` (`subscription_order_id`),
  ADD KEY `subscription_payment_logs_added_by_foreign` (`added_by`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`id`),
  ADD KEY `teams_user_id_index` (`user_id`);

--
-- Indexes for table `team_user`
--
ALTER TABLE `team_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `team_user_team_id_user_id_unique` (`team_id`,`user_id`);

--
-- Indexes for table `testimonials`
--
ALTER TABLE `testimonials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaction_logs`
--
ALTER TABLE `transaction_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `transaction_logs_model_type_model_id_index` (`model_type`,`model_id`),
  ADD KEY `transaction_logs_user_id_foreign` (`user_id`);

--
-- Indexes for table `trending_categories`
--
ALTER TABLE `trending_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trending_products`
--
ALTER TABLE `trending_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_phone_unique` (`phone`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `users_city_id_foreign` (`city_id`);

--
-- Indexes for table `user_badges`
--
ALTER TABLE `user_badges`
  ADD KEY `user_badges_user_id_foreign` (`user_id`),
  ADD KEY `user_badges_badge_id_foreign` (`badge_id`);

--
-- Indexes for table `user_favorites`
--
ALTER TABLE `user_favorites`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_favorite_by_favorable` (`user_id`,`favorable_id`,`favorable_type`),
  ADD KEY `user_favorites_favorable_type_favorable_id_index` (`favorable_type`,`favorable_id`);

--
-- Indexes for table `user_product_interests`
--
ALTER TABLE `user_product_interests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_product_interests_user_id_foreign` (`user_id`);

--
-- Indexes for table `user_product_services`
--
ALTER TABLE `user_product_services`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_product_services_user_id_foreign` (`user_id`),
  ADD KEY `user_product_services_business_type_id_foreign` (`business_type_id`);

--
-- Indexes for table `warehouses`
--
ALTER TABLE `warehouses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `warehouses_user_id_foreign` (`user_id`),
  ADD KEY `warehouses_city_id_foreign` (`city_id`),
  ADD KEY `warehouses_locality_id_foreign` (`locality_id`),
  ADD KEY `warehouses_property_type_id_foreign` (`property_type_id`);

--
-- Indexes for table `warehouse_bookings`
--
ALTER TABLE `warehouse_bookings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `warehouse_bookings_warehouse_id_foreign` (`warehouse_id`),
  ADD KEY `warehouse_bookings_booked_by_foreign` (`booked_by`);

--
-- Indexes for table `warehouse_features`
--
ALTER TABLE `warehouse_features`
  ADD PRIMARY KEY (`id`),
  ADD KEY `warehouse_features_warehouse_id_foreign` (`warehouse_id`),
  ADD KEY `warehouse_features_feature_id_foreign` (`feature_id`);

--
-- Indexes for table `warehouse_feature_keys`
--
ALTER TABLE `warehouse_feature_keys`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `warehouse_images`
--
ALTER TABLE `warehouse_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `warehouse_images_warehouse_id_foreign` (`warehouse_id`);

--
-- Indexes for table `warehouse_related_loggings`
--
ALTER TABLE `warehouse_related_loggings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `warehouse_related_loggings_model_type_model_id_index` (`model_type`,`model_id`),
  ADD KEY `warehouse_related_loggings_user_id_foreign` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `additional_business_details`
--
ALTER TABLE `additional_business_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `advertisments`
--
ALTER TABLE `advertisments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `badges`
--
ALTER TABLE `badges`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `booking_agreement_terms`
--
ALTER TABLE `booking_agreement_terms`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `business_awards`
--
ALTER TABLE `business_awards`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `business_certifications`
--
ALTER TABLE `business_certifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `business_contact_details`
--
ALTER TABLE `business_contact_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `business_details`
--
ALTER TABLE `business_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `business_directors`
--
ALTER TABLE `business_directors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `business_mode_of_payments`
--
ALTER TABLE `business_mode_of_payments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `business_photos`
--
ALTER TABLE `business_photos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `business_types`
--
ALTER TABLE `business_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `catalogs`
--
ALTER TABLE `catalogs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `challans`
--
ALTER TABLE `challans`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `chat_conversations`
--
ALTER TABLE `chat_conversations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `chat_labels`
--
ALTER TABLE `chat_labels`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `chat_messages`
--
ALTER TABLE `chat_messages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `chat_message_notifications`
--
ALTER TABLE `chat_message_notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `chat_participation`
--
ALTER TABLE `chat_participation`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `chat_reminders`
--
ALTER TABLE `chat_reminders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `company_page_banners`
--
ALTER TABLE `company_page_banners`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `company_page_products`
--
ALTER TABLE `company_page_products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `home_page_categories`
--
ALTER TABLE `home_page_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `inventory_product_definitions`
--
ALTER TABLE `inventory_product_definitions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `inventory_product_pricings`
--
ALTER TABLE `inventory_product_pricings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `invitations`
--
ALTER TABLE `invitations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `invoices`
--
ALTER TABLE `invoices`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `invoice_attachments`
--
ALTER TABLE `invoice_attachments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `invoice_items`
--
ALTER TABLE `invoice_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `labels`
--
ALTER TABLE `labels`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `lead_quotations`
--
ALTER TABLE `lead_quotations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `localities`
--
ALTER TABLE `localities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `matter_sheets`
--
ALTER TABLE `matter_sheets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `matter_sheet_products`
--
ALTER TABLE `matter_sheet_products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=131;

--
-- AUTO_INCREMENT for table `mode_of_payments`
--
ALTER TABLE `mode_of_payments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `notification_subscriptions`
--
ALTER TABLE `notification_subscriptions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notification_types`
--
ALTER TABLE `notification_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `otps`
--
ALTER TABLE `otps`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment_methods`
--
ALTER TABLE `payment_methods`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `plans`
--
ALTER TABLE `plans`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `plan_features`
--
ALTER TABLE `plan_features`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `plan_subscriptions`
--
ALTER TABLE `plan_subscriptions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `plan_subscription_usage`
--
ALTER TABLE `plan_subscription_usage`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `popular_warehouses`
--
ALTER TABLE `popular_warehouses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `product_buy_requirements`
--
ALTER TABLE `product_buy_requirements`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `product_details`
--
ALTER TABLE `product_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `product_documents`
--
ALTER TABLE `product_documents`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `product_images`
--
ALTER TABLE `product_images`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `product_videos`
--
ALTER TABLE `product_videos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `promocodes`
--
ALTER TABLE `promocodes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `promocode_user`
--
ALTER TABLE `promocode_user`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `promotional_products`
--
ALTER TABLE `promotional_products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `property_types`
--
ALTER TABLE `property_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `purchase_orders`
--
ALTER TABLE `purchase_orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `purchase_returns`
--
ALTER TABLE `purchase_returns`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `quotations`
--
ALTER TABLE `quotations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `quotation_products`
--
ALTER TABLE `quotation_products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `quotation_requests`
--
ALTER TABLE `quotation_requests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `quotation_request_details`
--
ALTER TABLE `quotation_request_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `quotation_seller_details`
--
ALTER TABLE `quotation_seller_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `quotation_terms`
--
ALTER TABLE `quotation_terms`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `subscription_orders`
--
ALTER TABLE `subscription_orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `subscription_payment_images`
--
ALTER TABLE `subscription_payment_images`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `subscription_payment_logs`
--
ALTER TABLE `subscription_payment_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `teams`
--
ALTER TABLE `teams`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `team_user`
--
ALTER TABLE `team_user`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `testimonials`
--
ALTER TABLE `testimonials`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `transaction_logs`
--
ALTER TABLE `transaction_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `trending_categories`
--
ALTER TABLE `trending_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `trending_products`
--
ALTER TABLE `trending_products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `user_favorites`
--
ALTER TABLE `user_favorites`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_product_interests`
--
ALTER TABLE `user_product_interests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user_product_services`
--
ALTER TABLE `user_product_services`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `warehouses`
--
ALTER TABLE `warehouses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `warehouse_bookings`
--
ALTER TABLE `warehouse_bookings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `warehouse_features`
--
ALTER TABLE `warehouse_features`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=350;

--
-- AUTO_INCREMENT for table `warehouse_feature_keys`
--
ALTER TABLE `warehouse_feature_keys`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `warehouse_images`
--
ALTER TABLE `warehouse_images`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `warehouse_related_loggings`
--
ALTER TABLE `warehouse_related_loggings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `booking_agreement_terms`
--
ALTER TABLE `booking_agreement_terms`
  ADD CONSTRAINT `booking_agreement_terms_booking_id_foreign` FOREIGN KEY (`booking_id`) REFERENCES `warehouse_bookings` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `booking_agreement_terms_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `booking_agreement_terms_creator_role_foreign` FOREIGN KEY (`creator_role`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `booking_agreement_terms_payment_method_id_foreign` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `business_details`
--
ALTER TABLE `business_details`
  ADD CONSTRAINT `business_details_city_id_foreign` FOREIGN KEY (`city_id`) REFERENCES `cities` (`id`),
  ADD CONSTRAINT `business_details_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `catalogs`
--
ALTER TABLE `catalogs`
  ADD CONSTRAINT `catalogs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `challans`
--
ALTER TABLE `challans`
  ADD CONSTRAINT `challans_from_foreign` FOREIGN KEY (`from`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `challans_to_foreign` FOREIGN KEY (`to`) REFERENCES `users` (`id`);

--
-- Constraints for table `chat_labels`
--
ALTER TABLE `chat_labels`
  ADD CONSTRAINT `chat_labels_conversation_id_foreign` FOREIGN KEY (`conversation_id`) REFERENCES `chat_conversations` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `chat_labels_label_id_foreign` FOREIGN KEY (`label_id`) REFERENCES `labels` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `chat_labels_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD CONSTRAINT `chat_messages_conversation_id_foreign` FOREIGN KEY (`conversation_id`) REFERENCES `chat_conversations` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `chat_messages_participation_id_foreign` FOREIGN KEY (`participation_id`) REFERENCES `chat_participation` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `chat_message_notifications`
--
ALTER TABLE `chat_message_notifications`
  ADD CONSTRAINT `chat_message_notifications_conversation_id_foreign` FOREIGN KEY (`conversation_id`) REFERENCES `chat_conversations` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `chat_message_notifications_message_id_foreign` FOREIGN KEY (`message_id`) REFERENCES `chat_messages` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `chat_message_notifications_participation_id_foreign` FOREIGN KEY (`participation_id`) REFERENCES `chat_participation` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `chat_participation`
--
ALTER TABLE `chat_participation`
  ADD CONSTRAINT `chat_participation_conversation_id_foreign` FOREIGN KEY (`conversation_id`) REFERENCES `chat_conversations` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `chat_reminders`
--
ALTER TABLE `chat_reminders`
  ADD CONSTRAINT `chat_reminders_conversation_id_foreign` FOREIGN KEY (`conversation_id`) REFERENCES `chat_conversations` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `chat_reminders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `clients`
--
ALTER TABLE `clients`
  ADD CONSTRAINT `clients_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `company_page_banners`
--
ALTER TABLE `company_page_banners`
  ADD CONSTRAINT `company_page_banners_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `company_page_products`
--
ALTER TABLE `company_page_products`
  ADD CONSTRAINT `company_page_products_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `company_page_products_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `home_page_categories`
--
ALTER TABLE `home_page_categories`
  ADD CONSTRAINT `home_page_categories_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);

--
-- Constraints for table `inventory_product_definitions`
--
ALTER TABLE `inventory_product_definitions`
  ADD CONSTRAINT `inventory_product_definitions_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `inventory_product_pricings`
--
ALTER TABLE `inventory_product_pricings`
  ADD CONSTRAINT `inventory_product_pricings_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `invoices`
--
ALTER TABLE `invoices`
  ADD CONSTRAINT `invoices_buyer_id_foreign` FOREIGN KEY (`buyer_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `invoices_seller_id_foreign` FOREIGN KEY (`seller_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `invoices_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `invoice_attachments`
--
ALTER TABLE `invoice_attachments`
  ADD CONSTRAINT `invoice_attachments_invoice_id_foreign` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`);

--
-- Constraints for table `invoice_items`
--
ALTER TABLE `invoice_items`
  ADD CONSTRAINT `invoice_items_invoice_id_foreign` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`),
  ADD CONSTRAINT `invoice_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `lead_quotations`
--
ALTER TABLE `lead_quotations`
  ADD CONSTRAINT `lead_quotations_lead_id_foreign` FOREIGN KEY (`lead_id`) REFERENCES `product_buy_requirements` (`id`),
  ADD CONSTRAINT `lead_quotations_seller_id_foreign` FOREIGN KEY (`seller_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `localities`
--
ALTER TABLE `localities`
  ADD CONSTRAINT `localities_city_id_foreign` FOREIGN KEY (`city_id`) REFERENCES `cities` (`id`);

--
-- Constraints for table `matter_sheets`
--
ALTER TABLE `matter_sheets`
  ADD CONSTRAINT `matter_sheets_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `matter_sheets_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `matter_sheet_products`
--
ALTER TABLE `matter_sheet_products`
  ADD CONSTRAINT `matter_sheet_products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `matter_sheet_products_matter_sheet_id_foreign` FOREIGN KEY (`matter_sheet_id`) REFERENCES `matter_sheets` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `matter_sheet_products_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `notification_subscriptions`
--
ALTER TABLE `notification_subscriptions`
  ADD CONSTRAINT `notification_subscriptions_notification_type_id_foreign` FOREIGN KEY (`notification_type_id`) REFERENCES `notification_types` (`id`),
  ADD CONSTRAINT `notification_subscriptions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_payment_method_id_foreign` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods` (`id`),
  ADD CONSTRAINT `payments_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `plan_features`
--
ALTER TABLE `plan_features`
  ADD CONSTRAINT `plan_features_plan_id_foreign` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `plan_subscriptions`
--
ALTER TABLE `plan_subscriptions`
  ADD CONSTRAINT `plan_subscriptions_plan_id_foreign` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `plan_subscription_usage`
--
ALTER TABLE `plan_subscription_usage`
  ADD CONSTRAINT `plan_subscription_usage_feature_id_foreign` FOREIGN KEY (`feature_id`) REFERENCES `plan_features` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `plan_subscription_usage_subscription_id_foreign` FOREIGN KEY (`subscription_id`) REFERENCES `plan_subscriptions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `products_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `product_buy_requirements`
--
ALTER TABLE `product_buy_requirements`
  ADD CONSTRAINT `product_buy_requirements_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `product_details`
--
ALTER TABLE `product_details`
  ADD CONSTRAINT `product_details_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `product_documents`
--
ALTER TABLE `product_documents`
  ADD CONSTRAINT `product_documents_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `product_images`
--
ALTER TABLE `product_images`
  ADD CONSTRAINT `product_images_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `product_videos`
--
ALTER TABLE `product_videos`
  ADD CONSTRAINT `product_videos_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `promocode_user`
--
ALTER TABLE `promocode_user`
  ADD CONSTRAINT `promocode_user_promocode_id_foreign` FOREIGN KEY (`promocode_id`) REFERENCES `promocodes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `promocode_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `promotional_products`
--
ALTER TABLE `promotional_products`
  ADD CONSTRAINT `promotional_products_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `promotional_products_promotional_product_id_foreign` FOREIGN KEY (`promotional_product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `purchase_orders`
--
ALTER TABLE `purchase_orders`
  ADD CONSTRAINT `purchase_orders_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `quotations`
--
ALTER TABLE `quotations`
  ADD CONSTRAINT `quotations_buyer_id_foreign` FOREIGN KEY (`buyer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `quotations_seller_id_foreign` FOREIGN KEY (`seller_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `quotation_requests`
--
ALTER TABLE `quotation_requests`
  ADD CONSTRAINT `quotation_requests_buyer_id_foreign` FOREIGN KEY (`buyer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `quotation_requests_seller_id_foreign` FOREIGN KEY (`seller_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `subscription_orders`
--
ALTER TABLE `subscription_orders`
  ADD CONSTRAINT `subscription_orders_payment_method_id_foreign` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `subscription_orders_plan_id_foreign` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `subscription_orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `subscription_payment_logs`
--
ALTER TABLE `subscription_payment_logs`
  ADD CONSTRAINT `subscription_payment_logs_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `subscription_payment_logs_subscription_order_id_foreign` FOREIGN KEY (`subscription_order_id`) REFERENCES `subscription_orders` (`id`);

--
-- Constraints for table `transaction_logs`
--
ALTER TABLE `transaction_logs`
  ADD CONSTRAINT `transaction_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_city_id_foreign` FOREIGN KEY (`city_id`) REFERENCES `cities` (`id`);

--
-- Constraints for table `user_badges`
--
ALTER TABLE `user_badges`
  ADD CONSTRAINT `user_badges_badge_id_foreign` FOREIGN KEY (`badge_id`) REFERENCES `badges` (`id`),
  ADD CONSTRAINT `user_badges_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `user_favorites`
--
ALTER TABLE `user_favorites`
  ADD CONSTRAINT `user_favorites_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `user_product_interests`
--
ALTER TABLE `user_product_interests`
  ADD CONSTRAINT `user_product_interests_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `user_product_services`
--
ALTER TABLE `user_product_services`
  ADD CONSTRAINT `user_product_services_business_type_id_foreign` FOREIGN KEY (`business_type_id`) REFERENCES `business_types` (`id`),
  ADD CONSTRAINT `user_product_services_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `warehouses`
--
ALTER TABLE `warehouses`
  ADD CONSTRAINT `warehouses_city_id_foreign` FOREIGN KEY (`city_id`) REFERENCES `cities` (`id`),
  ADD CONSTRAINT `warehouses_locality_id_foreign` FOREIGN KEY (`locality_id`) REFERENCES `localities` (`id`),
  ADD CONSTRAINT `warehouses_property_type_id_foreign` FOREIGN KEY (`property_type_id`) REFERENCES `property_types` (`id`),
  ADD CONSTRAINT `warehouses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `warehouse_bookings`
--
ALTER TABLE `warehouse_bookings`
  ADD CONSTRAINT `warehouse_bookings_booked_by_foreign` FOREIGN KEY (`booked_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `warehouse_bookings_warehouse_id_foreign` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`);

--
-- Constraints for table `warehouse_features`
--
ALTER TABLE `warehouse_features`
  ADD CONSTRAINT `warehouse_features_feature_id_foreign` FOREIGN KEY (`feature_id`) REFERENCES `warehouse_feature_keys` (`id`),
  ADD CONSTRAINT `warehouse_features_warehouse_id_foreign` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`);

--
-- Constraints for table `warehouse_images`
--
ALTER TABLE `warehouse_images`
  ADD CONSTRAINT `warehouse_images_warehouse_id_foreign` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`);

--
-- Constraints for table `warehouse_related_loggings`
--
ALTER TABLE `warehouse_related_loggings`
  ADD CONSTRAINT `warehouse_related_loggings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
