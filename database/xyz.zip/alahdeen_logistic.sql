-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 15, 2021 at 07:15 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `alahdeen_logistic`
--

-- --------------------------------------------------------

--
-- Table structure for table `accepted_rides`
--

CREATE TABLE `accepted_rides` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `booking_request_id` bigint(20) UNSIGNED NOT NULL,
  `driver_id` bigint(20) UNSIGNED NOT NULL,
  `offer` double(8,2) NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `booking_consignments`
--

CREATE TABLE `booking_consignments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `booking_request_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `type_of_packing` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_of_packs` int(11) NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `booking_requests`
--

CREATE TABLE `booking_requests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `vehicle_id` bigint(20) UNSIGNED NOT NULL,
  `delivery_type` enum('inner-city','inter-city','international') COLLATE utf8mb4_unicode_ci NOT NULL,
  `pick_up_city_id` bigint(20) UNSIGNED NOT NULL,
  `shipper_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipper_contact_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipper_address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipper_lat` decimal(10,8) NOT NULL,
  `shipper_lng` decimal(11,8) NOT NULL,
  `drop_off_city_id` bigint(20) UNSIGNED NOT NULL,
  `receiver_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receiver_contact_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receiver_address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receiver_lat` decimal(10,8) NOT NULL,
  `receiver_lng` decimal(11,8) NOT NULL,
  `weight` double(8,2) NOT NULL,
  `weight_unit` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `volume` double(8,2) NOT NULL,
  `volume_unit` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `departure_date` date NOT NULL,
  `departure_time` time NOT NULL,
  `bid_offer` double(8,2) NOT NULL,
  `comments_and_wishes` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `terms_agreed` tinyint(1) NOT NULL DEFAULT 0,
  `shipment_requestor` bigint(20) UNSIGNED NOT NULL,
  `pick_up_country` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `drop_off_country` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vehicle_type` enum('full_vehicle','shared_vehicle') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `drivers`
--

CREATE TABLE `drivers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dob` date NOT NULL,
  `license_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `license_photo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `license_expiry_date` date NOT NULL,
  `cnic_front` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cnic_back` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `referral_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_verified` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `driver_feedback`
--

CREATE TABLE `driver_feedback` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `booking_request_id` bigint(20) UNSIGNED NOT NULL,
  `rating` decimal(3,2) NOT NULL DEFAULT 0.00,
  `feedback` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `driver_locations`
--

CREATE TABLE `driver_locations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `driver_id` bigint(20) UNSIGNED NOT NULL,
  `lat` decimal(10,8) NOT NULL,
  `lng` decimal(11,8) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `driver_vehicles`
--

CREATE TABLE `driver_vehicles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `driver_id` bigint(20) UNSIGNED NOT NULL,
  `vehicle_id` bigint(20) UNSIGNED NOT NULL,
  `company_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number_plate_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `registration_certificate` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fitness_certificate` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `receipts`
--

CREATE TABLE `receipts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `booking_request_id` bigint(20) UNSIGNED NOT NULL,
  `customer_id` bigint(20) UNSIGNED NOT NULL,
  `driver_id` bigint(20) UNSIGNED NOT NULL,
  `fare` double(8,2) NOT NULL,
  `commission` double(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ride_offers`
--

CREATE TABLE `ride_offers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `booking_request_id` bigint(20) UNSIGNED NOT NULL,
  `driver_id` bigint(20) UNSIGNED NOT NULL,
  `offer` double(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shipment_trackings`
--

CREATE TABLE `shipment_trackings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `booking_request_id` bigint(20) UNSIGNED NOT NULL,
  `lat` decimal(10,8) NOT NULL,
  `lng` decimal(11,8) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vehicles`
--

CREATE TABLE `vehicles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `image_path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `vehicles`
--

INSERT INTO `vehicles` (`id`, `name`, `parent_id`, `image_path`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Motor Bike', 0, 'images/vehicle/motor_bike.jpg', '2021-12-08 08:14:54', '2021-12-08 08:14:54', NULL),
(2, 'Pickup', 0, 'images/vehicle/pickup.jpg', '2021-12-08 08:14:54', '2021-12-08 08:14:54', NULL),
(3, 'Pickup Open', 2, 'images/vehicle/pickup_open.jpg', '2021-12-08 08:14:54', '2021-12-08 08:14:54', NULL),
(4, 'Pickup Close', 2, 'images/vehicle/pickup_close.jpg', '2021-12-08 08:14:54', '2021-12-08 08:14:54', NULL),
(5, 'Shehzore', 0, 'images/vehicle/shehzore.jpg', '2021-12-08 08:14:54', '2021-12-08 08:14:54', NULL),
(6, 'Shehzore Open', 5, 'images/vehicle/shehzore_open.jpg', '2021-12-08 08:14:54', '2021-12-08 08:14:54', NULL),
(7, 'Shehzore Close', 5, 'images/vehicle/shehzore_close.jpg', '2021-12-08 08:14:54', '2021-12-08 08:14:54', NULL),
(8, 'Mazda', 0, 'images/vehicle/Mazda.jpg', '2021-12-08 08:14:54', '2021-12-08 08:14:54', NULL),
(9, 'Mazda Flatbed', 8, 'images/vehicle/mazda_flatbed.jpg', '2021-12-08 08:14:54', '2021-12-08 08:14:54', NULL),
(10, 'Mazda Open', 8, 'images/vehicle/mazda_open.jpg', '2021-12-08 08:14:54', '2021-12-08 08:14:54', NULL),
(11, 'Mazda Containerized', 8, 'images/vehicle/mazda_containerized.jpg', '2021-12-08 08:14:54', '2021-12-08 08:14:54', NULL),
(12, 'Mazda Commercial 16 Feet', 8, 'images/vehicle/mazda_com_16_ft.jpg', '2021-12-08 08:14:54', '2021-12-08 08:14:54', NULL),
(13, 'Mazda Commercial 20 Feet', 8, 'images/vehicle/mazda_com_20_ft.jpg', '2021-12-08 08:14:54', '2021-12-08 08:14:54', NULL),
(14, 'Heavy Vehicle', 0, 'images/vehicle/heavy_vehicle.jpg', '2021-12-08 08:14:54', '2021-12-08 08:14:54', NULL),
(15, 'Heavy Vehicle 20Ft Flatbed', 14, 'images/vehicle/heavy_vehicle_20ft_fb.jpg', '2021-12-08 08:14:54', '2021-12-08 08:14:54', NULL),
(16, 'Heavy Vehicle 20Ft Half Body', 14, 'images/vehicle/heavy_vehicle_20ft_hb.jpg', '2021-12-08 08:14:54', '2021-12-08 08:14:54', NULL),
(17, 'Heavy Vehicle 20Ft Containerized', 14, 'images/vehicle/heavy_vehicle_20ft_containerized.jpg', '2021-12-08 08:14:54', '2021-12-08 08:14:54', NULL),
(18, 'Heavy Vehicle 40Ft Flatbed', 14, 'images/vehicle/heavy_vehicle_40ft_fb.jpg', '2021-12-08 08:14:54', '2021-12-08 08:14:54', NULL),
(19, 'Heavy Vehicle 40Ft Half Body', 14, 'images/vehicle/heavy_vehicle_40ft_hb.jpg', '2021-12-08 08:14:54', '2021-12-08 08:14:54', NULL),
(20, 'Heavy Vehicle 40Ft Containerized', 14, 'images/vehicle/heavy_vehicle_40ft_containerized.jpg', '2021-12-08 08:14:54', '2021-12-08 08:14:54', NULL),
(21, 'Water Tanker', 0, 'images/vehicle/water_tanker.jpg', '2021-12-08 08:14:54', '2021-12-08 08:14:54', NULL),
(22, 'Water Tanker 1000 gal', 21, 'images/vehicle/water_tanker_1k_gal.jpg', '2021-12-08 08:14:54', '2021-12-08 08:14:54', NULL),
(23, 'Water Tanker 2000 gal', 21, 'images/vehicle/water_tanker_2k_gal.jpg', '2021-12-08 08:14:54', '2021-12-08 08:14:54', NULL),
(24, 'Water Tanker 3000 gal', 21, 'images/vehicle/water_tanker_3k_gal.jpg', '2021-12-08 08:14:54', '2021-12-08 08:14:54', NULL),
(25, 'Water Tanker 4000 gal', 21, 'images/vehicle/water_tanker_4k_gal.jpg', '2021-12-08 08:14:54', '2021-12-08 08:14:54', NULL),
(26, 'Water Tanker 5000 gal', 21, 'images/vehicle/water_tanker_5k_gal.jpg', '2021-12-08 08:14:54', '2021-12-08 08:14:54', NULL),
(27, 'Water Tanker 6000 gal', 21, 'images/vehicle/water_tanker_6k_gal.jpg', '2021-12-08 08:14:54', '2021-12-08 08:14:54', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accepted_rides`
--
ALTER TABLE `accepted_rides`
  ADD PRIMARY KEY (`id`),
  ADD KEY `accepted_rides_booking_request_id_foreign` (`booking_request_id`),
  ADD KEY `accepted_rides_driver_id_foreign` (`driver_id`);

--
-- Indexes for table `booking_consignments`
--
ALTER TABLE `booking_consignments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `booking_consignments_product_id_foreign` (`product_id`);

--
-- Indexes for table `booking_requests`
--
ALTER TABLE `booking_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `booking_requests_vehicle_id_foreign` (`vehicle_id`),
  ADD KEY `booking_requests_pick_up_city_id_foreign` (`pick_up_city_id`),
  ADD KEY `booking_requests_drop_off_city_id_foreign` (`drop_off_city_id`),
  ADD KEY `booking_requests_shipment_requestor_foreign` (`shipment_requestor`);

--
-- Indexes for table `drivers`
--
ALTER TABLE `drivers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `drivers_user_id_unique` (`user_id`);

--
-- Indexes for table `driver_feedback`
--
ALTER TABLE `driver_feedback`
  ADD PRIMARY KEY (`id`),
  ADD KEY `driver_feedback_booking_request_id_foreign` (`booking_request_id`);

--
-- Indexes for table `driver_locations`
--
ALTER TABLE `driver_locations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `driver_locations_driver_id_unique` (`driver_id`);

--
-- Indexes for table `driver_vehicles`
--
ALTER TABLE `driver_vehicles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `driver_vehicles_driver_id_foreign` (`driver_id`),
  ADD KEY `driver_vehicles_vehicle_id_foreign` (`vehicle_id`);

--
-- Indexes for table `receipts`
--
ALTER TABLE `receipts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `receipts_booking_request_id_foreign` (`booking_request_id`),
  ADD KEY `receipts_driver_id_foreign` (`driver_id`),
  ADD KEY `receipts_customer_id_foreign` (`customer_id`);

--
-- Indexes for table `ride_offers`
--
ALTER TABLE `ride_offers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ride_offers_booking_request_id_foreign` (`booking_request_id`),
  ADD KEY `ride_offers_driver_id_foreign` (`driver_id`);

--
-- Indexes for table `shipment_trackings`
--
ALTER TABLE `shipment_trackings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `shipment_trackings_booking_request_id_foreign` (`booking_request_id`);

--
-- Indexes for table `vehicles`
--
ALTER TABLE `vehicles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `vehicles_name_unique` (`name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accepted_rides`
--
ALTER TABLE `accepted_rides`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `booking_consignments`
--
ALTER TABLE `booking_consignments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `booking_requests`
--
ALTER TABLE `booking_requests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `drivers`
--
ALTER TABLE `drivers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `driver_feedback`
--
ALTER TABLE `driver_feedback`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `driver_locations`
--
ALTER TABLE `driver_locations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `driver_vehicles`
--
ALTER TABLE `driver_vehicles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `receipts`
--
ALTER TABLE `receipts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ride_offers`
--
ALTER TABLE `ride_offers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `shipment_trackings`
--
ALTER TABLE `shipment_trackings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vehicles`
--
ALTER TABLE `vehicles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `accepted_rides`
--
ALTER TABLE `accepted_rides`
  ADD CONSTRAINT `accepted_rides_booking_request_id_foreign` FOREIGN KEY (`booking_request_id`) REFERENCES `booking_requests` (`id`),
  ADD CONSTRAINT `accepted_rides_driver_id_foreign` FOREIGN KEY (`driver_id`) REFERENCES `drivers` (`id`);

--
-- Constraints for table `driver_feedback`
--
ALTER TABLE `driver_feedback`
  ADD CONSTRAINT `driver_feedback_booking_request_id_foreign` FOREIGN KEY (`booking_request_id`) REFERENCES `booking_requests` (`id`);

--
-- Constraints for table `driver_locations`
--
ALTER TABLE `driver_locations`
  ADD CONSTRAINT `driver_locations_driver_id_foreign` FOREIGN KEY (`driver_id`) REFERENCES `drivers` (`id`);

--
-- Constraints for table `driver_vehicles`
--
ALTER TABLE `driver_vehicles`
  ADD CONSTRAINT `driver_vehicles_driver_id_foreign` FOREIGN KEY (`driver_id`) REFERENCES `drivers` (`id`),
  ADD CONSTRAINT `driver_vehicles_vehicle_id_foreign` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicles` (`id`);

--
-- Constraints for table `ride_offers`
--
ALTER TABLE `ride_offers`
  ADD CONSTRAINT `ride_offers_booking_request_id_foreign` FOREIGN KEY (`booking_request_id`) REFERENCES `booking_requests` (`id`),
  ADD CONSTRAINT `ride_offers_driver_id_foreign` FOREIGN KEY (`driver_id`) REFERENCES `drivers` (`id`);

--
-- Constraints for table `shipment_trackings`
--
ALTER TABLE `shipment_trackings`
  ADD CONSTRAINT `shipment_trackings_booking_request_id_foreign` FOREIGN KEY (`booking_request_id`) REFERENCES `booking_requests` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
